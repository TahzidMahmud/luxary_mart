export interface IBrandShort {
    id: number;
    name: string;
    slug: string;
    thumbnailImage: string;
}
