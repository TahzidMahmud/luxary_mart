import Cookies from 'universal-cookie';

export const cookies = new Cookies();
