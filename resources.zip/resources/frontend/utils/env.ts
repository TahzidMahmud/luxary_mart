export const API_URL = window.config.generalSettings?.apiUrl;
