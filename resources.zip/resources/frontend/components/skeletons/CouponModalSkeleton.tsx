const CouponModalSkeleton = () => {
    return <div>CouponModalSkeleton</div>;
};

export default CouponModalSkeleton;
