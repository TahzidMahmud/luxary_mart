export { default as Cards } from './Cards';
export { default as Gift } from './Gift';
export { default as NotFound } from './NotFound';
export { default as OrderSuccess } from './OrderSuccess';
export { default as PercentBadge } from './PercentBadge';
export { default as Shop } from './Shop';
