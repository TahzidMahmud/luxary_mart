import SearchAndFilter from '../components/search-filter/SearchAndFilter';

const Discounts = () => {
    return <SearchAndFilter discounted={true} />;
};

export default Discounts;
