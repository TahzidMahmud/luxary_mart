import OrderDetailsView from '../../components/order/OrderDetailsView';

const OrderDetails = () => {
    return <OrderDetailsView />;
};

export default OrderDetails;
