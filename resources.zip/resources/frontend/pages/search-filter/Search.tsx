import SearchAndFilter from '../../components/search-filter/SearchAndFilter';

const Search = () => {
    return (
        <>
            <SearchAndFilter />
        </>
    );
};

export default Search;
