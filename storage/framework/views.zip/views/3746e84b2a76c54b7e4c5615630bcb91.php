<div class="update-orders">
    <div class="flex flex-col">
        <div class="overflow-x-auto sm:mx-0.5 lg:mx-0.5">
            <div class="inline-block min-w-full">
                <div class="overflow-hidden">
                    <table class="w-full">
                        <thead class="bg-theme-primary/10 border-b border-border">
                            <tr class="text-left">
                                <th class="p-4 ps-6">
                                    #
                                </th>
                                <th class="p-4 w-[200px]" data-breakpoints="xs sm">
                                    <?php echo e(translate('Product')); ?>

                                </th>

                                <th class="p-4" data-breakpoints="xs sm">

                                    <?php echo e(translate('Current Stock')); ?>


                                </th>

                                <th class="p-4" data-breakpoints="xs sm">

                                    <?php echo e(translate('Qty')); ?>


                                </th>

                                <th class="p-4" data-breakpoints="xs sm">

                                    <?php echo e(translate('Action')); ?>


                                </th>
                            </tr>
                        </thead>
                        <tbody class="update-orders-tbody">
                            <?php if(count($orders) > 0): ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $product = $order->product;
                                        $productVariation = $order->productVariation;

                                        $disabledInput = false;
                                        if ($product->trashed() || $productVariation->trashed()) {
                                            $disabledInput = true;
                                        }

                                        $stockQty = 0;
                                        $productVariationStock = $productVariation
                                            ->productVariationStocks()
                                            ->where('warehouse_id', $order->purchaseOrder->warehouse_id)
                                            ->first();

                                        if (!is_null($productVariationStock)) {
                                            $stockQty = $productVariationStock->stock_qty;
                                        }
                                        $max = null;
                                        if (Route::is('admin.purchase-return.create')) {
                                            $max = $order->qty;
                                        }
                                    ?>

                                    <input type="hidden" name="purchaseOrderProductVariationIds[]"
                                        value="<?php echo e($order->id); ?>">

                                    <tr
                                        class="bg-background border-b border-border transition duration-300 ease-in-out hover:bg-background-hover">
                                        <td class="p-4 whitespace-nowrap text-sm font-medium text-foreground">
                                            <span class="tr-length"><?php echo e($key + 1); ?></span>
                                            <input type="hidden" name="selectedVariationIds[]"
                                                value="<?php echo e($order->product_variation_id); ?>">
                                        </td>
                                        <td
                                            class="text-sm text-foreground font-light p-4 w-[200px] tr-name <?php echo e($disabledInput ? 'text-red-500' : ''); ?>">
                                            <?php echo e($product->collectTranslation('name')); ?> <?php if($product->has_variation): ?>
                                                - <?php echo e(generateVariationName($productVariation->code)); ?>

                                            <?php endif; ?>

                                            <?php if($disabledInput): ?>
                                                <span class="tooltip">
                                                    <span class="tooltip__toggler">
                                                        <i class="far fa-exclamation-circle"></i>
                                                    </span>
                                                    <span
                                                        class="tooltip__content"><?php echo e(translate('This item is not available in system now')); ?></span>
                                                </span>
                                            <?php endif; ?>

                                        </td>

                                        <td
                                            class="p-4 whitespace-nowrap text-sm font-medium text-foreground tr-current-stock">
                                            <?php echo e($stockQty); ?> <span
                                                class="tr-unit"><?php echo e($product->unit?->collectTranslation('name')); ?></span>
                                        </td>
                                        <td
                                            class="text-sm text-foreground font-light p-4 whitespace-nowrap min-w-[150px]">

                                            <input type="hidden" name="unitPrice[]" value="<?php echo e($order->unit_price); ?>">
                                            <?php echo e(formatPrice($order->unit_price)); ?>


                                        </td>

                                        <td
                                            class="text-sm text-foreground font-light px-6 py-4 whitespace-nowrap min-w-[150px]">

                                            <?php if($disabledInput): ?>
                                                <input type="hidden" name="stockQty[]"
                                                    value="<?php echo e($returnOrder ? $order->returned_qty : 0); ?>">
                                            <?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['name' => 'stockQty[]','value' => ''.e($returnOrder ? $order->returned_qty : 0).'','isDisabled' => $disabledInput] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '0','max' => ''.e($max).'','onkeyup' => 'calculateSubtotal(this)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>

                                        </td>

                                        <td class="text-sm text-foreground font-light p-4 whitespace-nowrap">

                                            <input type="hidden" name="discount[]"
                                                value="<?php echo e($returnOrder ? $order->discount / ($order->returned_qty > 0 ? $order->returned_qty : 1) : $order->discount / $order->qty); ?>">
                                            <input type="hidden" name="discountPrice[]"
                                                value="<?php echo e($returnOrder ? $order->discount : 0); ?>">
                                            <span
                                                class="tr-discount"><?php echo e(number_format($returnOrder ? $order->discount : 0, 3)); ?></span>

                                        </td>

                                        <td class="text-sm text-foreground font-light p-4 whitespace-nowrap">

                                            <input type="hidden" name="tax[]"
                                                value="<?php echo e($returnOrder ? $order->tax / ($order->returned_qty > 0 ? $order->returned_qty : 1) : $order->tax / $order->qty); ?> }}">
                                            <input type="hidden" name="taxPrice[]"
                                                value="<?php echo e($returnOrder ? $order->tax : 0); ?>">
                                            <span
                                                class="tr-tax"><?php echo e(number_format($returnOrder ? $order->tax : 0, 3)); ?></span>

                                        </td>
                                        <td class="p-4 whitespace-nowrap text-sm font-medium text-foreground">
                                            <?php if(!Route::is('admin.purchase-return.create')): ?>
                                                <input type="hidden" name="subtotal[]"
                                                    value="<?php echo e($order->grand_total); ?>">
                                                <span
                                                    class="tr-subtotal"><?php echo e(number_format($order->grand_total, 3)); ?></span>
                                            <?php else: ?>
                                                <input type="hidden" name="subtotal[]"
                                                    value="<?php echo e($returnOrder ? $order->grand_total : 0); ?>">
                                                <span
                                                    class="tr-subtotal"><?php echo e(number_format($returnOrder ? $order->grand_total : 0, 3)); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr class="bg-background no-data">
                                    <td colspan="9"
                                        class="p-4 whitespace-nowrap text-sm font-medium text-foreground text-center">
                                        <?php echo e(translate('No data')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/orders/update-order-table.blade.php ENDPATH**/ ?>