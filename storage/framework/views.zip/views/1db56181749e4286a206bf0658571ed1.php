<?php if(count($products) == 0 && count($orders) == 0): ?>
    <a href="javascript:void(0);" class="block py-4 px-6 text-center">
        <?php echo e(translate('No result')); ?>

    </a>
<?php else: ?>
    <?php if(count($products) != 0): ?>
        <div class="flex justify-between py-4 px-6 bg-theme-primary/[.03] text-muted font-bold uppercase">
            <div>
                <?php echo e(translate('Products')); ?>

            </div>
            <a href="<?php echo e(route(routePrefix() . '.products.index') . '?search=' . $searchKey); ?>">
                <?php echo e(translate('View More')); ?>

            </a>
        </div>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route(routePrefix() . '.products.edit', $product->id)); ?>?lang_key=<?php echo e(config('app.default_language')); ?>&translate"
                class="block py-4 px-6">
                <?php echo e($product->collectTranslation('name')); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(count($orders) != 0): ?>
        <div class="flex justify-between py-4 px-6 bg-theme-primary/[.03] text-muted font-bold uppercase">
            <div>
                <?php echo e(translate('Orders')); ?>

            </div>
            <a href="<?php echo e(route(routePrefix() . '.orders.index') . '?search=' . $searchKey); ?>">
                <?php echo e(translate('View More')); ?>

            </a>
        </div>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route(routePrefix() . '.orders.show', $order->order_code)); ?>" class="block py-4 px-6">
                <?php echo e($order->user->name); ?> - <?php echo e($order->order_code); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


<?php endif; ?>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inc/navbar-search.blade.php ENDPATH**/ ?>