<aside class="sidebar h-full hover-scrollbar">
    <ul class="sidebar__list flex-grow">
        <li class="sidebar__logo hidden pl-[57px] py-10">
            <img src="<?php echo e(uploadedAsset(getSetting('websiteHeaderLogo'))); ?>" alt="" class="max-w-[200px]" />
        </li>

        <li class="sidebar__li <?php echo e(areActiveRoutes(['admin.dashboard'])); ?>">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar__item">
                <span class="sidebar__item--icon">
                    <i class="fa-regular fa-house"></i>
                </span>
                <span class="sidebar__item--text"><?php echo e(translate('Dashboard')); ?></span>
            </a>
        </li>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_orders')): ?>
            
            <li class="sidebar__li <?php echo e(areActiveRoutes(['admin.orders.index', 'admin.orders.show'])); ?>">
                <a href="<?php echo e(route('admin.orders.index')); ?>" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-square-poll-vertical"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('Orders')); ?></span>
                </a>
            </li>
        <?php endif; ?>

        
        
        <li class="sidebar__li <?php echo e(areActiveRoutes(['admin.pos'])); ?>">
            <a href="<?php echo e(route('admin.pos')); ?>" class="sidebar__item">
                <span class="sidebar__item--icon">
                    <i class="fa-solid fa-bell-concierge"></i>
                </span>
                <span class="sidebar__item--text"><?php echo e(translate('Sell Panel')); ?></span>
            </a>
        </li>
        

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view_products', 'view_categories', 'view_variations', 'view_brands', 'view_units', 'view_taxes',
            'view_badges'])): ?>
            
            <?php
                $productsActiveRoutes = [
                    'admin.products.*',
                    'admin.refunds',
                    'admin.units.*',
                    'admin.taxes.*',
                    'admin.badges.*',
                    'admin.brands.*',
                    'admin.categories.*',
                    'admin.variations.*',
                    'admin.variation-values.*',
                ];
            ?>
            <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($productsActiveRoutes, 'active expanded')); ?>">
                <a href="javascript:void(0);" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-cart-plus"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('Products')); ?></span>

                    <button class="sidebar__list--toggler">
                        <i class="fa-regular fa-chevron-down"></i>
                    </button>
                </a>

                <ul class="text-foreground divide-y divide-border bg-theme-primary/5">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_products')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.products.*'])); ?>">
                            <a href="<?php echo e(route('admin.products.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Products')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_categories')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.categories.*'])); ?>">
                            <a href="<?php echo e(route('admin.categories.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Categories')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_variations')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.variations.*', 'admin.variation-values.*'])); ?>">
                            <a href="<?php echo e(route('admin.variations.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Variations')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_brands')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.brands.*'])); ?>">
                            <a href="<?php echo e(route('admin.brands.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Brands')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_units')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.units.*'])); ?>">
                            <a href="<?php echo e(route('admin.units.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Units')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_taxes')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.taxes.*'])); ?>">
                            <a href="<?php echo e(route('admin.taxes.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Taxes')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_badges')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.badges.*'])); ?>">
                            <a href="<?php echo e(route('admin.badges.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Badges')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view_purchase_orders', 'view_return_purchase_orders', 'view_stock_adjustment', 'view_stock_transfer',
            'view_suppliers'])): ?>
            <?php if(useInventory()): ?>
                
                <?php
                    $inventoryActiveRoutes = [
                        'admin.suppliers.*',
                        'admin.purchase-orders.*',
                        'admin.purchase-return.*',
                        'admin.stockAdjustments.*',
                        'admin.stockTransfers.*',
                    ];
                ?>
                <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($inventoryActiveRoutes, 'active expanded')); ?>">
                    <a href="javascript:void(0);" class="sidebar__item">
                        <span class="sidebar__item--icon">
                            <i class="fa-regular  fa-calendar-check"></i>
                        </span>
                        <span class="sidebar__item--text"><?php echo e(translate('Inventory')); ?></span>

                        <button class="sidebar__list--toggler">
                            <i class="fa-regular fa-chevron-down"></i>
                        </button>
                    </a>

                    <ul class="text-foreground divide-y divide-border bg-theme-primary/5">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_purchase_orders')): ?>
                            <li class="<?php echo e(areActiveRoutes(['admin.purchase-orders.*'])); ?>">
                                <a href="<?php echo e(route('admin.purchase-orders.index')); ?>" class="py-3 w-full transition-all">
                                    <span class="sub-item--text"><?php echo e(translate('Purchase Orders')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_return_purchase_orders')): ?>
                            <li class="<?php echo e(areActiveRoutes(['admin.purchase-return.*'])); ?>">
                                <a href="<?php echo e(route('admin.purchase-return.index')); ?>" class="py-3 w-full transition-all">
                                    <span class="sub-item--text"><?php echo e(translate('Purchases Return')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_stock_adjustment')): ?>
                            <li class="<?php echo e(areActiveRoutes(['admin.stockAdjustments.*'])); ?>">
                                <a href="<?php echo e(route('admin.stockAdjustments.index')); ?>" class="py-3 w-full transition-all">
                                    <span class="sub-item--text"><?php echo e(translate('Stock Adjustment')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_stock_transfer')): ?>
                            <li class="<?php echo e(areActiveRoutes(['admin.stockTransfers.*'])); ?>">
                                <a href="<?php echo e(route('admin.stockTransfers.index')); ?>" class="py-3 w-full transition-all">
                                    <span class="sub-item--text"><?php echo e(translate('Stock Transfer')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_suppliers')): ?>
                            <li class="<?php echo e(areActiveRoutes(['admin.suppliers.*'])); ?>">
                                <a href="<?php echo e(route('admin.suppliers.index')); ?>" class="py-3 w-full transition-all">
                                    <span class="sub-item--text"><?php echo e(translate('Suppliers')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
        <?php endif; ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_customers')): ?>
            
            <li class="sidebar__li <?php echo e(areActiveRoutes(['admin.customers.index', 'admin.customers.show'])); ?>">
                <a href="<?php echo e(route('admin.customers.index')); ?>" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-users"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('Customers')); ?></span>
                </a>
            </li>
        <?php endif; ?>

        
        <?php
            $moderatorActiveRoutes = ['admin.moderators.*'];
        ?>
        <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($moderatorActiveRoutes, 'active expanded')); ?>">
            <a href="javascript:void(0);" class="sidebar__item">
                <span class="sidebar__item--icon">
                    <i class="fa-regular fa-user"></i>
                </span>
                <span class="sidebar__item--text"><?php echo e(translate('Moderators')); ?></span>

                <button class="sidebar__list--toggler">
                    <i class="fa-regular fa-chevron-down"></i>
                </button>
            </a>

            <ul class="text-foreground divide-y divide-border bg-theme-primary/5">

                <li class="<?php echo e(areActiveRoutes(['admin.moderators.index', 'admin.moderators.edit'])); ?>">
                    <a href="<?php echo e(route('admin.moderators.index')); ?>" class="py-3 w-full transition-all">
                        <span class="sub-item--text"><?php echo e(translate('Moderator Commissions')); ?></span>
                    </a>
                </li>
                <li class="<?php echo e(areActiveRoutes(['admin.moderators.payoutList'])); ?>">
                    <a href="<?php echo e(route('admin.moderators.payoutList')); ?>" class="py-3 w-full transition-all">
                        <span class="sub-item--text"><?php echo e(translate('Payouts')); ?></span>
                    </a>
                </li>
            </ul>
        </li>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view_sellers', 'show_payouts', 'show_payout_requests', 'show_earning_histories'])): ?>
            
            <?php
                $sellersActiveRoutes = ['admin.sellers.*'];
            ?>
            <?php if(config('app.app_mode') == 'multiVendor'): ?>
                <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($sellersActiveRoutes, 'active expanded')); ?>">
                    <a href="javascript:void(0);" class="sidebar__item">
                        <span class="sidebar__item--icon">
                            <i class="fa-regular fa-shop"></i>
                        </span>
                        <span class="sidebar__item--text"><?php echo e(translate('Seller Management')); ?></span>

                        <button class="sidebar__list--toggler">
                            <i class="fa-regular fa-chevron-down"></i>
                        </button>
                    </a>

                    <ul class="text-foreground divide-y divide-border bg-theme-primary/5">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_sellers')): ?>
                            <li class="<?php echo e(areActiveRoutes(['admin.sellers.index', 'admin.sellers.edit'])); ?>">
                                <a href="<?php echo e(route('admin.sellers.index')); ?>" class="py-3 w-full transition-all">
                                    <span class="sub-item--text"><?php echo e(translate('Sellers')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_payouts')): ?>
                            <li class="<?php echo e(areActiveRoutes(['admin.sellers.payouts'])); ?>">
                                <a href="<?php echo e(route('admin.sellers.payouts')); ?>" class="py-3 w-full transition-all">
                                    <span class="sub-item--text"><?php echo e(translate('Payouts')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_payout_requests')): ?>
                            <li class="<?php echo e(areActiveRoutes(['admin.sellers.payoutRequests'])); ?>">
                                <a href="<?php echo e(route('admin.sellers.payoutRequests')); ?>" class="py-3 w-full transition-all">
                                    <span class="sub-item--text"><?php echo e(translate('Payout Requests')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_earning_histories')): ?>
                            <li class="<?php echo e(areActiveRoutes(['admin.sellers.earnings'])); ?>">
                                <a href="<?php echo e(route('admin.sellers.earnings')); ?>" class="py-3 w-full transition-all">
                                    <span class="sub-item--text"><?php echo e(translate('Earning Histories')); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_tags')): ?>
            
            <?php
                $resourcesActiveRoutes = ['admin.tags.*'];
            ?>
            <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($resourcesActiveRoutes, 'active expanded')); ?>">
                <a href="javascript:void(0);" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-copy"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('Resources')); ?></span>

                    <button class="sidebar__list--toggler">
                        <i class="fa-regular fa-chevron-down"></i>
                    </button>
                </a>

                <ul class="text-foreground divide-y divide-border bg-theme-primary/5">
                    <li class="<?php echo e(areActiveRoutes(['admin.tags.*'])); ?>">
                        <a href="<?php echo e(route('admin.tags.index')); ?>" class="py-3 w-full transition-all">
                            <span class="sub-item--text"><?php echo e(translate('Tags')); ?></span>
                        </a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view_coupons', 'view_campaigns', 'view_subscribers'])): ?>
            
            <?php
                $promotionsActiveRoutes = [
                    'admin.coupons.*',
                    'admin.campaigns.*',
                    'admin.subscribers.index',
                    'admin.newsletters.index',
                ];
            ?>
            <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($promotionsActiveRoutes, 'active expanded')); ?>">
                <a href="javascript:void(0);" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-wand-magic-sparkles"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('Promotions')); ?></span>

                    <button class="sidebar__list--toggler">
                        <i class="fa-regular fa-chevron-down"></i>
                    </button>
                </a>

                <ul class="text-foreground divide-y divide-border bg-theme-primary/5">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_coupons')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.coupons.*'])); ?>">
                            <a href="<?php echo e(route('admin.coupons.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Coupons')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_campaigns')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.campaigns.*'])); ?>">
                            <a href="<?php echo e(route('admin.campaigns.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Campaign')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_subscribers')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.subscribers.index'])); ?>">
                            <a href="<?php echo e(route('admin.subscribers.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Subscribers')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('send_newsletters')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.newsletters.index'])); ?>">
                            <a href="<?php echo e(route('admin.newsletters.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Newsletters')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view_countries', 'view_states', 'view_cities', 'view_areas', 'view_zones', 'view_warehouses',
            'delivery_charges'])): ?>
            
            <?php
                $shippingActiveRoutes = [
                    'admin.countries.*',
                    'admin.states.*',
                    'admin.cities.*',
                    'admin.areas.*',
                    'admin.zones.*',
                    'admin.warehouses.*',
                    'admin.delivery-charges.*',
                ];
            ?>
            <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($shippingActiveRoutes, 'active expanded')); ?>">
                <a href="javascript:void(0);" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-shipping-fast"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('Shipping & Delivery')); ?></span>

                    <button class="sidebar__list--toggler">
                        <i class="fa-regular fa-chevron-down"></i>
                    </button>
                </a>

                
                <ul class="text-foreground divide-y divide-border bg-theme-primary/5">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_countries')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.countries.*'])); ?>">
                            <a href="<?php echo e(route('admin.countries')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Countries')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_states')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.states.*'])); ?>">
                            <a href="<?php echo e(route('admin.states.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('States')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_cities')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.cities.*'])); ?>">
                            <a href="<?php echo e(route('admin.cities.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Cities')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_areas')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.areas.*'])); ?>">
                            <a href="<?php echo e(route('admin.areas.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Areas')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_zones')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.zones.*'])); ?>">
                            <a href="<?php echo e(route('admin.zones.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Zones')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_warehouses')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.warehouses.*'])); ?>">
                            <a href="<?php echo e(route('admin.warehouses.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Warehouses')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delivery_charges')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.delivery-charges.*'])); ?>">
                            <a href="<?php echo e(route('admin.delivery-charges.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Delivery Charges')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('file_manager')): ?>
            
            <li class="sidebar__li  <?php echo e(areActiveRoutes(['file-manager.index'])); ?>">
                <a href="<?php echo e(route('file-manager.index')); ?>" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-image"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('File Management')); ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('conversation')): ?>
            <?php if(config('app.app_mode') == 'multiVendor'): ?>
                <li class="sidebar__li  <?php echo e(areActiveRoutes(['admin.chat'])); ?>">
                    <a href="<?php echo e(route('admin.chat')); ?>" class="sidebar__item">
                        <span class="sidebar__item--icon">
                            <i class="fa-regular fa-message"></i>
                        </span>
                        <span class="sidebar__item--text"><?php echo e(translate('Conversations')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view_home_sections', 'configurations'])): ?>
            
            <?php
                $shopSettingsActiveRoutes = ['admin.shop-sections.*', 'admin.shops.*'];
            ?>
            <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($shopSettingsActiveRoutes, 'active expanded')); ?>">
                <a href="javascript:void(0);" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-shop-lock"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('Shop Settings')); ?></span>

                    <button class="sidebar__list--toggler">
                        <i class="fa-regular fa-chevron-down"></i>
                    </button>
                </a>

                <ul class="text-foreground divide-y divide-border bg-theme-primary/5">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_home_sections')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.shop-sections.*'])); ?>">
                            <a href="<?php echo e(route('admin.shop-sections.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Home Sections')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('configurations')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.shops.profile'])); ?>">
                            <a href="<?php echo e(route('admin.shops.profile')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Configurations')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view_staffs', 'view_roles_and_permissions'])): ?>
            
            <?php
                $staffsActiveRoutes = ['admin.staffs.*', 'admin.roles.*'];
            ?>
            <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($staffsActiveRoutes, 'active expanded')); ?>">
                <a href="javascript:void(0);" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-user-lock"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('Staff Management')); ?></span>

                    <button class="sidebar__list--toggler">
                        <i class="fa-regular fa-chevron-down"></i>
                    </button>
                </a>

                <ul class="text-foreground divide-y divide-border bg-theme-primary/5">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_staffs')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.staffs.*'])); ?>">
                            <a href="<?php echo e(route('admin.staffs.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('All Staffs')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_roles_and_permissions')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.roles.*'])); ?>">
                            <a href="<?php echo e(route('admin.roles.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Roles')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>

        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view_pages', 'homepage', 'color_and_branding'])): ?>
            
            <?php
                $shopSettingsActiveRoutes = ['admin.pages.*', 'admin.homepage.configure', 'admin.colorBranding.index'];
            ?>
            <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($shopSettingsActiveRoutes, 'active expanded')); ?>">
                <a href="javascript:void(0);" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-desktop"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('Website Setup')); ?></span>

                    <button class="sidebar__list--toggler">
                        <i class="fa-regular fa-chevron-down"></i>
                    </button>
                </a>

                <ul class="text-foreground divide-y divide-border bg-theme-primary/5">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('homepage')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.homepage.configure'])); ?>">
                            <?php
                                $homepageId = 1;
                            ?>
                            <a href="<?php echo e(route('admin.homepage.configure', ['id' => $homepageId, 'lang_key' => config('app.default_language')])); ?>&translate"
                                class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Homepage')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_pages')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.pages.*'])); ?>">
                            <a href="<?php echo e(route('admin.pages.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Pages')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('color_and_branding')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.colorBranding.index'])); ?>">
                            <a href="<?php echo e(route('admin.colorBranding.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Color & Branding')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

        
        
        <?php
            $otpSettingsActiveRoutes = ['admin.otp.*'];
        ?>
        <?php if(user()->user_type == 'admin'): ?>
            <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($otpSettingsActiveRoutes, 'active expanded')); ?>">
                <a href="javascript:void(0);" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-phone"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('OTP System')); ?></span>

                    <button class="sidebar__list--toggler">
                        <i class="fa-regular fa-chevron-down"></i>
                    </button>
                </a>

                <ul class="text-foreground divide-y divide-border bg-theme-primary/5">
                    
                    <li class="<?php echo e(areActiveRoutes(['admin.otp.configure'])); ?>">
                        <a href="<?php echo e(route('admin.otp.configure')); ?>" class="py-3 w-full transition-all">
                            <span class="sub-item--text"><?php echo e(translate('Set OTP Credentials')); ?></span>
                        </a>
                    </li>
                    
                </ul>
            </li>
        <?php endif; ?>
        

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['general_settings', 'order_settings', 'smtp_settings', 'payment_methods', 'social_media_login',
            'view_languages'])): ?>
            
            <?php
                $configActiveRoutes = [
                    'admin.general-settings.index',
                    'admin.general-settings.update',
                    'admin.order-settings.index',
                    'admin.smtp-settings.index',
                    'test.smtp',
                    'admin.env-key.update',
                    'admin.payment-method.index',
                    'admin.payment-method.update',
                    'admin.social-login.index',
                    'admin.languages.*',
                ];
            ?>
            <li class="sidebar__li has-submenu <?php echo e(areActiveRoutes($configActiveRoutes, 'active expanded')); ?>">
                <a href="javascript:void(0);" class="sidebar__item">
                    <span class="sidebar__item--icon">
                        <i class="fa-regular fa-gear"></i>
                    </span>
                    <span class="sidebar__item--text"><?php echo e(translate('System Setup')); ?></span>

                    <button class="sidebar__list--toggler">
                        <i class="fa-regular fa-chevron-down"></i>
                    </button>
                </a>

                <ul class="text-foreground divide-y divide-border bg-theme-primary/5">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general_settings')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.general-settings.index'])); ?>">
                            <a href="<?php echo e(route('admin.general-settings.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('General Settings')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_settings')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.order-settings.index'])); ?>">
                            <a href="<?php echo e(route('admin.order-settings.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Order Settings')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_languages')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.languages.*'])); ?>">
                            <a href="<?php echo e(route('admin.languages.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Language Settings')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('smtp_settings')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.smtp-settings.index'])); ?>">
                            <a href="<?php echo e(route('admin.smtp-settings.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('SMTP Settings')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment_methods')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.payment-method.index'])); ?>">
                            <a href="<?php echo e(route('admin.payment-method.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Payment Methods')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('social_media_login')): ?>
                        <li class="<?php echo e(areActiveRoutes(['admin.social-login.index'])); ?>">
                            <a href="<?php echo e(route('admin.social-login.index')); ?>" class="py-3 w-full transition-all">
                                <span class="sub-item--text"><?php echo e(translate('Social Media Login')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

    </ul>

    <div
        class="sticky bottom-0 bg-background px-[15px] pb-3 pt-5 border-t border-border grid grid-cols-2 lg:hidden items-center gap-4">
        <div class="option-dropdown" tabindex="0">
            <?php
                if (Session::has('locale')) {
                    $locale = Session::get('locale', Config::get('app.locale'));
                } else {
                    $locale = env('DEFAULT_LANGUAGE');
                }

                $currentLanguage = \App\Models\Language::where('code', $locale)->first();

                if (is_null($currentLanguage)) {
                    $currentLanguage = \App\Models\Language::where('code', 'en-US')->first();
                }
            ?>

            <div class="option-dropdown__toggler option-dropdown__toggler--icon-small bg-background text-foreground">
                <span>
                    <img src="<?php echo e(asset('images/flags/' . $currentLanguage->flag . '.png')); ?>" alt=""
                        class="w-[20px]" />
                </span>
                <span><?php echo e($currentLanguage->name); ?></span>
            </div>

            <div class="option-dropdown__options option-dropdown__options--top">
                <ul>
                    <?php $__currentLoopData = \App\Models\Language::where('is_active', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="javascript:void(0);"
                                class="option-dropdown__option <?php if($currentLanguage->code == $language->code): ?> active <?php endif; ?>"
                                onclick="changeLocaleLanguage(this)" data-flag="<?php echo e($language->code); ?>">
                                <span>
                                    <img src="<?php echo e(asset('images/flags/' . $language->flag . '.png')); ?>"
                                        alt="" class="w-[20px]" />
                                </span>
                                <span><?php echo e($language->name); ?></span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <a href="<?php echo e(url('/')); ?>" target="_blank"
            class="whitespace-nowrap h-10 inline-flex items-center gap-2 bg-theme-primary text-white rounded-md px-4 font-bold border-2 border-transparent hover:bg-transparent hover:border-theme-primary hover:text-theme-primary">
            <span>
                <i class="fa-light fa-globe-pointer"></i>
            </span>
            <span><?php echo e(translate('Browse')); ?></span>
        </a>
    </div>

    <div class="copyright pl-[57px] pb-9">
        <p class="text-muted leading-none">
            <?php echo e(translate('Powered By')); ?>

        </p>
        <a href="">
            <img src="<?php echo e(uploadedAsset(getSetting('poweredBy'))); ?>" alt="" />
        </a>
    </div>
</aside>
<?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/components/backend/inc/sidebar.blade.php ENDPATH**/ ?>