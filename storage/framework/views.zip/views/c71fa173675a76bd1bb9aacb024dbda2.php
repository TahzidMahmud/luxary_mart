<form action="<?php echo e($tag ? route('admin.tags.update', $tag->id) : route('admin.tags.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <?php if($tag): ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" name="lang_key" value="<?php echo e($langKey); ?>">
    <?php else: ?>
        <?php
            $langKey = config('app.default_language');
        ?>
    <?php endif; ?>

    <div class="space-y-3">
        <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Name','name' => 'name','placeholder' => 'Type tag name','value' => ''.e($tag?->name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>

        <div class="flex justify-end">
            <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['buttonText' => 'Save Tag','type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
        </div>
    </div>
</form>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/forms/tag-form.blade.php ENDPATH**/ ?>