<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Create Stock Transfer')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Create Stock Transfer')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.stockTransfers.index')); ?>" class="font-bold "><?php echo e(translate('Stock Transfer')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Create Stock Transfer')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="card">
        <div class="card__content">
            <?php if (isset($component)) { $__componentOriginalb6e67b51c2016b80d671d5d06d1c2cda = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb6e67b51c2016b80d671d5d06d1c2cda = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\StockTransferForm::resolve(['warehouses' => $warehouses] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.stock-transfer-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\StockTransferForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb6e67b51c2016b80d671d5d06d1c2cda)): ?>
<?php $attributes = $__attributesOriginalb6e67b51c2016b80d671d5d06d1c2cda; ?>
<?php unset($__attributesOriginalb6e67b51c2016b80d671d5d06d1c2cda); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb6e67b51c2016b80d671d5d06d1c2cda)): ?>
<?php $component = $__componentOriginalb6e67b51c2016b80d671d5d06d1c2cda; ?>
<?php unset($__componentOriginalb6e67b51c2016b80d671d5d06d1c2cda); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if (isset($component)) { $__componentOriginal7ec940d2e041d6e1066045107800e0c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ec940d2e041d6e1066045107800e0c2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.inc.stock-transfers-scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inc.stock-transfers-scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ec940d2e041d6e1066045107800e0c2)): ?>
<?php $attributes = $__attributesOriginal7ec940d2e041d6e1066045107800e0c2; ?>
<?php unset($__attributesOriginal7ec940d2e041d6e1066045107800e0c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ec940d2e041d6e1066045107800e0c2)): ?>
<?php $component = $__componentOriginal7ec940d2e041d6e1066045107800e0c2; ?>
<?php unset($__componentOriginal7ec940d2e041d6e1066045107800e0c2); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/inventory/stock-transfers/create.blade.php ENDPATH**/ ?>