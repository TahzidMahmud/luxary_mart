<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Orders Details')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Order details')); ?>

            </span>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="grid 3xl:grid-cols-4 gap-10">
        <div class="3xl:col-span-3 space-y-10">
            <div class="card">
                <h4 class="card__title"><?php echo e(translate('Order Information')); ?></h4>

                <div class="grid lg:grid-cols-2 xl:grid-cols-10 max-lg:divide-y xl:divide-x divide-border">
                    <div class="xl:col-span-3 py-8 px-3 lg:px-6">
                        <p class="text-muted"><?php echo e(translate('INVOICE')); ?></p>
                        <p class="text-xl "><?php echo e(getSetting('orderCodePrefix')); ?><?php echo e($order->order_code); ?></p>
                        <?php if (isset($component)) { $__componentOriginaldbabb662c3b9843f55fe55cc2492a70a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Link::resolve(['href' => ''.e(route('admin.orders.downloadInvoice', $order->id)).'','variant' => 'secondary'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '_blank','class' => 'mt-3']); ?>
                            <?php echo e(translate('DOWNLOAD INVOICE')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a)): ?>
<?php $attributes = $__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a; ?>
<?php unset($__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbabb662c3b9843f55fe55cc2492a70a)): ?>
<?php $component = $__componentOriginaldbabb662c3b9843f55fe55cc2492a70a; ?>
<?php unset($__componentOriginaldbabb662c3b9843f55fe55cc2492a70a); ?>
<?php endif; ?>

                        <p class="mt-4">
                            <span class="mr-3 text-xs text-muted"><?php echo e(translate('Order Created Date')); ?>:</span>
                            <?php echo e(date('d M, Y', strtotime($order->created_at))); ?>

                        </p>
                        <p class="mt-4">
                            <span class="mr-3 text-xs text-muted"><?php echo e(translate('Order Receiving Date')); ?>:</span>
                            <?php echo e($order->order_receiving_date ? date('d M, Y', strtotime($order->order_receiving_date)) : ''); ?>

                        </p>
                        <p class="mt-4">
                            <span class="mr-3 text-xs text-muted"><?php echo e(translate('Order Shipment Date')); ?>:</span>
                            <?php echo e($order->order_shipment_date ? date('d M, Y', strtotime($order->order_shipment_date)) : ''); ?>

                        </p>

                        <p class="mt-10 mb-5 text-muted"><?php echo e(translate('CUSTOMER INFORMATION')); ?></p>
                        <table class="w-full [&_td]:py-2">
                            <tr>
                                <td class="text-xs text-muted"><?php echo e(translate('Name')); ?>:</td>
                                <td class="text-sm"><?php echo e($orderGroup->name); ?></td>
                            </tr>
                            <tr>
                                <td class="text-xs text-muted"><?php echo e(translate('Phone')); ?>:</td>
                                <td class="text-sm"><?php echo e($orderGroup->phone); ?></td>
                            </tr>
                            <tr>
                                <td class="text-xs text-muted"><?php echo e(translate('Email')); ?>:</td>
                                <td class="text-sm">
                                    <?php echo e($orderGroup->email); ?>

                                </td>
                            </tr>
                        </table>
                    </div>

                    <div class="xl:col-span-4 py-8 px-3 lg:px-9">
                        <p class="text-muted mb-6"><?php echo e(translate('DELIVERY INFORMATION')); ?></p>

                        <div class="space-y-7">
                            <div>
                                <div class="flex items-center justify-between mb-2">
                                    <p class="text-muted text-xs"><?php echo e(translate('BILLING ADDRESS')); ?></p>
                                    <a href="javascript:void(0);" data-type="billing_address"
                                        data-address="<?php echo e($orderGroup->billing_address); ?>" data-id="<?php echo e($order->id); ?>"
                                        data-micromodal-trigger="order-address-modal"
                                        class="text-base text-theme-secondary order-address-modal">
                                        <i class="fa-regular fa-pen-to-square"></i>
                                    </a>
                                </div>
                                <p class=" mb-2.5"><?php echo e($orderGroup->billing_address); ?></p>
                            </div>
                            <div>
                                <div class="flex items-center justify-between mb-2">
                                    <p class="text-muted text-xs"><?php echo e(translate('SHIPPING ADDRESS')); ?></p>

                                    <a href="javascript:void(0);" data-type="shipping_address"
                                        data-address="<?php echo e($orderGroup->shipping_address); ?>" data-id="<?php echo e($order->id); ?>"
                                        data-direction="<?php echo e($orderGroup->direction); ?>"
                                        data-phone="<?php echo e($orderGroup->phone); ?>" data-micromodal-trigger="order-address-modal"
                                        class="text-base text-theme-secondary order-address-modal">
                                        <i class="fa-regular fa-pen-to-square"></i>
                                    </a>
                                </div>
                                <p class=" mb-2.5"><?php echo e($orderGroup->shipping_address); ?></p>
                                <p class="text-muted"><?php echo e($orderGroup->direction); ?></p>
                                <p class="text-muted"><?php echo e(translate('Phone')); ?>: <?php echo e($orderGroup->phone); ?></p>
                            </div>

                            <table class="[&_td]:py-1">
                                <tr>
                                    <td class="text-xs text-muted"><?php echo e(translate('Payment Type')); ?>:</td>
                                    <td class="text-sm">
                                        <span
                                            class="ms-4"><?php echo e(ucfirst(str_replace('_', ' ', $orderGroup->transaction->payment_method))); ?></span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="xl:col-span-3 py-8 px-3 lg:px-9 ">
                        <p class="text-muted mb-6"><?php echo e(translate('ORDER TRACKING')); ?></p>

                        <form action="<?php echo e(route('admin.orders.updateOrderTracking')); ?>" class="space-y-3" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                            <div>
                                <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Courier Name','labelInline' => false,'name' => 'courier_name','placeholder' => 'Type courier name','value' => ''.e($order->courier_name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                            </div>
                            <div>
                                <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Tracking Number','labelInline' => false,'name' => 'tracking_number','placeholder' => 'Type tracking number','value' => ''.e($order->tracking_number).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                            </div>
                            <div>
                                <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Tracking URL','labelInline' => false,'name' => 'tracking_url','placeholder' => 'Type tracking url','value' => ''.e($order->tracking_url).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                            </div>

                            <div>
                                <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['type' => 'submit','variant' => 'secondary','buttonText' => 'SAVE DATA'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="card">
                <h4 class="card__title border-b-0"><?php echo e(translate('Product Details')); ?></h4>

                <table class="footable">
                    <thead>
                        <tr>
                            <th><?php echo e(translate('PRODUCT')); ?></th>
                            <th data-breakpoints="xs sm lg"><?php echo e(translate('UNIT PRICE')); ?></th>
                            <th class=" text-center"><?php echo e(translate('QTY')); ?></th>
                            <th data-breakpoints="xs sm lg"><?php echo e(translate('Total TAX')); ?></th>
                            <th data-breakpoints="xs sm lg"><?php echo e(translate('Discount')); ?></th>
                            <th data-breakpoints=""><?php echo e(translate('SUB TOTAL')); ?></th>
                            <th data-breakpoints="" class="text-right"><?php echo e(translate('Action')); ?></th>
                        </tr>
                    </thead>

                    <tbody class="[&_td]:py-3">
                        <?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $variation = $item->productVariation;
                                $product = $variation->product;
                            ?>
                            <tr>
                                <td>
                                    <div class="inline-flex items-center gap-4">
                                        <div class="max-xs:hidden border border-border rounded-md p-2 aspect-square">
                                            <img src="<?php echo e(uploadedAsset($product->thumbnail_image)); ?>"
                                                class="w-12 h-12 lg:w-[70px] lg:h-[70px] rounded-md"
                                                onerror="this.onerror=null;this.src='<?php echo e(asset('images/image-error.png')); ?>';">
                                        </div>
                                        <div class=" line-clamp-2 max-w-[230px]">
                                            <?php echo e($product->collectTranslation('name')); ?> <?php if($product->has_variation): ?>
                                                -
                                                <?php echo e(generateVariationName($variation->code)); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td class="font-medium"><?php echo e(formatPrice($item->unit_price)); ?></td>
                                <td class="font-medium text-center">
                                    <input class="theme-input max-w-[50px] px-2 text-center update_qty" type="text"
                                        data-id="<?php echo e($item->id); ?>" value="<?php echo e($item->qty); ?>"
                                        <?php if($order->delivery_status == 'delivered' || $order->payment_status == 'paid' ? true : false): echo 'disabled'; endif; ?>>
                                </td>
                                <td class="font-medium"><?php echo e(formatPrice($item->total_tax)); ?></td>
                                <td class="font-medium"><?php echo e(formatPrice($item->total_discount)); ?></td>
                                <td class="font-medium"><?php echo e(formatPrice($item->total_price)); ?></td>
                                <td class="font-medium text-right">
                                    <?php if($order->delivery_status != 'delivered' && $order->payment_status != 'paid'): ?>
                                        <a class="text-red-400 hover:text-rose-600 confirm-modal"
                                            href="javascript:void(0);"
                                            data-href="<?php echo e(route('admin.orders.removeOrderItem', $item->id)); ?>"
                                            data-title="<?php echo e(translate('Are you sure you want to delete this item?')); ?>"
                                            data-text="<?php echo e(translate('All data related to this may get deleted.')); ?>"
                                            data-method="DELETE" data-micromodal-trigger="confirm-modal">
                                            <i class="fa-regular fa-trash-can"></i>
                                        </a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="ms-4 md:ms-12 my-3">
                    

                    
                    <div class="modal micromodal-slide" id="update-order-modal" aria-hidden="true">
                        <div class="modal__overlay" tabindex="-1" data-micromodal-close></div>
                        <div class="modal__container max-w-max min-w-[800px]" role="dialog" aria-modal="true"
                            aria-labelledby="update-order-modal-title">
                            <header class="modal__header">
                                <h2 class="modal__title">
                                    <?php echo e(translate('Add Products To Order')); ?>

                                </h2>
                                <button type="button" class="modal__close ms-2" aria-label="Close modal"
                                    data-micromodal-close></button>
                            </header>
                            <main class="modal__content min-h-[180px] w-full">
                                <div id="update-order">
                                    <?php if (isset($component)) { $__componentOriginal30c7f2fd273ac771c545215a67a9d9c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal30c7f2fd273ac771c545215a67a9d9c2 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\UpdateOrderForm::resolve(['order' => $order] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.update-order-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\UpdateOrderForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal30c7f2fd273ac771c545215a67a9d9c2)): ?>
<?php $attributes = $__attributesOriginal30c7f2fd273ac771c545215a67a9d9c2; ?>
<?php unset($__attributesOriginal30c7f2fd273ac771c545215a67a9d9c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30c7f2fd273ac771c545215a67a9d9c2)): ?>
<?php $component = $__componentOriginal30c7f2fd273ac771c545215a67a9d9c2; ?>
<?php unset($__componentOriginal30c7f2fd273ac771c545215a67a9d9c2); ?>
<?php endif; ?>
                                </div>
                            </main>
                        </div>
                    </div>
                    

                </div>

                <div class="max-w-[300px] space-y-4 md:space-y-6 ml-auto pr-4 lg:pr-6 xl:pr-12">
                    <div class="flex justify-between uppercase">
                        <span><?php echo e(translate('Subtotal')); ?></span>
                        <span><?php echo e(formatPrice($order->amount)); ?></span>
                    </div>

                    <div class="flex justify-between uppercase">
                        <span><?php echo e(translate('TAX')); ?></span>
                        <span><?php echo e(formatPrice($order->tax_amount)); ?></span>
                    </div>
                    <div class="flex justify-between uppercase">
                        <span><?php echo e(translate('Delivery charge')); ?></span>
                        <span><?php echo e(formatPrice($order->shipping_charge_amount)); ?></span>
                    </div>
                    <div class="flex justify-between uppercase">
                        <span><?php echo e(translate('Discount')); ?></span>
                        <span><?php echo e(formatPrice($order->discount_amount)); ?></span>
                    </div>
                    <?php if($order->coupon_id): ?>
                        <div class="flex justify-between uppercase">
                            <span><?php echo e(translate('Coupon Discount')); ?></span>
                            <span><?php echo e(formatPrice($order->coupon_discount_amount)); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="flex justify-between uppercase">
                        <span><?php echo e(translate('Total')); ?></span>
                        <span class="text-base font-bold text-theme-secondary">
                            <?php echo e(formatPrice($order->total_amount)); ?></span>
                    </div>
                    <div class="flex justify-between uppercase">
                        <span><?php echo e(translate('Advance')); ?></span>
                        <span class="text-base font-bold text-green-500">
                            <?php echo e(formatPrice($order->advance_payment)); ?></span>
                    </div>
                    <div class="flex justify-between uppercase">
                        <span><?php echo e(translate('Due')); ?></span>
                        <span class="text-base font-bold text-red-500">
                            <?php echo e(formatPrice($order->total_amount - $order->advance_payment)); ?></span>
                    </div>
                </div>

                <br>
                <br>
            </div>
        </div>

        <div class="col-span-1">
            <div class="card">
                <h4 class="card__title"><?php echo e(translate('Order Updates')); ?></h4>

                
                <div class="card__content py-6">
                    <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['label' => 'Payment Status','name' => 'status','wrapperClass' => 'col-span-1','groupClass' => 'grid-cols-2 mb-2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'update_payment_status']); ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'paid','selected' => ''.e($order->payment_status).'','name' => 'Paid'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'unpaid','selected' => ''.e($order->payment_status).'','name' => 'Unpaid'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['label' => 'Delivery Status','name' => 'status','wrapperClass' => 'col-span-1','groupClass' => 'grid-cols-2 mb-2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'update_delivery_status']); ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'order_placed','selected' => ''.e($order->delivery_status).'','name' => 'Order Placed'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'processing','selected' => ''.e($order->delivery_status).'','name' => 'Processing'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'confirmed','selected' => ''.e($order->delivery_status).'','name' => 'Confirmed'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'shipped','selected' => ''.e($order->delivery_status).'','name' => 'Shipped'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'delivered','selected' => ''.e($order->delivery_status).'','name' => 'Delivered'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'cancelled','selected' => ''.e($order->delivery_status).'','name' => 'Cancelled'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
                </div>

                
                <div class="card__content py-6 border-t border-border">
                    <form action="<?php echo e(route('admin.orders.storeOrderUpdates')); ?>" class="space-y-3" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                        <div>
                            <label class="mb-2.5"><?php echo e(translate('Title')); ?></label>
                            <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => 'status','placeholder' => 'Title'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <label class="mb-2.5"><?php echo e(translate('Text')); ?></label>
                            <?php if (isset($component)) { $__componentOriginale582db01b056b256cb800ff6b8d80bac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale582db01b056b256cb800ff6b8d80bac = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Textarea::resolve(['name' => 'note','placeholder' => 'Text','rows' => '2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $attributes = $__attributesOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__attributesOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $component = $__componentOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__componentOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>
                        </div>

                        <div>
                            <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['type' => 'submit','variant' => 'secondary'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <?php echo e(translate('PUBLISH NOTE')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
                    </form>
                </div>

                
                <h5 class="text-muted my-8"><?php echo e(translate('PREVIOUS NOTES')); ?></h5>
                <div class="flex flex-col">
                    <?php $__currentLoopData = $orderUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="relative flex gap-4 pb-9 [&:last-child>span]:hidden"><span
                                class="absolute left-[5px] z-0 h-full border-l border-border border-dashed"></span>
                            <div><span class="relative w-3 h-3 inline-block rounded-full bg-theme-secondary-light"></span>
                            </div>
                            <div class="grow">
                                <div class="flex items-center justify-between">
                                    <h6 class=" font-public-sans mb-1 capitalize"><?php echo e($note->status); ?></h6>
                                    <?php if($note->type != 'default'): ?>
                                        <a href="javascript:void(0);"
                                            data-href="<?php echo e(route('admin.orders.deleteOrderUpdate', $note->id)); ?>"
                                            data-title="<?php echo e(translate('Are you sure want to delete this item?')); ?>"
                                            data-text="<?php echo e(translate('All data related to this may get deleted.')); ?>"
                                            data-method="POST" data-micromodal-trigger="confirm-modal"
                                            class="text-base text-theme-alert confirm-modal">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>

                                <p class="text-muted text-xs mb-4"><?php echo e($note->note); ?></p>

                                <time class="text-xs">
                                    <?php echo e(date('d M, Y', strtotime($note->created_at))); ?>


                                    <span class="text-muted inline-block ml-1.5 uppercase">
                                        <?php echo e(date('h:i A', strtotime($note->created_at))); ?>

                                    </span>
                                </time>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        "use strict";
        // payment status
        $('#update_payment_status').on('change', function() {
            var order_id = <?php echo e($order->id); ?>;
            var status = $('#update_payment_status').val();
            $.post('<?php echo e(route('admin.orders.updatePaymentStatus')); ?>', {
                _token: '<?php echo e(@csrf_token()); ?>',
                order_id: order_id,
                status: status
            }, function(data) {
                notifyMe('success', '<?php echo e(translate('Payment status has been updated')); ?>');
                window.location.reload();
            });
        });

        // delivery status 
        $('#update_delivery_status').on('change', function() {
            var order_id = <?php echo e($order->id); ?>;
            var status = $('#update_delivery_status').val();
            $.post('<?php echo e(route('admin.orders.updateDeliveryStatus')); ?>', {
                _token: '<?php echo e(@csrf_token()); ?>',
                order_id: order_id,
                status: status
            }, function(data) {
                notifyMe('success', '<?php echo e(translate('Delivery status has been updated')); ?>');
                window.location.reload();
            });
        });
    </script>
    <?php if (isset($component)) { $__componentOriginale1c8e85a0df6127e7f7c482558c957c1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1c8e85a0df6127e7f7c482558c957c1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.inc.update-order-scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inc.update-order-scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1c8e85a0df6127e7f7c482558c957c1)): ?>
<?php $attributes = $__attributesOriginale1c8e85a0df6127e7f7c482558c957c1; ?>
<?php unset($__attributesOriginale1c8e85a0df6127e7f7c482558c957c1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1c8e85a0df6127e7f7c482558c957c1)): ?>
<?php $component = $__componentOriginale1c8e85a0df6127e7f7c482558c957c1; ?>
<?php unset($__componentOriginale1c8e85a0df6127e7f7c482558c957c1); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/orders/show.blade.php ENDPATH**/ ?>