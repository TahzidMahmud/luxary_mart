<div class="modal micromodal-slide" id="purchase-order-payment-modal" aria-hidden="true">
    <div class="modal__overlay" tabindex="-1" data-micromodal-close></div>
    <div class="modal__container" role="dialog" aria-modal="true" aria-labelledby="purchase-order-payment-modal-title">
        <form action="<?php echo e(route(routePrefix() . '.purchase-payments.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input id="purchase-order-payment-modal-method" type="hidden" name="_method" value="">
            <header class="modal__header">
                <h2 class="modal__title">
                    <?php echo e(translate('Make Payment')); ?>

                </h2>
                <button type="button" class="modal__close ms-2" aria-label="Close modal"
                    data-micromodal-close></button>
            </header>
            <main class="modal__content" id="purchase-order-payment-modal-content">
                <p id="purchase-order-payment-modal-text">
                    <input type="hidden" name="payable_id" value="">
                    <input type="hidden" name="payable_type" value="">

                <div class="grid grid-cols-12 gap-4">
                    <div class="col-span-12 md:col-span-6">
                        <?php if (isset($component)) { $__componentOriginal73a08ec365b68163e5a99ef991f25cd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73a08ec365b68163e5a99ef991f25cd2 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Datepicker::resolve(['label' => 'Date','labelInline' => false,'name' => 'date','placeholder' => 'Pick a date','value' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Datepicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73a08ec365b68163e5a99ef991f25cd2)): ?>
<?php $attributes = $__attributesOriginal73a08ec365b68163e5a99ef991f25cd2; ?>
<?php unset($__attributesOriginal73a08ec365b68163e5a99ef991f25cd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73a08ec365b68163e5a99ef991f25cd2)): ?>
<?php $component = $__componentOriginal73a08ec365b68163e5a99ef991f25cd2; ?>
<?php unset($__componentOriginal73a08ec365b68163e5a99ef991f25cd2); ?>
<?php endif; ?>
                    </div>

                    <div class="col-span-12 md:col-span-6">
                        <label class="theme-input-label pt-0 input-required"><?php echo e(translate('Payment Method')); ?></label>
                        <div class="theme-input-wrapper">
                            <select class="theme-input h-auto p-3" name="payment_method">
                                <option value="cash"><?php echo e(translate('Cash')); ?></option>
                                <option value="card"><?php echo e(translate('Card')); ?></option>
                                <option value="bank_transfer"><?php echo e(translate('Bank Transfer')); ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="col-span-12">
                        <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['label' => 'Payable Amount','labelInline' => false,'name' => 'payable_amount','placeholder' => '','value' => '','isRequired' => false,'isDisabled' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
                    </div>

                    <div class="col-span-12">
                        <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['label' => 'Paid Amount','labelInline' => false,'name' => 'paid_amount','placeholder' => '','value' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['step' => '0.001']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
                    </div>

                    <div class="col-span-12">
                        <?php if (isset($component)) { $__componentOriginale582db01b056b256cb800ff6b8d80bac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale582db01b056b256cb800ff6b8d80bac = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Textarea::resolve(['label' => 'Note','labelInline' => false,'name' => 'note','placeholder' => 'Type few words...','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $attributes = $__attributesOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__attributesOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $component = $__componentOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__componentOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>
                    </div>

                </div>
                </p>
            </main>
            <footer class="modal__footer">
                <button type="submit"
                    class="modal__btn modal__btn-success button button--primary"><?php echo e(translate('Continue')); ?></button>
                <button type="button" class="modal__btn ms-3" data-micromodal-close
                    aria-label="Close this dialog window"><?php echo e(translate('Close')); ?></button>
            </footer>
        </form>
    </div>
</div>
<?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/components/backend/modals/purchase-order-payments.blade.php ENDPATH**/ ?>