<div class="modal micromodal-slide" id="seller-payout-modal" aria-hidden="true">
    <div class="modal__overlay" tabindex="-1" data-micromodal-close></div>
    <div class="modal__container" role="dialog" aria-modal="true" aria-labelledby="seller-payout-modal-title">
        <form action="<?php echo e(route('admin.sellers.makePayment')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input id="seller-payout-modal-method" type="hidden" name="_method" value="">
            <header class="modal__header">
                <h2 class="modal__title">
                    <?php echo e(translate('Make Payment')); ?>

                </h2>
                <button type="button" class="modal__close ms-2" aria-label="Close modal"
                    data-micromodal-close></button>
            </header>
            <main class="modal__content" id="seller-payout-modal-content">

                <input type="hidden" name="id" value="">
                <input type="hidden" name="shop_id" value="">
                <div>
                    <table class="w-[350px] my-4">
                        <tbody>
                            <tr
                                class="bg-background-hover border-b border-border transition duration-300 ease-in-out hover:bg-background">

                                <td class="px-2 py-1 whitespace-nowrap text-[13px] font-medium text-foreground">
                                    <?php echo e(translate('Due To Seller')); ?>

                                </td>
                                <td
                                    class="text-[13px] text-end text-foreground font-light px-2 py-1 whitespace-nowrap due">
                                    0
                                </td>
                            </tr>
                            <tr
                                class="bg-background-hover border-b border-border transition duration-300 ease-in-out hover:bg-background">

                                <td class="px-2 py-1 whitespace-nowrap text-[13px] font-medium text-foreground">
                                    <?php echo e(translate('Requested Amount')); ?>

                                </td>
                                <td
                                    class="text-[13px] text-end text-foreground font-light px-2 py-1 whitespace-nowrap demanded">
                                    0
                                </td>
                            </tr>
                            <div class="bank-details hidden">
                                <tr
                                    class="bg-background-hover border-b border-border transition duration-300 ease-in-out hover:bg-background ">

                                    <td class="px-2 py-1 whitespace-nowrap text-[13px] font-medium text-foreground">
                                        <?php echo e(translate('Bank Name')); ?>

                                    </td>
                                    <td
                                        class="text-[13px] text-end text-foreground font-light px-2 py-1 whitespace-nowrap bank-name">
                                    </td>
                                </tr>
                                <tr
                                    class="bg-background-hover border-b border-border transition duration-300 ease-in-out hover:bg-background ">

                                    <td class="px-2 py-1 whitespace-nowrap text-[13px] font-medium text-foreground">
                                        <?php echo e(translate('Bank Acc Name')); ?>

                                    </td>
                                    <td
                                        class="text-[13px] text-end text-foreground font-light px-2 py-1 whitespace-nowrap bank-acc-name">
                                    </td>
                                </tr>
                                <tr
                                    class="bg-background-hover border-b border-border transition duration-300 ease-in-out hover:bg-background ">

                                    <td class="px-2 py-1 whitespace-nowrap text-[13px] font-medium text-foreground">
                                        <?php echo e(translate('Bank Acc Number')); ?>

                                    </td>
                                    <td
                                        class="text-[13px] text-end text-foreground font-light px-2 py-1 whitespace-nowrap bank-acc-no">
                                    </td>
                                </tr>
                                <tr
                                    class="bg-background-hover border-b border-border transition duration-300 ease-in-out hover:bg-background ">

                                    <td class="px-2 py-1 whitespace-nowrap text-[13px] font-medium text-foreground">
                                        <?php echo e(translate('Bank Routing Number')); ?>

                                    </td>
                                    <td
                                        class="text-[13px] text-end text-foreground font-light px-2 py-1 whitespace-nowrap bank-routing-no">
                                    </td>
                                </tr>
                            </div>

                        </tbody>
                    </table>
                </div>

                <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['label' => 'Amount','labelInline' => false,'name' => 'amount','placeholder' => '','value' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['step' => '0.001']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>

                <div class="my-3">
                    <label class="theme-input-label pt-0 input-required"><?php echo e(translate('Payment Method')); ?></label>
                    <div class="theme-input-wrapper">
                        <select class="theme-input h-auto p-3" name="payment_method" required>
                            <option value=""><?php echo e(translate('Select payment method')); ?></option>
                            <option value="cash" class="hidden cash"><?php echo e(translate('Cash')); ?></option>
                            <option value="bank" class="hidden bank"><?php echo e(translate('Bank Transfer')); ?></option>
                        </select>
                    </div>
                </div>

                <div class="payment-details hidden">
                    <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Transaction Id','labelInline' => false,'name' => 'payment_details','placeholder' => '','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                </div>
            </main>
            <footer class="modal__footer">
                <button type="submit"
                    class="modal__btn modal__btn-success button button--primary"><?php echo e(translate('Pay Now')); ?></button>
            </footer>
        </form>
    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/modals/seller-payout.blade.php ENDPATH**/ ?>