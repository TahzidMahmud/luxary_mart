<div class="theme-input-group <?php echo e(!$label ? 'no-label' : ''); ?>">
    <?php if($label): ?>
        <label for="" class="text-foreground">
            <?php echo e(translate($label)); ?>

        </label>
    <?php endif; ?>

    <div class="flex">
        <label
            class="<?php echo e($toggler ? 'theme-checkbox--toggler' : 'theme-checkbox-check'); ?> options <?php echo e('theme-checkbox--' . $variant); ?>">
            <input <?php echo e($attributes->merge(['class' => 'theme-checkbox__input'])); ?> type="checkbox"
                name="<?php echo e($name); ?>" value="<?php echo $value; ?>" <?php if($isChecked): echo 'checked'; endif; ?>
                <?php if($isDisabled): echo 'disabled'; endif; ?> />
            <span class="theme-checkbox__checkmark"></span>
        </label>
    </div>
</div>
<?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/components/backend/inputs/checkbox.blade.php ENDPATH**/ ?>