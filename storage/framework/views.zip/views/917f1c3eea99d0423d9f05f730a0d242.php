<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Brand List')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Brand List')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="#" class="font-bold "><?php echo e(translate('Dashboard')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Brand List')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="grid md:grid-cols-5 gap-3">
        <div class="md:col-span-3">
            <div class="card">
                <div class="card__title border-none">
                    <div class="flex flex-col md:flex-row justify-end gap-3">
                        <?php if (isset($component)) { $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\SearchForm::resolve(['searchKey' => ''.e($searchKey).'','class' => 'max-w-[380px]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\SearchForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $attributes = $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $component = $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
                    </div>
                </div>

                <div class="card__content pt-0">
                    <div class="grid xl:grid-cols-2 gap-3 lg:gap-5">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="py-3 px-4 bg-background-primary-light rounded-md flex items-center gap-3.5 relative">
                                <img src="<?php echo e(uploadedAsset($brand->thumbnail_image)); ?>" alt=""
                                    class="w-[70px] h-[80px] rounded-md"
                                    onerror="this.onerror=null;this.src='<?php echo e(asset('images/image-error.png')); ?>';">

                                <div class="grow">
                                    <h4 class="font-bold"><?php echo e($brand->collectTranslation('name')); ?></h4>
                                    <p class="text-xs mt-1 whitespace-nowrap">
                                        <?php echo e(translate('Total Products')); ?>:
                                        <span class="text-muted ml-0.5"><?php echo e($brand->products_count); ?></span>
                                    </p>
                                </div>

                                <div class="flex gap-3 absolute top-3 right-3">

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_brands')): ?>
                                        <a class="text-stone-300 hover:text-stone-500"
                                            href="<?php echo e(route('admin.brands.edit', ['brand' => $brand->id, 'lang_key' => config('app.default_language')])); ?>&translate">
                                            <i class="fa-regular fa-pen-to-square"></i>
                                        </a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_brands')): ?>
                                        <a class="text-red-400 hover:text-rose-600 confirm-modal" href="javascript:void(0);"
                                            data-href="<?php echo e(route('admin.brands.destroy', $brand->id)); ?>"
                                            data-title="<?php echo e(translate('Are you sure you want to delete this item?')); ?>"
                                            data-text="<?php echo e(translate('All data related to this may get deleted.')); ?>"
                                            data-method="DELETE" data-micromodal-trigger="confirm-modal">
                                            <i class="fa-regular fa-trash-can"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="card__footer pt-0">
                    <?php echo e($brands->links()); ?>

                </div>
            </div>
        </div>
        <div class="md:col-span-2">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_brands')): ?>
                <div class="card">
                    <h4 class="card__title"><?php echo e(translate('Add New Brand')); ?></h4>
                    <div class="card__content">
                        <?php if (isset($component)) { $__componentOriginala9861334c0acb13999a88348f438a546 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9861334c0acb13999a88348f438a546 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\BrandForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.brand-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\BrandForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9861334c0acb13999a88348f438a546)): ?>
<?php $attributes = $__attributesOriginala9861334c0acb13999a88348f438a546; ?>
<?php unset($__attributesOriginala9861334c0acb13999a88348f438a546); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9861334c0acb13999a88348f438a546)): ?>
<?php $component = $__componentOriginala9861334c0acb13999a88348f438a546; ?>
<?php unset($__componentOriginala9861334c0acb13999a88348f438a546); ?>
<?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/brands/index.blade.php ENDPATH**/ ?>