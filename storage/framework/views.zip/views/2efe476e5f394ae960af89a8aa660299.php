<div class="media-manager--wrapper">
    <div class="media-manager__browser active h-full">
        <div class="card__title flex items-center justify-between">
            <h4 class="text-base font-bold">
                <?php echo e(translate('Upload Files')); ?>

            </h4>

            <div class="flex gap-5 items-center">
                <button class="text-lg text-theme-secondary-light md:hidden media-manager__filters--toggler">
                    <i class="fa-regular fa-sliders"></i>
                </button>

                <button class="text-lg toggle-media-manager" data-micromodal-close="media-manager-modal">
                    <i class="fal fa-times"></i>
                </button>
            </div>
        </div>

        <div class="card__content grow flex flex-col">
            <form class="media-manager__filters" id="media-manager__filters">
                <div class="md:hidden bg-theme-primary text-white px-5 py-4 rounded-t-md flex justify-between">
                    <span><?php echo e(translate('FILTER')); ?></span>
                    <button type="button" class="text-white media-manager__filters--toggler">
                        <i class="fa-regular fa-times"></i>
                    </button>
                </div>
                <div class="grow lg:max-w-[250px] px-5 !lg:px-0 xl:px-0">
                    <?php if (isset($component)) { $__componentOriginal0a9614842ee9e3735e691e614c4eb027 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a9614842ee9e3735e691e614c4eb027 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SearchInput::resolve(['name' => 'media_name','placeholder' => 'Search by name'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SearchInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $attributes = $__attributesOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $component = $__componentOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__componentOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>
                </div>

                <div class="flex lg:justify-end max-lg:flex-col lg:items-center gap-4 2xl:gap-10 px-5">
                    <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['name' => 'order','label' => 'Order','wrapperClass' => 'min-w-[160px]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-search' => 'false']); ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'newest','name' => 'Newest to Oldest'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'oldest','name' => 'Oldest to Newest'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'smallest','name' => 'Smallest to Largest'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'largest','name' => 'Largest to Smallest'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['groupClass' => 'lg:max-w-[180px] hidden','name' => 'file-type','label' => 'Type'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-search' => 'false']); ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => 'all','name' => 'All','selected' => 'all'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => '','name' => 'Images','selected' => 'all'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => '','name' => 'Videos','selected' => 'all'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => '','name' => 'Audio','selected' => 'all'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['value' => '','name' => 'Documents','selected' => 'all'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
                </div>
            </form>

            <div class="media-manager">
            </div>
        </div>

        <div class="flex items-center justify-between px-6 py-2 md:py-5 border-b border-[#7878782a]">
            <div class="flex items-center justify-start gap-5 ">
                <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['variant' => 'dark','buttonText' => 'Prev'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'media-manager__pagination--prev']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['buttonText' => 'Next'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'media-manager__pagination--next']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
            </div>

            <div>
                <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['buttonText' => 'Confirm'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'set-files']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
            </div>
        </div>
    </div>

    <div class="media-manager__uploader">
        <div class="card__title flex items-center justify-between">
            <h4 class="text-base font-bold">
                <?php echo e(translate('Upload Files')); ?>

            </h4>

            <button class="text-lg toggle-media-uploader">
                <i class="fal fa-times"></i>
            </button>
        </div>

        <div class="card__content grow min-h-[300px]">
            <div id="uppy-upload-files" class="h-full mx-auto"></div>
        </div>
    </div>
</div>
<?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/components/file-manager/content.blade.php ENDPATH**/ ?>