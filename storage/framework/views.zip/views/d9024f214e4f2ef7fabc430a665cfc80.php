<?php if($labelInline): ?>
    <div
        <?php echo e($attributes->except(['trashParent'])->merge(['class' => 'theme-input-group theme-input--file-upload ' . (!$label ? 'no-label' : '')])); ?>>
    <?php else: ?>
        <div
            <?php echo e($attributes->except(['trashParent'])->merge(['class' => 'theme-input-group theme-input--file-upload !block ' . (!$label ? 'no-label' : '')])); ?>>
<?php endif; ?>
<?php if($label): ?>
    <div>
        <label class="theme-input-label">
            <?php echo e(translate($label)); ?>

        </label>
    </div>
<?php endif; ?>

<div class="theme-input-wrapper">
    <div class="flex">
        <div class="theme-input p-[3px] py-0 flex gap-3 cursor-pointer !ps-0" tabindex="0"
            data-micromodal-trigger="media-manager-modal">
            <div class="px-6 py-3 bg-theme-primary text-white rounded-md rounded-e-none"><?php echo e(translate('BROWSE')); ?></div>
            <span class="media-count py-2 flex items-center text-muted"><?php echo e(translate('No Selected Item')); ?></span>
            <input type="hidden" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" class="hidden"
                <?php echo e($multiple ? 'multiple' : ''); ?> accept="<?php echo e($accept); ?>" value="<?php echo $value; ?>" />
        </div>

        <?php if($trashBtn): ?>
            <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['type' => 'button','variant' => 'light'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-10 h-10 !p-0 flex items-center justify-center ms-1','data-toggle' => 'remove-parent','data-parent' => ''.e($trashParent).'']); ?>
                <i class="text-red-500 fa-solid fa-trash-can"></i>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
    <span class="text-xs text-muted leading-none"><?php echo translate($filesHint); ?></span>

    <div class="file-preview mt-2 flex gap-3 flex-wrap"></div>
</div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/file.blade.php ENDPATH**/ ?>