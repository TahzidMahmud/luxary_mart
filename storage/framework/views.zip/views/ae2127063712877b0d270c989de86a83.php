<?php
    if (isset($productCategories)) {
        $selected = $productCategories->contains($subCategory->id) ? $subCategory->id : null;
    } else {
        $selected = null;
    }
?>

<li class="category <?php echo e(count($subCategory->childrenCategories) > 0 ? 'has-subcategory' : ''); ?>">
    <label class="flex gap-3 items-center">
        <?php if (isset($component)) { $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Checkbox::resolve(['name' => 'category_ids[]','value' => ''.e($subCategory->id).'','isChecked' => ''.e($productCategories->contains($subCategory->id)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'category-selector']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $attributes = $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $component = $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
        <?php echo e($subCategory->collectTranslation('name', $langKey)); ?>

    </label>


    <?php if(count($subCategory->childrenCategories) > 0): ?>
        <button type="button" class="category-toggler">
            <i class="fa-solid fa-chevron-down"></i>
        </button>

        <ul class="pl-5 mt-4 space-y-4">
            <?php $__currentLoopData = $subCategory->childrenCategories()->orderBy('sorting_order_level', 'desc')->where('id', '!=', $category->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $data = [
                        'subCategory' => $childCategory,
                        'langKey' => $langKey,
                    ];

                    if (isset($productCategories)) {
                        $data['productCategories'] = $productCategories;
                    }
                ?>

                <?php echo $__env->make('backend.admin.products.subCategory', $data, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li>
<?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/products/subCategory.blade.php ENDPATH**/ ?>