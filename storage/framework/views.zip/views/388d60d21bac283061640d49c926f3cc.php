<?php if (isset($component)) { $__componentOriginal3565128b8c50044c48921a08ed427585 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3565128b8c50044c48921a08ed427585 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Radio::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Radio::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="<?php echo e($key != 0 ? 'my-4' : ''); ?>">
            <label class="inline-flex gap-3 items-center">
                <?php if (isset($component)) { $__componentOriginal2df452217da52f8f46812ad11781d200 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2df452217da52f8f46812ad11781d200 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\RadioOption::resolve(['name' => 'brand_id','checkedValue' => ''.e($product?->brand_id ?? $selectedBrand).'','value' => ''.e($brand->id).'','label' => ''.e($brand->collectTranslation('name', $langKey)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.radio-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\RadioOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2df452217da52f8f46812ad11781d200)): ?>
<?php $attributes = $__attributesOriginal2df452217da52f8f46812ad11781d200; ?>
<?php unset($__attributesOriginal2df452217da52f8f46812ad11781d200); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2df452217da52f8f46812ad11781d200)): ?>
<?php $component = $__componentOriginal2df452217da52f8f46812ad11781d200; ?>
<?php unset($__componentOriginal2df452217da52f8f46812ad11781d200); ?>
<?php endif; ?>
            </label>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3565128b8c50044c48921a08ed427585)): ?>
<?php $attributes = $__attributesOriginal3565128b8c50044c48921a08ed427585; ?>
<?php unset($__attributesOriginal3565128b8c50044c48921a08ed427585); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3565128b8c50044c48921a08ed427585)): ?>
<?php $component = $__componentOriginal3565128b8c50044c48921a08ed427585; ?>
<?php unset($__componentOriginal3565128b8c50044c48921a08ed427585); ?>
<?php endif; ?>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inc/products/brand-list.blade.php ENDPATH**/ ?>