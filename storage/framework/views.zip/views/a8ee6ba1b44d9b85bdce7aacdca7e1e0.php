<div class="option-dropdown" tabindex="0">
    <div class="option-dropdown__toggler bg-background text-muted">
        <span>
            <img src="<?php echo e(asset("images/flags/$language->flag.png")); ?>" alt="" class="w-[20px]" />
        </span>
        <span><?php echo e($language->name); ?></span>
    </div>

    <div class="option-dropdown__options">
        <ul>
            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href='<?php echo e(url()->current() . '?lang_key=' . $language->code . '&translate'); ?>'
                        class="option-dropdown__option">
                        <span>
                            <img src="<?php echo e(asset("images/flags/$language->flag.png")); ?>" alt="" class="w-[20px]" />
                        </span>
                        <span><?php echo e($language->name); ?></span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/change-languages.blade.php ENDPATH**/ ?>