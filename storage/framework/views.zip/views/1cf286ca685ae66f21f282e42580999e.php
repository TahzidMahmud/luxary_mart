<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Product Real Pictures')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Real Pictures')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="font-bold "><?php echo e(translate('Dashboard')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="font-bold "><?php echo e(translate('Products')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Real Pictures')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <!-- start::product-form -->
    <div class="grid grid-cols-12 md:grid-cols-3 lg:grid-cols-4 gap-3">
        <?php
            $galleryImages = collect();
            if (!is_null($product->real_pictures)) {
                $galleryImages = explode(',', $product->real_pictures);
            }
        ?>

        <?php $__currentLoopData = $galleryImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(uploadedAsset($image)); ?>" download="<?php echo e($image); ?>"><img src="<?php echo e(uploadedAsset($image)); ?>"
                    alt=""></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- end::product-form -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/products/pictures.blade.php ENDPATH**/ ?>