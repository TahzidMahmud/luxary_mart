<nav class="h-[75px] 2xl:h-[103px] flex items-center">
    <div class="px-[15px] lg:px-[50px] flex-grow flex items-center justify-between gap-10">
        <div class="flex items-center grow gap-14">
            <div class="flex items-center gap-7">
                <button
                    class="sidebar-toggler text-lg sm:text-2xl w-10 h-10 flex items-center justify-center rounded-md text-theme-secondary">
                    <i class="fa-regular fa-bars"></i>
                </button>
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <img src="<?php echo e(uploadedAsset(getSetting('websiteHeaderLogo'))); ?>" class="max-h-[60px]" alt="EpikCart"
                        onerror="this.onerror=null;this.src='<?php echo e(asset('images/image-error.png')); ?>';" />
                </a>
            </div>

            <div class="flex items-center grow gap-5">
                <a href="<?php echo e(env('APP_URL')); ?>" target="_blank"
                    class="whitespace-nowrap h-10 max-lg:hidden inline-flex items-center gap-2 bg-theme-primary text-white rounded-md px-4 font-bold">
                    <span>
                        <i class="fa-light fa-globe-pointer"></i>
                    </span>
                    <span><?php echo e(translate('Browse')); ?></span>
                </a>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clear_cache')): ?>
                    <a href="<?php echo e(route('admin.clearCache')); ?>"
                        class="whitespace-nowrap h-10 max-2xl:hidden inline-flex items-center gap-2 bg-theme-secondary/10 text-theme-secondary rounded-md px-4">
                        <span>
                            <i class="fa-light fa-bin-recycle"></i>
                        </span>
                        <span><?php echo e(translate('Clear Cache')); ?></span>
                    </a>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('search')): ?>
                    <!-- start::search box and suggestions -->
                    <div class="group relative max-xl:hidden w-full max-lg:max-w-[250px] max-w-[420px]" tabindex="0">
                        <?php if (isset($component)) { $__componentOriginal0a9614842ee9e3735e691e614c4eb027 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a9614842ee9e3735e691e614c4eb027 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SearchInput::resolve(['class' => 'sm:!max-w-none navbar-search-input','name' => 'search','placeholder' => 'Search','value' => ''.e(Request::get('search')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SearchInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $attributes = $__attributesOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $component = $__componentOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__componentOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>

                        <div
                            class="absolute z-[1] bg-popover text-popover-foreground rounded-md right-0 top-[calc(100%+38px)] w-full min-w-[300px] shadow-theme max-h-[440px] overflow-y-auto p-[2px] divide-y divide-border opacity-0 invisible group-focus-within:opacity-100 group-focus-within:visible transition-all duration-300 navbar-search">
                            <?php echo $__env->make('components.backend.inc.navbar-search', [
                                'products' => collect(),
                                'orders' => collect(),
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <!-- start::search box and suggestions -->
                <?php endif; ?>

            </div>
        </div>

        <div class="flex items-center flex-shrink-0 gap-4">
            <div class="option-dropdown max-xl:hidden" tabindex="0">
                <div class="option-dropdown__toggler">
                    <span class="text-xl">
                        <i class="fal fa-plus"></i>
                    </span>
                    <span><?php echo e(translate('ADD NEW')); ?></span>
                </div>

                <div class="option-dropdown__options">
                    <ul>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_products')): ?>
                            <li>
                                <a href="<?php echo e(route('admin.products.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Product')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_purchase_orders')): ?>
                            <li>
                                <a href="<?php echo e(route('admin.purchase-orders.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Purchase Order')); ?></a>
                            </li>
                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_stock_adjustment')): ?>
                            <li>
                                <a href="<?php echo e(route('admin.stockAdjustments.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Stock Adjustment')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_stock_transfer')): ?>
                            <li>
                                <a href="<?php echo e(route('admin.stockTransfers.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Stock Transfer')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_suppliers')): ?>
                            <li>
                                <a href="<?php echo e(route('admin.suppliers.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Supplier')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_coupons')): ?>
                            <li>
                                <a href="<?php echo e(route('admin.coupons.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Coupon')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_campaigns')): ?>
                            <li>
                                <a href="<?php echo e(route('admin.campaigns.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Campaign')); ?></a>
                            </li>
                        <?php endif; ?>

                    </ul>
                </div>
            </div>

            <?php
                if (Session::has('locale')) {
                    $locale = Session::get('locale', Config::get('app.locale'));
                } else {
                    $locale = env('DEFAULT_LANGUAGE');
                }

                $currentLanguage = \App\Models\Language::where('code', $locale)->first();

                if (is_null($currentLanguage)) {
                    $currentLanguage = \App\Models\Language::where('code', 'en-US')->first();
                }
            ?>

            <div class="option-dropdown max-xl:hidden" tabindex="0">
                <div class="option-dropdown__toggler bg-background text-muted">
                    <span>
                        <img src="<?php echo e(asset('images/flags/' . $currentLanguage->flag . '.png')); ?>" alt=""
                            class="w-[20px]" />
                    </span>
                    <span><?php echo e($currentLanguage->name); ?></span>
                </div>

                <div class="option-dropdown__options">
                    <ul>
                        <?php $__currentLoopData = \App\Models\Language::where('is_active', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="javascript:void(0);"
                                    class="option-dropdown__option <?php if($currentLanguage->code == $language->code): ?> active <?php endif; ?>"
                                    onclick="changeLocaleLanguage(this)" data-flag="<?php echo e($language->code); ?>">
                                    <span>
                                        <img src="<?php echo e(asset('images/flags/' . $language->flag . '.png')); ?>"
                                            alt="" class="w-[20px]" />
                                    </span>
                                    <span><?php echo e($language->name); ?></span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="button button--light h-12 w-12 text-foreground text-xl justify-center toggle-theme-btn">
                <i class="fa-light fa-sun-bright"></i>
            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_notifications')): ?>
                <div class="group relative max-md:hidden" tabindex="0">
                    <button class="text-theme-primary text-xl relative w-12 h-12 flex items-center justify-center">
                        <i class="fa-regular fa-bell"></i>
                        <span
                            class="absolute top-6 left-7 w-[17px] h-[17px] flex items-center justify-center bg-red-500 text-white text-[9px] rounded-full">
                            <?php echo e(\App\Models\Notification::where(function ($q) {
                                $q->where('for', 'admin')->orWhere('shop_id', shopId());
                            })->where('is_read', 0)->count()); ?>

                        </span>
                    </button>

                    <!-- notifications -->
                    <div
                        class="absolute z-[1] bg-background rounded-md right-0 top-[calc(100%+35px)] min-w-[300px] shadow-theme divide-y divide-[#78787829] max-h-[440px] overflow-y-auto opacity-0 invisible group-focus-within:opacity-100 group-focus-within:visible transition-all duration-300">
                        <div class="flex items-center justify-between px-7 py-[30px]">
                            <span class="font-bold"><?php echo e(translate('Notifications')); ?></span>
                            <a href="<?php echo e(route('admin.notifications.markRead')); ?>"
                                class="text-theme-secondary"><?php echo e(translate('Mark all as read')); ?></a>
                        </div>

                        <?php
                            $notifications = \App\Models\Notification::where('for', 'admin')
                                ->orWhere('shop_id', shopId())
                                ->latest()
                                ->take(4)
                                ->get();
                        ?>
                        <ul class="divide-y divide-[#78787829]">
                            <?php if(count($notifications) > 0): ?>
                                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(getNotificationLink($notification)); ?>"
                                            class="text-[13px] flex items-center px-[25px] py-[15px] gap-[14px] <?php echo e($notification->is_read ? '' : 'bg-orange-50/50'); ?>">
                                            <div>
                                                <span
                                                    class="w-[27px] aspect-square <?php echo e(getNotificationIcon($notification, 'class')); ?> inline-flex items-center justify-center rounded-full">
                                                    <i class="<?php echo e(getNotificationIcon($notification)); ?>"></i>
                                                </span>
                                            </div>
                                            <div>
                                                <h5 class="truncate">
                                                    <?php echo e(getNotificationText($notification)); ?>

                                                </h5>
                                                <div class="flex items-center text-muted">
                                                    <span
                                                        class="truncate"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                                                    <span
                                                        class="ml-[9px] mr-[7px] h-[5px] w-[5px] rounded-full bg-theme-secondary"></span>
                                                    <span class="capitalize truncate"><?php echo e($notification->type); ?></span>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="text-center py-5">
                                    <?php echo e(translate('No Notifications')); ?>

                                </div>
                            <?php endif; ?>
                        </ul>

                        <div class="px-[22px] py-[18px] text-right">
                            <a href="<?php echo e(route('admin.notifications')); ?>"
                                class="text-theme-secondary inline-block"><?php echo e(translate('View All')); ?></a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="group relative" tabindex="0">
                <div class="flex items-center gap-2 cursor-pointer">
                    <?php
                        $user = user();
                    ?>
                    <div class="text-right leading-[1.3] hidden xl:block">
                        <h4 class="text-foreground font-bold">
                            <?php echo e($user->name); ?>

                        </h4>
                        <p class="text-[13px] text-muted">
                            <?php echo e($user->user_type); ?>

                        </p>
                    </div>
                    <div>
                        <img src="<?php echo e(uploadedAsset($user->avatar)); ?>" alt="" class="w-10 h-10 rounded-full"
                            onerror="this.onerror=null;this.src='<?php echo e(asset('images/image-error.png')); ?>';" />
                    </div>
                </div>

                <ul
                    class="absolute z-[1] bg-background text-foreground rounded-md right-0 top-[calc(100%+38px)] min-w-[150px] shadow-theme overflow-y-auto p-[2px] divide-y divide-[#78787829] opacity-0 invisible group-focus-within:opacity-100 group-focus-within:visible transition-all duration-300">
                    <li>
                        <a href="<?php echo e(route('profile.edit')); ?>"
                            class="group/item px-5 py-1 flex gap-3 items-center text-xs font-medium hover:bg-theme-secondary/10 transition-all rounded-md">
                            <span class="text-base text-theme-secondary">
                                <i class="fa-regular fa-pen-to-square"></i>
                            </span>
                            <span class="group-hover/item:text-theme-secondary"><?php echo e(translate('Profile')); ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('logout')); ?>"
                            class="group/item px-5 py-1 flex gap-3 items-center text-xs font-medium hover:bg-red-500/5 transition-all rounded-md">
                            <span class="text-base text-red-500">
                                <i class="fa-regular fa-power-off"></i>
                            </span>
                            <span class="group-hover/item:text-red-500"><?php echo e(translate('Log Out')); ?></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inc/navbar.blade.php ENDPATH**/ ?>