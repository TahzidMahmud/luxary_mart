<div class="<?php echo e($labelInline ? 'theme-input-group' : ''); ?>  <?php echo e(!$label ? 'no-label' : ''); ?>">
    <?php if($label): ?>
        <label for="<?php echo e($name); ?>"
            class="theme-input-label <?php echo e($labelInline ? '' : 'pt-0'); ?> <?php echo e($isRequired ? 'input-required' : ''); ?>">
            <?php echo e(translate($label)); ?>

        </label>
    <?php endif; ?>

    <div class="theme-input-wrapper flex gap-3 <?php echo e($label ? '' : 'col-span-4'); ?>">
        <textarea class="theme-input theme-textarea <?php echo e($rich ? 'jodit-editor' : ''); ?>" placeholder="<?php echo e(translate($placeholder)); ?>"
            rows="<?php echo e($rows); ?>" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" <?php if(!$rich && $isRequired): echo 'required'; endif; ?>
            <?php if($isDisabled): echo 'disabled'; endif; ?>><?php echo $value; ?></textarea>
        <?php if($aiGenerate): ?>
            <div>
                <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['type' => 'button'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '!bg-[#8952FF] w-10 h-10 !p-0 flex items-center justify-center','id' => 'generate-'.e($name).'','onclick' => 'generateOpenAIContent(\''.e($name).'\')']); ?>
                    <i class="fa-solid fa-wand-magic-sparkles"></i>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/components/backend/inputs/textarea.blade.php ENDPATH**/ ?>