<div class="theme-input-group <?php echo e(!$label ? 'no-label' : ''); ?>">
    <?php if($label): ?>
        <label for="<?php echo e($name); ?>" class="theme-input-label">
            <?php echo e(translate($label)); ?>

        </label>
    <?php endif; ?>

    <div class="gap-3">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/radio.blade.php ENDPATH**/ ?>