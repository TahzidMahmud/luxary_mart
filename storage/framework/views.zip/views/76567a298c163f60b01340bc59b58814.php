<div class="theme-input-group <?php echo e(!$label ? 'no-label' : ''); ?>">
    <?php if($label): ?>
        <label for="<?php echo e($name); ?>" class="theme-input-label <?php echo e($isRequired ? 'input-required' : ''); ?>">
            <?php echo e(translate($label)); ?>

        </label>
    <?php endif; ?>

    <div class="theme-input-wrapper">
        <input type="color" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
            <?php echo e($attributes->merge(['class' => 'w-full h-full p-2 rounded'])); ?>

            placeholder="<?php echo e(translate($placeholder)); ?>" value="<?php echo $value; ?>" <?php if($isRequired): echo 'required'; endif; ?>
            <?php if($isDisabled): echo 'disabled'; endif; ?> />
    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/color.blade.php ENDPATH**/ ?>