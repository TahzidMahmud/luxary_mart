<label class="theme-radio options">
    <input type="<?php echo e($type); ?>" class="theme-radio__input" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>"
        <?php if($value == $checkedValue): echo 'checked'; endif; ?> />
    <span class="theme-radio__checkmark"></span>
    <span class="theme-radio__text text-sm"><?php echo $label; ?></span>
</label>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/radio-option.blade.php ENDPATH**/ ?>