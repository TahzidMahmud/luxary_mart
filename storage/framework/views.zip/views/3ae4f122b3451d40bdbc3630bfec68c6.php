<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Categories')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Category List')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.categories.index')); ?>" class="font-bold "> <?php echo e(translate('Categories')); ?></a>

            <?php if($parentCategory): ?>
                <span class="text-theme-primary">
                    <i class="fa-solid fa-chevron-right"></i>
                </span>
                <a href="?parent_id=<?php echo e($parentCategory->id); ?>" class="text-muted">
                    <?php echo e($parentCategory->collectTranslation('name')); ?></a>
            <?php endif; ?>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="card">
        <div class="card__title theme-table__filter flex flex-col md:flex-row xl:items-center justify-between gap-3">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_categories')): ?>
                <?php if (isset($component)) { $__componentOriginaldbabb662c3b9843f55fe55cc2492a70a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Link::resolve(['href' => ''.e(route('admin.categories.create')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <span class="text-xl">
                        <i class="fal fa-plus"></i>
                    </span> <?php echo e(translate('Add New')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a)): ?>
<?php $attributes = $__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a; ?>
<?php unset($__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbabb662c3b9843f55fe55cc2492a70a)): ?>
<?php $component = $__componentOriginaldbabb662c3b9843f55fe55cc2492a70a; ?>
<?php unset($__componentOriginaldbabb662c3b9843f55fe55cc2492a70a); ?>
<?php endif; ?>
            <?php else: ?>
                <div></div>
            <?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\SearchForm::resolve(['searchKey' => ''.e($searchKey).'','class' => 'max-w-[380px]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\SearchForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if($parentCategory): ?>
                    <input type="hidden" name="parent_id" value="<?php echo e($parentCategory->id); ?>" />
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $attributes = $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $component = $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
        </div>

        <div class="card__content">
            <div class="mb-3 flex items-center gap-3 text-xs">
                <a href="<?php echo e(route('admin.categories.index')); ?>" class="flex items-center gap-2 text-muted">
                    <span class="text-theme-secondary-light">
                        <i class="fa-solid fa-house-chimney"></i>
                    </span>
                    <span><?php echo e(translate('Main Categories')); ?></span>
                </a>

                <?php if($parentCategory): ?>
                    <span class="text-muted">
                        <i class="fa-solid fa-angle-right"></i>
                    </span>
                    <a href="?parent_id=<?php echo e($parentCategory->id); ?>" class="flex items-center gap-1">
                        <?php echo e($parentCategory->collectTranslation('name')); ?>

                    </a>
                <?php endif; ?>

            </div>

            <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-3 lg:gap-5">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-background-primary-light rounded-md py-5 px-7">
                        <div class="flex items-center gap-2.5">
                            <div>
                                <img src="<?php echo e(uploadedAsset($category->collectTranslation('thumbnail_image'))); ?>"
                                    alt=""
                                    class="w-10 lg:w-12 aspect-square rounded-full border border-theme-secondary-light"
                                    onerror="this.onerror=null;this.src='<?php echo e(asset('images/image-error.png')); ?>';" />
                            </div>

                            <div class="grow leading-tight">
                                <?php if($parentCategory): ?>
                                    <p class="text-muted"><?php echo e($parentCategory->collectTranslation('name')); ?>

                                    </p>
                                <?php endif; ?>
                                <h4 class="uppercase font-medium"><?php echo e($category->collectTranslation('name')); ?></h4>
                            </div>

                            <div class="flex gap-3">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_categories')): ?>
                                    <a class="text-stone-300 hover:text-stone-500"
                                        href="<?php echo e(route('admin.categories.edit', ['category' => $category->id, 'lang_key' => config('app.default_language')])); ?>&translate">
                                        <i class="fa-regular fa-pen-to-square"></i></a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_categories')): ?>
                                    <a class="text-red-400 hover:text-rose-600 confirm-modal" href="javascript:void(0);"
                                        data-href="<?php echo e(route('admin.categories.destroy', $category->id)); ?>"
                                        data-title="<?php echo e(translate('Are you sure you want to delete this item?')); ?>"
                                        data-text="<?php echo e(translate('All data related to this may get deleted.')); ?>"
                                        data-method="DELETE" data-micromodal-trigger="confirm-modal">
                                        <i class="fa-regular fa-trash-can"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="flex justify-between mt-4">
                            <span>
                                <?php echo e(translate('Serial')); ?>:
                                <span class="text-muted"><?php echo e($category->sorting_order_level); ?></span>
                            </span>

                            <span>
                                <a <?php if($category->children_categories_count): ?> href="?parent_id=<?php echo e($category->id); ?>" <?php endif; ?>>
                                    <?php echo e(translate('Sub-categories')); ?>

                                    <span class="text-muted">(<?php echo e($category->children_categories_count); ?>)</span>
                                </a>
                            </span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="card__footer pt-0">
            <?php echo e($categories->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/categories/index.blade.php ENDPATH**/ ?>