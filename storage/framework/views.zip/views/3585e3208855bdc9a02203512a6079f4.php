<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Dashboard')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_dashboard')): ?>
    <?php $__env->startSection('content'); ?>
        <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
            <div class="flex items-center">
                <span class="text-xl mr-3 text-theme-secondary">
                    <i class="fa-light fa-chart-mixed"></i>
                </span>
                <span class="text-sm sm:text-base font-bold"><?php echo e(translate('Admin Dashboard')); ?></span>
            </div>
        </div>

        <div id="app"></div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
        <script>
            window.config = <?php echo json_encode($settings, 15, 512) ?>;
        </script>

        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/backend/dashboard/index.tsx']); ?>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/backend/admin/dashboard/index.blade.php ENDPATH**/ ?>