<!DOCTYPE html>
<html lang="en" class="dark">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Favicon -->
    <link rel="icon" sizes="16x16" href="<?php echo e(uploadedAsset(getSetting('favicon'))); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- css -->
    <?php if (isset($component)) { $__componentOriginal1d12a4f89dcd45d78ec9ecda59b92c58 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1d12a4f89dcd45d78ec9ecda59b92c58 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.inc.styles','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inc.styles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1d12a4f89dcd45d78ec9ecda59b92c58)): ?>
<?php $attributes = $__attributesOriginal1d12a4f89dcd45d78ec9ecda59b92c58; ?>
<?php unset($__attributesOriginal1d12a4f89dcd45d78ec9ecda59b92c58); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1d12a4f89dcd45d78ec9ecda59b92c58)): ?>
<?php $component = $__componentOriginal1d12a4f89dcd45d78ec9ecda59b92c58; ?>
<?php unset($__componentOriginal1d12a4f89dcd45d78ec9ecda59b92c58); ?>
<?php endif; ?>

    <!-- header js -->
    <script>
        "use strict";
        const ATE = {};
        window.backendApiUrl = "<?php echo e(adminApiUrl()); ?>";
        window.urlType = "admin";

        // dark / light theme 
        // On page load or when changing themes, best to add inline in `head` to avoid FOUC
        const setupSystemTheme = () => {
            if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia(
                    '(prefers-color-scheme: dark)').matches)) {
                document.documentElement.classList.add('dark')
            } else {
                document.documentElement.classList.remove('dark')
            }
        }
        setupSystemTheme()

        document.addEventListener('click', function(e) {
            const toggler = e.target.closest('.toggle-theme-btn');
            if (!toggler) return

            var theme = document.documentElement.classList.contains('dark') ? 'light' : 'dark'

            document.documentElement.classList.toggle('dark')
            localStorage.theme = theme
        })
    </script>

</head>

<body>
    <div class="flex flex-col">
        <!-- start::navbar -->
        <?php if (isset($component)) { $__componentOriginal340660dd72e5591ea41ca0b60f329ca0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal340660dd72e5591ea41ca0b60f329ca0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.inc.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inc.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal340660dd72e5591ea41ca0b60f329ca0)): ?>
<?php $attributes = $__attributesOriginal340660dd72e5591ea41ca0b60f329ca0; ?>
<?php unset($__attributesOriginal340660dd72e5591ea41ca0b60f329ca0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal340660dd72e5591ea41ca0b60f329ca0)): ?>
<?php $component = $__componentOriginal340660dd72e5591ea41ca0b60f329ca0; ?>
<?php unset($__componentOriginal340660dd72e5591ea41ca0b60f329ca0); ?>
<?php endif; ?>
        <!-- end::navbar -->

        <div class="pt-[10px] h-[calc(100vh-78px)] md:h-[calc(100vh-103px)] flex bg-background-primary-light">
            <div>
                <!-- start::sidebar -->
                <?php if (isset($component)) { $__componentOriginald76a9b1c07917585db6c35290b76ba1d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald76a9b1c07917585db6c35290b76ba1d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.inc.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inc.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald76a9b1c07917585db6c35290b76ba1d)): ?>
<?php $attributes = $__attributesOriginald76a9b1c07917585db6c35290b76ba1d; ?>
<?php unset($__attributesOriginald76a9b1c07917585db6c35290b76ba1d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald76a9b1c07917585db6c35290b76ba1d)): ?>
<?php $component = $__componentOriginald76a9b1c07917585db6c35290b76ba1d; ?>
<?php unset($__componentOriginald76a9b1c07917585db6c35290b76ba1d); ?>
<?php endif; ?>
                <!-- end::sidebar -->
            </div>

            <!-- start::main content -->
            <div class="flex-grow overflow-y-auto px-4 md:px-8 xl:px-12 pb-[100px] lg:pb-10 <?php echo $__env->yieldContent('p-class'); ?>">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- end::main content -->

            <!-- start::modals -->
            <?php if (isset($component)) { $__componentOriginal760ebacd6c61b76e0bcbded36982c5ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal760ebacd6c61b76e0bcbded36982c5ac = $attributes; } ?>
<?php $component = App\View\Components\Backend\Modals\Confirm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.confirm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Modals\Confirm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal760ebacd6c61b76e0bcbded36982c5ac)): ?>
<?php $attributes = $__attributesOriginal760ebacd6c61b76e0bcbded36982c5ac; ?>
<?php unset($__attributesOriginal760ebacd6c61b76e0bcbded36982c5ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal760ebacd6c61b76e0bcbded36982c5ac)): ?>
<?php $component = $__componentOriginal760ebacd6c61b76e0bcbded36982c5ac; ?>
<?php unset($__componentOriginal760ebacd6c61b76e0bcbded36982c5ac); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal2cacee8a509b65165ec597d3342a4f07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cacee8a509b65165ec597d3342a4f07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.purchase-order-payments','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.purchase-order-payments'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cacee8a509b65165ec597d3342a4f07)): ?>
<?php $attributes = $__attributesOriginal2cacee8a509b65165ec597d3342a4f07; ?>
<?php unset($__attributesOriginal2cacee8a509b65165ec597d3342a4f07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cacee8a509b65165ec597d3342a4f07)): ?>
<?php $component = $__componentOriginal2cacee8a509b65165ec597d3342a4f07; ?>
<?php unset($__componentOriginal2cacee8a509b65165ec597d3342a4f07); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalefa8ffb754b0792ffc46feb5d555d9b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalefa8ffb754b0792ffc46feb5d555d9b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.purchase-order-payment-histories','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.purchase-order-payment-histories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalefa8ffb754b0792ffc46feb5d555d9b3)): ?>
<?php $attributes = $__attributesOriginalefa8ffb754b0792ffc46feb5d555d9b3; ?>
<?php unset($__attributesOriginalefa8ffb754b0792ffc46feb5d555d9b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalefa8ffb754b0792ffc46feb5d555d9b3)): ?>
<?php $component = $__componentOriginalefa8ffb754b0792ffc46feb5d555d9b3; ?>
<?php unset($__componentOriginalefa8ffb754b0792ffc46feb5d555d9b3); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal1a0ac2babe6214cff86396e059a4f583 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a0ac2babe6214cff86396e059a4f583 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.order-address','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.order-address'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a0ac2babe6214cff86396e059a4f583)): ?>
<?php $attributes = $__attributesOriginal1a0ac2babe6214cff86396e059a4f583; ?>
<?php unset($__attributesOriginal1a0ac2babe6214cff86396e059a4f583); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a0ac2babe6214cff86396e059a4f583)): ?>
<?php $component = $__componentOriginal1a0ac2babe6214cff86396e059a4f583; ?>
<?php unset($__componentOriginal1a0ac2babe6214cff86396e059a4f583); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal28d93d90de3d9f40aed36f27cc642550 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28d93d90de3d9f40aed36f27cc642550 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.category-create','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.category-create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28d93d90de3d9f40aed36f27cc642550)): ?>
<?php $attributes = $__attributesOriginal28d93d90de3d9f40aed36f27cc642550; ?>
<?php unset($__attributesOriginal28d93d90de3d9f40aed36f27cc642550); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28d93d90de3d9f40aed36f27cc642550)): ?>
<?php $component = $__componentOriginal28d93d90de3d9f40aed36f27cc642550; ?>
<?php unset($__componentOriginal28d93d90de3d9f40aed36f27cc642550); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale5af2e7aca3fda8198f40d4f3b3b18f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5af2e7aca3fda8198f40d4f3b3b18f4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.brand-create','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.brand-create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5af2e7aca3fda8198f40d4f3b3b18f4)): ?>
<?php $attributes = $__attributesOriginale5af2e7aca3fda8198f40d4f3b3b18f4; ?>
<?php unset($__attributesOriginale5af2e7aca3fda8198f40d4f3b3b18f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5af2e7aca3fda8198f40d4f3b3b18f4)): ?>
<?php $component = $__componentOriginale5af2e7aca3fda8198f40d4f3b3b18f4; ?>
<?php unset($__componentOriginale5af2e7aca3fda8198f40d4f3b3b18f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf74da9801b977f82d709534fb5a5c1ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf74da9801b977f82d709534fb5a5c1ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.unit-create','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.unit-create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf74da9801b977f82d709534fb5a5c1ac)): ?>
<?php $attributes = $__attributesOriginalf74da9801b977f82d709534fb5a5c1ac; ?>
<?php unset($__attributesOriginalf74da9801b977f82d709534fb5a5c1ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf74da9801b977f82d709534fb5a5c1ac)): ?>
<?php $component = $__componentOriginalf74da9801b977f82d709534fb5a5c1ac; ?>
<?php unset($__componentOriginalf74da9801b977f82d709534fb5a5c1ac); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal5c00d0f1d83c2ba4e54f7f5876c12a69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c00d0f1d83c2ba4e54f7f5876c12a69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.tag-create','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.tag-create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c00d0f1d83c2ba4e54f7f5876c12a69)): ?>
<?php $attributes = $__attributesOriginal5c00d0f1d83c2ba4e54f7f5876c12a69; ?>
<?php unset($__attributesOriginal5c00d0f1d83c2ba4e54f7f5876c12a69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c00d0f1d83c2ba4e54f7f5876c12a69)): ?>
<?php $component = $__componentOriginal5c00d0f1d83c2ba4e54f7f5876c12a69; ?>
<?php unset($__componentOriginal5c00d0f1d83c2ba4e54f7f5876c12a69); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala7689bfd0bb4cef64dec66e51d181409 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7689bfd0bb4cef64dec66e51d181409 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.badge-create','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.badge-create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7689bfd0bb4cef64dec66e51d181409)): ?>
<?php $attributes = $__attributesOriginala7689bfd0bb4cef64dec66e51d181409; ?>
<?php unset($__attributesOriginala7689bfd0bb4cef64dec66e51d181409); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7689bfd0bb4cef64dec66e51d181409)): ?>
<?php $component = $__componentOriginala7689bfd0bb4cef64dec66e51d181409; ?>
<?php unset($__componentOriginala7689bfd0bb4cef64dec66e51d181409); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal8fb0fdb7f68cbd91f6f69500f0b058c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8fb0fdb7f68cbd91f6f69500f0b058c2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.seller-payout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.seller-payout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8fb0fdb7f68cbd91f6f69500f0b058c2)): ?>
<?php $attributes = $__attributesOriginal8fb0fdb7f68cbd91f6f69500f0b058c2; ?>
<?php unset($__attributesOriginal8fb0fdb7f68cbd91f6f69500f0b058c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8fb0fdb7f68cbd91f6f69500f0b058c2)): ?>
<?php $component = $__componentOriginal8fb0fdb7f68cbd91f6f69500f0b058c2; ?>
<?php unset($__componentOriginal8fb0fdb7f68cbd91f6f69500f0b058c2); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalfb7fec8d48a93d690fd3bc2700cfaa8f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfb7fec8d48a93d690fd3bc2700cfaa8f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.modals.media-info','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.modals.media-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfb7fec8d48a93d690fd3bc2700cfaa8f)): ?>
<?php $attributes = $__attributesOriginalfb7fec8d48a93d690fd3bc2700cfaa8f; ?>
<?php unset($__attributesOriginalfb7fec8d48a93d690fd3bc2700cfaa8f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfb7fec8d48a93d690fd3bc2700cfaa8f)): ?>
<?php $component = $__componentOriginalfb7fec8d48a93d690fd3bc2700cfaa8f; ?>
<?php unset($__componentOriginalfb7fec8d48a93d690fd3bc2700cfaa8f); ?>
<?php endif; ?>
            <!-- end::modals -->

            <!-- start::footer -->
            <?php if (isset($component)) { $__componentOriginal430b13eacc09563b7351f0959d91af4d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal430b13eacc09563b7351f0959d91af4d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.inc.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inc.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal430b13eacc09563b7351f0959d91af4d)): ?>
<?php $attributes = $__attributesOriginal430b13eacc09563b7351f0959d91af4d; ?>
<?php unset($__attributesOriginal430b13eacc09563b7351f0959d91af4d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal430b13eacc09563b7351f0959d91af4d)): ?>
<?php $component = $__componentOriginal430b13eacc09563b7351f0959d91af4d; ?>
<?php unset($__componentOriginal430b13eacc09563b7351f0959d91af4d); ?>
<?php endif; ?>
            <!-- end::footer -->
        </div>
    </div>

    <!-- file manager modal -->
    <div class="modal micromodal-slide media-manager-modal" id="media-manager-modal" aria-hidden="true">
        <div class="modal__overlay" tabindex="-1" data-micromodal-close></div>
        <div class="modal__container" role="dialog" aria-modal="true" aria-labelledby="media manager">
            <?php if (isset($component)) { $__componentOriginal70281eb1c6e546e031cb8a3b9ef7232d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70281eb1c6e546e031cb8a3b9ef7232d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.file-manager.content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-manager.content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70281eb1c6e546e031cb8a3b9ef7232d)): ?>
<?php $attributes = $__attributesOriginal70281eb1c6e546e031cb8a3b9ef7232d; ?>
<?php unset($__attributesOriginal70281eb1c6e546e031cb8a3b9ef7232d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70281eb1c6e546e031cb8a3b9ef7232d)): ?>
<?php $component = $__componentOriginal70281eb1c6e546e031cb8a3b9ef7232d; ?>
<?php unset($__componentOriginal70281eb1c6e546e031cb8a3b9ef7232d); ?>
<?php endif; ?>
        </div>
    </div>

    <!-- start::mobile search box -->
    <div class="mobile-search-box">
        <?php if (isset($component)) { $__componentOriginal0a9614842ee9e3735e691e614c4eb027 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a9614842ee9e3735e691e614c4eb027 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SearchInput::resolve(['name' => 'search','placeholder' => 'Search for anything','class' => 'navbar-search-input'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SearchInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $attributes = $__attributesOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $component = $__componentOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__componentOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>

        <div class="navbar-search">
            <?php echo $__env->make('components.backend.inc.navbar-search', [
                'products' => collect(),
                'orders' => collect(),
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <!-- end::mobile search box -->

    <div class="overlay"></div>

    <!-- scripts -->
    <?php if (isset($component)) { $__componentOriginal043a5032571e5859b220ab3b252c8fcc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal043a5032571e5859b220ab3b252c8fcc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.inc.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inc.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal043a5032571e5859b220ab3b252c8fcc)): ?>
<?php $attributes = $__attributesOriginal043a5032571e5859b220ab3b252c8fcc; ?>
<?php unset($__attributesOriginal043a5032571e5859b220ab3b252c8fcc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal043a5032571e5859b220ab3b252c8fcc)): ?>
<?php $component = $__componentOriginal043a5032571e5859b220ab3b252c8fcc; ?>
<?php unset($__componentOriginal043a5032571e5859b220ab3b252c8fcc); ?>
<?php endif; ?>

    <!-- file manager -->
    <?php if (isset($component)) { $__componentOriginal3519f05a2f4c379b90027c71e8f24d2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3519f05a2f4c379b90027c71e8f24d2c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.file-manager.file-manager-js','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-manager.file-manager-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3519f05a2f4c379b90027c71e8f24d2c)): ?>
<?php $attributes = $__attributesOriginal3519f05a2f4c379b90027c71e8f24d2c; ?>
<?php unset($__attributesOriginal3519f05a2f4c379b90027c71e8f24d2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3519f05a2f4c379b90027c71e8f24d2c)): ?>
<?php $component = $__componentOriginal3519f05a2f4c379b90027c71e8f24d2c; ?>
<?php unset($__componentOriginal3519f05a2f4c379b90027c71e8f24d2c); ?>
<?php endif; ?>

    <!-- from each page -->
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH /home/luxuryon/public_html/resources/views/layouts/admin.blade.php ENDPATH**/ ?>