<form action="<?php echo e(route('admin.orders.update')); ?>" method="POST" class="update-order-form">
    <?php echo csrf_field(); ?>
    <div class="space-y-4">
        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
        <input type="hidden" name="warehouse_id" value="<?php echo e($order->warehouse_id); ?>">
        <div class="group relative !mt-4" tabindex="0">
            <?php if (isset($component)) { $__componentOriginal0a9614842ee9e3735e691e614c4eb027 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a9614842ee9e3735e691e614c4eb027 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SearchInput::resolve(['label' => 'Search Products','class' => 'update-order-product-search-input','name' => '','placeholder' => 'Search product by name','value' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SearchInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $attributes = $__attributesOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $component = $__componentOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__componentOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>

            <div
                class="update-order-product-search absolute z-[1] bg-background rounded-md right-0 top-[calc(100%)] w-full min-w-[300px] min-h-[150px] shadow max-h-[350px] overflow-y-auto p-[2px] divide-y divide-[#78787829] hidden group-focus-within:block transition-all duration-300">

                <div class="block py-4 px-6 bg-theme-primary/[.03] text-muted font-bold">
                    <span class="uppercase"><?php echo e(translate('Search Results')); ?></span>
                </div>

                
                <div class="divide-y divide-[#78787829] update-order-search-results">
                    <?php echo $__env->make('backend.admin.orders.product-search-results', [
                        'productVariations' => [],
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>

        
        <div class="!mt-4">
            <label class="theme-input-label !pt-0 input-required">
                <?php echo e(translate('Products')); ?>

            </label>
            <?php echo $__env->make('backend.admin.orders.update-order-table', [
                'orders' => collect(),
                'returnOrder' => null,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        

        <div class="flex justify-end">
            <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['buttonText' => 'Update Order','type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
        </div>
    </div>
</form>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/forms/update-order-form.blade.php ENDPATH**/ ?>