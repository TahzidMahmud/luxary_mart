<div
    class="input-select2 <?php echo e($labelInline ? 'theme-input-group' : ''); ?> <?php echo e(!$label ? 'no-label' : ''); ?> <?php echo e($groupClass); ?>">
    <?php if($label): ?>
        <label for="<?php echo e($name); ?>"
            class="theme-input-label <?php echo e($labelInline ? '' : 'pt-0'); ?> <?php echo e($isRequired ? 'input-required' : ''); ?>"><?php echo e(translate($label)); ?></label>
    <?php endif; ?>

    <div class="theme-input-wrapper <?php echo e($wrapperClass); ?>">
        <select <?php echo e($attributes->merge(['class' => $type . ' theme-input'])); ?> name="<?php echo e($name); ?>" <?php if($isRequired): echo 'required'; endif; ?>
            <?php if($isDisabled): ?> disabled <?php endif; ?>>
            <?php echo e($slot); ?>

        </select>
    </div>
</div>
<?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/components/backend/inputs/select.blade.php ENDPATH**/ ?>