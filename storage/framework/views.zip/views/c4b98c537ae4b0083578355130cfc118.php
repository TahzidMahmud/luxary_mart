<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Login')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="min-h-screen flex max-lg:flex-col bg-white">
        <div class="w-full lg:max-w-[600px] mx-auto py-8 2xl:py-12 h-screen overflow-y-auto">
            <div class="max-w-[450px] px-[15px] h-full mx-auto flex flex-col gap-8 xl:gap-14 justify-between">
                <div>
                    <img src="<?php echo e(uploadedAsset(getSetting('websiteHeaderLogo'))); ?>" alt="">
                </div>

                <div>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <h1 class="mb-8 text-xl md:text-[26px] font-semibold"><?php echo e(translate('Login to Dashboard')); ?></h1>

                        <div>
                            <label class="mb-1 uppercase text-[11px]"><?php echo e(translate('Email')); ?></label>
                            <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => 'email','placeholder' => ''.e(translate('Email')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                        </div>
                        <div class="mt-4">
                            <label class="mb-1 uppercase text-[11px]"><?php echo e(translate('Password')); ?></label>
                            <?php if (isset($component)) { $__componentOriginaleb2b233c21bd18a16379344934da8997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleb2b233c21bd18a16379344934da8997 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Password::resolve(['name' => 'password','placeholder' => ''.e(translate('Password')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Password::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleb2b233c21bd18a16379344934da8997)): ?>
<?php $attributes = $__attributesOriginaleb2b233c21bd18a16379344934da8997; ?>
<?php unset($__attributesOriginaleb2b233c21bd18a16379344934da8997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb2b233c21bd18a16379344934da8997)): ?>
<?php $component = $__componentOriginaleb2b233c21bd18a16379344934da8997; ?>
<?php unset($__componentOriginaleb2b233c21bd18a16379344934da8997); ?>
<?php endif; ?>

                            <label class="flex items-center gap-2 mt-2 text-xs">
                                <?php if (isset($component)) { $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Checkbox::resolve(['name' => 'toggle-password'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'toggle-password','data-target' => '#password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $attributes = $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $component = $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
                                <span><?php echo e(translate('Show Password')); ?></span>
                            </label>
                        </div>

                        <div class="mt-5">
                            <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full justify-center !bg-[#005BFF]']); ?><?php echo e(translate('Login')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
                        </div>

                        <label class="mt-6 flex gap-3 items-center text-xs">
                            <?php if (isset($component)) { $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Checkbox::resolve(['name' => 'remember_me'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $attributes = $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $component = $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
                            <span><?php echo e(translate('Remember Me')); ?></span>
                        </label>
                    </form>

                    <?php if(config('app.demo_mode') == 'On'): ?>
                        <div class="mt-12 space-y-4">
                            <div
                                class="flex bg-[#F1F1F1] border border-[#E3E3E3] text-neutral-400 rounded-md overflow-hidden max-w-[420px]">
                                <input name="email" class="w-full text-xs px-4 py-3 bg-transparent"
                                    value="admin@epikcart.com" readonly />
                                <input name="password"
                                    class="w-full text-xs px-2 py-3 bg-transparent border-l border-[#E3E3E3]" value="123456"
                                    readonly />
                                <button
                                    class="copy-password text-xs px-4 py-3 bg-theme-secondary-light text-white font-bold">COPY</button>
                            </div>
                            <div
                                class="flex bg-[#F1F1F1] border border-[#E3E3E3] text-neutral-400 rounded-md overflow-hidden max-w-[420px]">
                                <input name="email" class="w-full text-xs px-4 py-3 bg-transparent"
                                    value="seller@epikcart.com" readonly />
                                <input name="password"
                                    class="w-full text-xs px-2 py-3 bg-transparent border-l border-[#E3E3E3]" value="123456"
                                    readonly />
                                <button
                                    class="copy-password text-xs px-4 py-3 bg-theme-secondary-light text-white font-bold">COPY</button>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div>
                    <?php echo e(translate('Forgot The Pasword?')); ?>

                    <a href="<?php echo e(route('password.request')); ?>"
                        class="text-theme-secondary-light"><?php echo e(translate('Recover Now')); ?></a>
                </div>
            </div>
        </div>
        <div class="grow p-8 relative hidden lg:flex flex-col justify-center items-center text-white bg-cover"
            style="background-image: url(<?php echo e(asset('images/auth-bg.png')); ?>)">
            <div class="w-full max-w-[513px]">
                <h2 class="text-2xl xl:text-[44px] font-normal mb-5"><?php echo e(translate('Welcome Back Admin!')); ?></h2>
                <p class="text-lg">
                    <?php echo e(translate('Login to get all your latest order updates, notifications, edit options and activity log.')); ?>

                </p>
            </div>
        </div>
    </div>

    <script>
        "use strict";
        // insert email and password in the inputs when copy button is clicked
        const emailInput = document.querySelector('input[name="email"]');
        const passwordInput = document.querySelector('input[name="password"]');
        const copyBtn = document.querySelectorAll('.copy-password');

        copyBtn?.forEach(btn => {
            btn.addEventListener('click', () => {
                const email = btn.parentElement.querySelector('input[name="email"]').value;
                const password = btn.parentElement.querySelector('input[name="password"]').value;

                emailInput.value = email;
                passwordInput.value = password;

                btn.innerHTML = 'COPIED';
                setTimeout(() => {
                    btn.innerHTML = 'COPY';
                }, 5000);
            });
        });

        // toggle password visibility
        const togglePassword = document.querySelector('.toggle-password');
        const target = togglePassword.getAttribute('data-target');
        const passwordInputEl = document.querySelector(target);

        togglePassword.addEventListener('change', () => {

            if (passwordInputEl.type === 'password') {
                passwordInputEl.type = 'text';
            } else {
                passwordInputEl.type = 'password';
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/auth/login.blade.php ENDPATH**/ ?>