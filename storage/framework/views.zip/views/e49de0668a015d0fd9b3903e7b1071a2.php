
<button type="<?php echo e($type); ?>" <?php echo e($attributes->merge(['class' => 'button button--' . $variant])); ?>>
    <?php echo e(translate($buttonText)); ?>

    <?php echo e($slot); ?>

</button>
<?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/components/backend/inputs/button.blade.php ENDPATH**/ ?>