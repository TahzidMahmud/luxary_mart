<div class="stocks">
    <div class="flex flex-col">
        <div class="overflow-x-auto sm:mx-0.5 lg:mx-0.5">
            <div class="inline-block min-w-full">
                <div class="overflow-hidden">
                    <table class="min-w-full">
                        <thead class="bg-theme-primary/10 border-b border-border">
                            <tr class="text-left">
                                <th class="p-4 ps-6 w-[60px]">
                                    #
                                </th>
                                <th class="p-4 <?php echo e(!Route::is('admin.stockTransfers.show') ? 'w-[200px]' : 'w-[280px]'); ?>"
                                    data-breakpoints="xs sm">
                                    <?php echo e(translate('Product')); ?>

                                </th>
                                <?php if(!Route::is('admin.stockTransfers.show')): ?>
                                    <th class="p-4" data-breakpoints="xs sm">
                                        <?php echo e(translate('Current Stock')); ?>

                                    </th>
                                <?php endif; ?>

                                <th class="p-4 <?php echo e(!Route::is('admin.stockTransfers.show') ? '' : 'text-end'); ?>"
                                    data-breakpoints="xs sm">
                                    <?php echo e(translate('Qty')); ?>

                                </th>

                                <?php if(!Route::is('admin.stockTransfers.show')): ?>
                                    <th class="p-4" data-breakpoints="xs sm">
                                        <?php echo e(translate('Action')); ?>

                                    </th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody class="stocks-tbody">
                            <?php if(count($stockProductVariations) > 0): ?>
                                <?php $__currentLoopData = $stockProductVariations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $stockProductVariation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $product = $stockProductVariation->product;
                                        $productVariation = $stockProductVariation->productVariation;
                                    ?>

                                    <input type="hidden" name="purchaseOrderProductVariationIds[]"
                                        value="<?php echo e($stockProductVariation->id); ?>">

                                    <tr
                                        class="bg-background border-b border-border transition duration-300 ease-in-out hover:bg-background-hover">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">
                                            <span class="tr-length"><?php echo e($key + 1); ?></span>
                                            <input type="hidden" name="selectedVariationIds[]"
                                                value="<?php echo e($stockProductVariation->product_variation_id); ?>">
                                        </td>

                                        <td class="text-sm text-foreground font-light px-6 py-4 w-[200px] tr-name">
                                            <?php echo e($stockProductVariation->product->collectTranslation('name')); ?>

                                            <?php if($stockProductVariation->product->has_variation): ?>
                                                -
                                                <?php echo e(generateVariationName($stockProductVariation->productVariation->code)); ?>

                                            <?php endif; ?>
                                        </td>

                                        <td
                                            class="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground tr-current-stock text-end">
                                            <?php echo e($stockProductVariation->qty); ?> <span
                                                class="tr-unit"><?php echo e($product->unit?->collectTranslation('name')); ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr class="bg-background no-data">
                                    <td colspan="9"
                                        class="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground text-center">
                                        <?php echo e(translate('No data')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/inventory/stock-transfers/stock-products-table.blade.php ENDPATH**/ ?>