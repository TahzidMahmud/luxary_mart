<div class="mt-8">
    <div class="flex items-center justify-between gap-3 relative">
        <h4 class="font-medium bg-background pr-4 relative z-[1]"><?php echo e(translate('Variations')); ?></h4>
        <span
            class="absolute inline-block top-1/2 left-0 right-0 -translate-y-1/2 border-b border-[#E7E7E7] w-full h-0.5"></span>
    </div>

    <div class="product-variations init-accordion accordion-container border-collapse mt-5">
        <?php
            $defaultWarehouse = shop()->warehouses()->where('is_default', 1)->first();
        ?>
        <?php $__currentLoopData = $combinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $combination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $name = '';
                $code_array = array_filter(explode('/', $combination->code));
                $lstKey = array_key_last($code_array);

                foreach ($code_array as $key2 => $comb) {
                    $comb = explode(':', $comb);

                    $option_name = \App\Models\Variation::find($comb[0])?->collectTranslation('name') ?? '';
                    $choice_name = \App\Models\VariationValue::find($comb[1])?->collectTranslation('name') ?? '';

                    $name .= $choice_name;

                    if ($lstKey != $key2) {
                        $name .= '-';
                    }
                }
            ?>

            <div class="ac">
                <h2 class="ac-header">
                    <button type="button" class="ac-trigger">
                        <span class="text-muted mr-3"><?php echo e(translate('Variation')); ?> <?php echo e($key + 1); ?>:</span>
                        <?php echo e($name); ?>

                    </button>
                </h2>
                <div class="ac-panel">
                    <div class="py-4 xl:py-7 px-3 md:px-6 xl:px-10 grid sm:grid-cols-2 xl:grid-cols-4 gap-7">
                        <input type="hidden" value="<?php echo e($combination->code); ?>"
                            name="variations[<?php echo e($key); ?>][code]">

                        <div>
                            <label class="mb-2"><?php echo e(translate('SKU')); ?></label>
                            <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => 'variations['.e($key).'][sku]','value' => ''.e($combination->sku).'','placeholder' => 'red-xl-346890'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <label class="mb-2"><?php echo e(translate('Price')); ?></label>
                            <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => 'variations['.e($key).'][price]','value' => ''.e($combination->price).'','placeholder' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '0','step' => '0.001']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <label class="mb-2"><?php echo e(translate('Discount')); ?></label>
                            <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => 'variations['.e($key).'][discount_value]','value' => ''.e($combination->discount_value).'','placeholder' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','min' => '0','step' => '0.001']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                        </div>
                        <div>
                            <label class="mb-2"><?php echo e(translate('Discount Type')); ?></label>
                            <select class="theme-input h-auto p-3 py-2.5"
                                name="variations[<?php echo e($key); ?>][discount_type]">
                                <option value="flat" <?php if($combination->discount_type == 'flat'): echo 'selected'; endif; ?>><?php echo e(translate('Flat')); ?></option>
                                <option value="percentage" <?php if($combination->discount_type == 'percentage'): echo 'selected'; endif; ?>><?php echo e(translate('Percentage')); ?>

                                </option>
                            </select>
                        </div>
                        <div class="sm:col-span-2 <?php echo e(!useInventory() ? 'xl:col-span-3' : 'xl:col-span-4'); ?> ">
                            <label class="mb-2"><?php echo e(translate('Image')); ?></label>
                            <?php if (isset($component)) { $__componentOriginalbcbda3596773ae205278bc8929e0d504 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbcbda3596773ae205278bc8929e0d504 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\File::resolve(['name' => 'variations['.e($key).'][image]','value' => ''.e($combination->image).'','filesHint' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\File::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $attributes = $__attributesOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__attributesOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $component = $__componentOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__componentOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>
                        </div>

                        <?php if(!useInventory()): ?>
                            <div>
                                <label class="mb-2"><?php echo e(translate('Stock')); ?></label>
                                <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => 'variations['.e($key).'][stock_qty]','value' => ''.e($combination->productVariationStocks()->where('warehouse_id', $defaultWarehouse->id)->where('product_variation_id', $combination->id)->first()?->stock_qty ?? 0).'','placeholder' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','min' => '0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/products/update-variation-combinations.blade.php ENDPATH**/ ?>