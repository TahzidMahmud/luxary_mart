<form action="<?php echo e($brand ? route('admin.brands.update', $brand->id) : route('admin.brands.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <?php if($brand): ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" name="lang_key" value="<?php echo e($langKey); ?>">
    <?php else: ?>
        <?php
            $langKey = config('app.default_language');
        ?>
    <?php endif; ?>

    <div class="space-y-3">
        <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Name','name' => 'name','placeholder' => 'Type brand name','value' => ''.e($brand?->collectTranslation('name', $langKey)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalbcbda3596773ae205278bc8929e0d504 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbcbda3596773ae205278bc8929e0d504 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\File::resolve(['label' => 'Thumbnail Image','name' => 'thumbnail_image','value' => ''.e($brand?->thumbnail_image).'','filesHint' => 'This image will be used as thumbnail of the brand. Recommended size: 300*300'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\File::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $attributes = $__attributesOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__attributesOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $component = $__componentOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__componentOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Meta Title','name' => 'meta_title','placeholder' => 'Type meta title','value' => ''.e($brand?->collectTranslation('meta_title', $langKey)).'','isRequired' => false,'aiGenerate' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginale582db01b056b256cb800ff6b8d80bac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale582db01b056b256cb800ff6b8d80bac = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Textarea::resolve(['label' => 'Meta Description','name' => 'meta_description','placeholder' => 'Type meta description','value' => ''.e($brand?->collectTranslation('meta_description', $langKey)).'','isRequired' => false,'aiGenerate' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $attributes = $__attributesOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__attributesOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $component = $__componentOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__componentOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginale582db01b056b256cb800ff6b8d80bac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale582db01b056b256cb800ff6b8d80bac = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Textarea::resolve(['label' => 'Meta Keywords','name' => 'meta_keywords','placeholder' => 'Type comma separated keywords. e.g. keyword1, keyword2','value' => ''.$brand?->collectTranslation('meta_keywords', $langKey).'','isRequired' => false,'aiGenerate' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $attributes = $__attributesOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__attributesOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $component = $__componentOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__componentOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalbcbda3596773ae205278bc8929e0d504 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbcbda3596773ae205278bc8929e0d504 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\File::resolve(['label' => 'Meta Image','name' => 'meta_image','value' => ''.e($brand?->meta_image).'','filesHint' => 'This image will be used as meta image of the brand. Recommended size: 512*512'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\File::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $attributes = $__attributesOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__attributesOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $component = $__componentOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__componentOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>

        <?php if($brand && $langKey == config('app.default_language')): ?>
            <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Slug','name' => 'slug','placeholder' => 'Type custom slug','value' => ''.e($brand->slug).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
        <?php endif; ?>

        <div class="flex justify-end">
            <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['buttonText' => 'Save Brand','type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
        </div>
    </div>
</form>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/forms/brand-form.blade.php ENDPATH**/ ?>