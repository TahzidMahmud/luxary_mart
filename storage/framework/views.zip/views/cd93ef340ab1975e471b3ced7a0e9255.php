<!-- start::mobile bottom nav -->
<div class="mobile-navbar">
    <ul class="flex items-center">
        <li>
            <a href="<?php echo e(route(routePrefix() . '.dashboard')); ?>" class="text-center leading-none px-3">
                <span class="text-base text-theme-secondary"><i class="fa-regular fa-house"></i></span>
                <br />
                <span class="text-[11px] text-muted"><?php echo e(translate('Home')); ?></span>
            </a>
        </li>
        <?php if(user()->user_type == 'seller'): ?>
            <li>
                <a href="<?php echo e(route(routePrefix() . '.orders.index')); ?>" class="text-center leading-none px-3">
                    <span class="text-base text-theme-secondary"><i class="fa-regular fa-cart-shopping"></i></span>
                    <br />
                    <span class="text-[11px] text-muted"><?php echo e(translate('Orders')); ?></span>
                </a>
            </li>
        <?php else: ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_orders')): ?>
                <li>
                    <a href="<?php echo e(route(routePrefix() . '.orders.index')); ?>" class="text-center leading-none px-3">
                        <span class="text-base text-theme-secondary"><i class="fa-regular fa-cart-shopping"></i></span>
                        <br />
                        <span class="text-[11px] text-muted"><?php echo e(translate('Orders')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>

        <li>
            <div class="option-dropdown relative -translate-y-5" tabindex="0">
                <div
                    class="option-dropdown__toggler no-style no-arrow border-4 border-border flex items-center justify-center w-[55px] aspect-square rounded-full bg-theme-primary text-white text-2xl">
                    <i class="fal fa-plus"></i>
                </div>

                <div class="option-dropdown__options bottom-full top-auto left-1/2 -translate-x-1/2 min-w-[180px]"
                    data-placement="">
                    <ul>
                        <?php if(user()->user_type == 'seller'): ?>
                            <li>
                                <a href="<?php echo e(route(routePrefix() . '.products.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Product')); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route(routePrefix() . '.purchase-orders.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Purchase Order')); ?></a>
                            </li>

                            <li>
                                <a href="<?php echo e(route(routePrefix() . '.stockAdjustments.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Stock Adjustment')); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route(routePrefix() . '.stockTransfers.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Stock Transfer')); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route(routePrefix() . '.suppliers.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Supplier')); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route(routePrefix() . '.coupons.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Coupon')); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route(routePrefix() . '.campaigns.create')); ?>"
                                    class="option-dropdown__option"><?php echo e(translate('Campaign')); ?></a>
                            </li>
                        <?php else: ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_products')): ?>
                                <li>
                                    <a href="<?php echo e(route(routePrefix() . '.products.create')); ?>"
                                        class="option-dropdown__option"><?php echo e(translate('Product')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_purchase_orders')): ?>
                                <li>
                                    <a href="<?php echo e(route(routePrefix() . '.purchase-orders.create')); ?>"
                                        class="option-dropdown__option"><?php echo e(translate('Purchase Order')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_stock_adjustment')): ?>
                                <li>
                                    <a href="<?php echo e(route(routePrefix() . '.stockAdjustments.create')); ?>"
                                        class="option-dropdown__option"><?php echo e(translate('Stock Adjustment')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_stock_transfer')): ?>
                                <li>
                                    <a href="<?php echo e(route(routePrefix() . '.stockTransfers.create')); ?>"
                                        class="option-dropdown__option"><?php echo e(translate('Stock Transfer')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_suppliers')): ?>
                                <li>
                                    <a href="<?php echo e(route(routePrefix() . '.suppliers.create')); ?>"
                                        class="option-dropdown__option"><?php echo e(translate('Supplier')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_coupons')): ?>
                                <li>
                                    <a href="<?php echo e(route(routePrefix() . '.coupons.create')); ?>"
                                        class="option-dropdown__option"><?php echo e(translate('Coupon')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_campaigns')): ?>
                                <li>
                                    <a href="<?php echo e(route(routePrefix() . '.campaigns.create')); ?>"
                                        class="option-dropdown__option"><?php echo e(translate('Campaign')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>

                    </ul>
                </div>
            </div>
        </li>
        <li>
            <button href="#" class="toggle-mobile-search text-center leading-none px-3">
                <span class="text-base text-theme-secondary"><i class="fa-regular fa-search"></i></span>
                <br />
                <span class="text-[11px] text-muted"><?php echo e(translate('Search')); ?></span>
            </button>
        </li>

        <?php if(user()->user_type == 'seller'): ?>
            <li>
                <a href="<?php echo e(route(routePrefix() . '.notifications')); ?>" class="text-center leading-none px-3">
                    <span class="text-base text-theme-secondary"><i class="fa-regular fa-bell"></i></span>
                    <br />
                    <span class="text-[11px] text-muted"><?php echo e(translate('Notifications')); ?></span>
                </a>
            </li>
        <?php else: ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_notifications')): ?>
                <li>
                    <a href="<?php echo e(route(routePrefix() . '.notifications')); ?>" class="text-center leading-none px-3">
                        <span class="text-base text-theme-secondary"><i class="fa-regular fa-bell"></i></span>
                        <br />
                        <span class="text-[11px] text-muted"><?php echo e(translate('Notifications')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
    </ul>
</div>
<!-- end::mobile bottom nav -->
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inc/footer.blade.php ENDPATH**/ ?>