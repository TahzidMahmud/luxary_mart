<?php $__env->startSection('title'); ?>
    <?php echo e(translate('File Manager')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex-grow overflow-y-hidden">
        <!-- start::dashboard breadcrumb -->
        <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
            <div class="flex items-center">
                <span class="text-xl mr-3 text-theme-secondary">
                    <i class="fa-regular fa-folder"></i>
                </span>
                <span class="text-sm sm:text-base font-bold">
                    <?php echo e(translate('Media Library')); ?>

                </span>
            </div>

            <div class="max-sm:hidden flex items-center gap-2">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="font-bold "><?php echo e(translate('Dashboard')); ?></a>
                <span class="text-theme-primary">
                    <i class="fa-solid fa-chevron-right"></i>
                </span>
                <p class="text-muted"><?php echo e(translate('File Manager')); ?></p>
            </div>
        </div>
        <!-- end::dashboard breadcrumb -->

        <div
            class="show-media-manager bg-background relative md:h-[calc(100vh-241px)] rounded-md shadow-theme [&_.uppy-Dashboard-AddFiles]:h-[280px]">
            <?php if (isset($component)) { $__componentOriginal70281eb1c6e546e031cb8a3b9ef7232d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal70281eb1c6e546e031cb8a3b9ef7232d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.file-manager.content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('file-manager.content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal70281eb1c6e546e031cb8a3b9ef7232d)): ?>
<?php $attributes = $__attributesOriginal70281eb1c6e546e031cb8a3b9ef7232d; ?>
<?php unset($__attributesOriginal70281eb1c6e546e031cb8a3b9ef7232d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70281eb1c6e546e031cb8a3b9ef7232d)): ?>
<?php $component = $__componentOriginal70281eb1c6e546e031cb8a3b9ef7232d; ?>
<?php unset($__componentOriginal70281eb1c6e546e031cb8a3b9ef7232d); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        "use strict";
        $(document).ready(async function() {
            mediaManager.data.multiple = true;
            mediaManager.showMedia()
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/file-manager/index.blade.php ENDPATH**/ ?>