<div class="grid md:grid-cols-2 gap-3 mt-4">
    <div class="md:col-span-1">
        <div class="flex items-center">
            <div class="w-full"><?php echo e(translate('Attribute')); ?> <span class="attribute-counter"><?php echo e($chosenCounter); ?></span>
            </div>
            <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['groupClass' => 'w-full ms-4','name' => 'chosen_variations[]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onchange' => 'getVariationValues(this)','class' => 'chosen_variations','data-search' => 'false']); ?>
                <option value=""><?php echo e(translate('Select Variation')); ?>

                    <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e($variation->collectTranslation('name')).'','value' => ''.e($variation->id).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
        </div>
    </div>

    <div class="md:col-span-1">
        <div class="flex items-center">
            <div class="variationvalues w-full">
                <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => '','placeholder' => 'Select variation values'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
            </div>
            <button class="button button-default" type="button" onclick="removeVariation(this)">
                <span class="footable-toggle fooicon fooicon-minus"></span>
            </button>
        </div>
    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/products/new-variation.blade.php ENDPATH**/ ?>