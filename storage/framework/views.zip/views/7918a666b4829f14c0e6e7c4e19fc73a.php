<script>
    "use strict";

    ATE.searchKey = '';

    // submit form
    $('.stocks-form').on('submit', function(e) {
        let selectedVariationIds = $("input[name='selectedVariationIds[]']")
            .map(function() {
                return $(this).val();
            }).get();

        if (selectedVariationIds.length < 1) {
            notifyMe('error', '<?php echo e(translate('Please select at least one product')); ?>');
            e.preventDefault();
        }
    });

    // show search result ui
    $('.stocks-product-search-input').on('click', function() {
        debouncedProductSearch()
        $(".stock-product-search").show();
    });

    // search products
    const debouncedProductSearch = debounce(getProducts, 300);
    $('.stocks-product-search-input').on('input', ((e) => {
        ATE.searchKey = e.target.value
        debouncedProductSearch()
    }));

    // get products
    function getProducts() {

        let warehouseId = ($('[name=from_warehouse_id]').val());
        if (warehouseId == '') {
            notifyMe('warning', '<?php echo e(translate('Please select from warehouse')); ?>')
            return;
        }

        let selectedVariationIds = $("input[name='selectedVariationIds[]']")
            .map(function() {
                return $(this).val();
            }).get();

        $.ajax({
            type: "POST",
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            url: '<?php echo e(route(routePrefix() . '.stockTransfers.getProducts')); ?>',
            data: {
                searchKey: ATE.searchKey,
                selectedVariationIds: selectedVariationIds,
                warehouseId: warehouseId,
            },
            success: function(data) {
                $('.stock-search-results').html(data);
            }
        });
    }

    // load More Products
    function loadMorePoProducts($this, url) {
        $('.load-more-spin').removeClass('hidden');

        let selectedVariationIds = $("input[name='selectedVariationIds[]']")
            .map(function() {
                return $(this).val();
            }).get();

        let warehouseId = ($('[name=from_warehouse_id]').val());

        $.ajax({
            type: "POST",
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            url: url,
            data: {
                selectedVariationIds: selectedVariationIds,
                warehouseId: warehouseId,
            },
            success: function(data) {
                $($this).closest('div').remove();
                $(".stocks-product-search-input input").focus();
                $('.stock-search-results').append(data);
            }
        });
    }

    // hadnle po product click
    function handlePoProductClick($this) {
        let
            variationId = 0,
            length = 0,
            name = '',
            unit = '',
            stock = 0;

        $('.stocks-tbody .no-data')?.remove();

        variationId = $($this).data('variation-id');
        length = $('.stocks-tbody').children().length + 1;
        name = $($this).data('name');
        unit = $($this).data('unit');
        stock = $($this).data('stock');

        let tr = `<tr class="bg-background border-b border-border transition duration-300 ease-in-out hover:bg-background-hover">
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">
                             <span class="tr-length">${length}</span>
                            <input type="hidden" name="selectedVariationIds[]" value="${variationId}"> 
                        </td>
                        
                        <td class="text-sm text-foreground font-light px-6 py-4 w-[200px] tr-name">
                          ${name} 
                        </td>
                        
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground tr-current-stock"> 
                            ${stock} <span class="tr-unit">${unit}</span>
                        </td>
                        
                        <td class="text-sm text-foreground font-light px-6 py-4 whitespace-nowrap">
                            <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['name' => 'stockQty[]','value' => '1'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '1','max' => '${stock}']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
                        </td> 

                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">
                            <button type="button" class="text-md flex items-center justify-center"
                                onclick="removeOrderItem(this)">
                                <i class="fas fa-times text-red-500"></i>
                            </button>
                        </td>
                    </tr>`;

        $('.stocks-tbody').append(tr);
        $($this).remove();
        $(".stock-product-search").hide();
    }

    // removeOrderItem(this)
    function removeOrderItem($this) {
        $($this).closest('tr').remove();
    }

    // on warehouse change
    $('[name=from_warehouse_id]').on('change', function() {
        let noSearch = `<div class="flex justify-center items-center py-[35px]">
                        <?php echo e(translate('No results')); ?>

                    </div>`;
        let noProduct = `<tr class="bg-background no-data">
                            <td colspan="9"
                                class="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground text-center">
                                <?php echo e(translate('No data')); ?>

                            </td>
                        </tr>`;

        $('.stocks-tbody').empty().html(noProduct);
        $('.stock-search-results').empty().html(noSearch);
    })
</script>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inc/stock-transfers-scripts.blade.php ENDPATH**/ ?>