<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- css -->
    <?php if (isset($component)) { $__componentOriginal1d12a4f89dcd45d78ec9ecda59b92c58 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1d12a4f89dcd45d78ec9ecda59b92c58 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.inc.styles','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inc.styles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1d12a4f89dcd45d78ec9ecda59b92c58)): ?>
<?php $attributes = $__attributesOriginal1d12a4f89dcd45d78ec9ecda59b92c58; ?>
<?php unset($__attributesOriginal1d12a4f89dcd45d78ec9ecda59b92c58); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1d12a4f89dcd45d78ec9ecda59b92c58)): ?>
<?php $component = $__componentOriginal1d12a4f89dcd45d78ec9ecda59b92c58; ?>
<?php unset($__componentOriginal1d12a4f89dcd45d78ec9ecda59b92c58); ?>
<?php endif; ?>
</head>

<body>
    <div class="h-100vh bg-[#eff7fd]">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <div class="overlay"></div>

    <!-- scripts -->
    
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>

    <script>
        "use strict";

        // ajax toast 
        function notifyMe(level, message) {
            if (level == 'danger') {
                level = 'error';
            }
            toastr.options = {
                closeButton: true,
                newestOnTop: false,
                progressBar: true,
                positionClass: "toast-top-right",
                preventDuplicates: false,
                onclick: null,
                showDuration: "3000",
                hideDuration: "1000",
                timeOut: "3000",
                extendedTimeOut: "1000",
                showEasing: "swing",
                hideEasing: "linear",
                showMethod: "fadeIn",
                hideMethod: "fadeOut",
            };
            toastr[level](message);
        }

        // laravel flash toast messages 
        <?php $__currentLoopData = session('flash_notification', collect())->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            notifyMe("<?php echo e($message['level']); ?>", "<?php echo e($message['message']); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
</body>

</html>
<?php /**PATH /home/luxuryon/public_html/resources/views/layouts/auth.blade.php ENDPATH**/ ?>