<div class="<?php echo e($labelInline ? 'theme-input-group' : ''); ?> <?php echo e(!$label ? 'no-label' : ''); ?>">
    <?php if($label): ?>
        <label for="<?php echo e($name); ?>"
            class="theme-input-label <?php echo e($labelInline ? '' : 'pt-0'); ?> <?php echo e($isRequired ? 'input-required' : ''); ?>">
            <?php echo e(translate($label)); ?>

        </label>
    <?php endif; ?>
    <div class="theme-input-wrapper <?php echo e($label ? '' : 'col-span-4'); ?>">
        <div class="date-picker date-picker--<?php echo e($type); ?>">
            <input type="text" placeholder="<?php echo translate($placeholder); ?>" class="theme-input" id="<?php echo e($name); ?>"
                name="<?php echo e($name); ?>" value="<?php echo $value; ?>" <?php if($isDisabled): echo 'disabled'; endif; ?> />
        </div>
    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/datepicker.blade.php ENDPATH**/ ?>