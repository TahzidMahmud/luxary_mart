<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Notifications')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-bell"></i>
            </span>
            <span class="text-sm sm:text-base font-bold"><?php echo e(translate('Notifications')); ?></span>
        </div>
    </div>

    <ul class="divide-y divide-border">
        <?php if(count($notifications) > 0): ?>
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="card mb-2  <?php echo e($notification->is_read ? '' : 'bg-orange-50/50'); ?>">
                    <a href="<?php echo e(getNotificationLink($notification)); ?>"
                        class="text-[13px] flex items-center px-[25px] py-[15px] gap-[14px]">
                        <div>
                            <span
                                class="w-[27px] aspect-square <?php echo e(getNotificationIcon($notification, 'class')); ?> inline-flex items-center justify-center rounded-full">
                                <i class="<?php echo e(getNotificationIcon($notification)); ?>"></i>
                            </span>
                        </div>
                        <div>
                            <h5 class="truncate">
                                <?php echo e(getNotificationText($notification)); ?>

                            </h5>
                            <div class="flex items-center text-muted">
                                <span><?php echo e($notification->created_at->diffForHumans()); ?></span>
                                <span class="ml-[9px] mr-[7px] h-[5px] w-[5px] rounded-full bg-theme-secondary"></span>
                                <span class="capitalize"><?php echo e($notification->type); ?></span>
                            </div>
                        </div>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="text-center py-5">
                <?php echo e(translate('No Notifications')); ?>

            </div>
        <?php endif; ?>
    </ul>

    <div class="mt-6">
        <?php echo e($notifications->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/dashboard/notifications.blade.php ENDPATH**/ ?>