<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Orders')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Order List')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="font-bold "><?php echo e(translate('Orders')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Order List')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="card theme-table">
        <div
            class="card__title border-none theme-table__filter flex flex-col md:flex-row xl:items-center justify-end gap-3">
            <?php if (isset($component)) { $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\SearchForm::resolve(['searchKey' => ''.e($searchKey).'','class' => 'w-full max-w-[600px]','placeholder' => 'Type name or order code & hit enter'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\SearchForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['name' => 'deliveryStatus','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'filterSelect']); ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('All Orders')).'','value' => '','selected' => ''.e(Request::get('deliveryStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('New Orders')).'','value' => 'order_placed','selected' => ''.e(Request::get('deliveryStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Confirmed')).'','value' => 'confirmed','selected' => ''.e(Request::get('deliveryStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Processing')).'','value' => 'processing','selected' => ''.e(Request::get('deliveryStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Shipped')).'','value' => 'shipped','selected' => ''.e(Request::get('deliveryStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Delivered')).'','value' => 'delivered','selected' => ''.e(Request::get('deliveryStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Cancelled')).'','value' => 'cancelled','selected' => ''.e(Request::get('deliveryStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['name' => 'paymentStatus','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'filterSelect']); ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Paid & Unpaid')).'','value' => '','selected' => ''.e(Request::get('paymentStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Paid Orders')).'','value' => 'paid','selected' => ''.e(Request::get('paymentStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Unpaid Orders')).'','value' => 'unpaid','selected' => ''.e(Request::get('paymentStatus')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $attributes = $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $component = $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
        </div>

        <table class="product-list-table footable w-full">
            <thead class="">
                <tr>
                    <th>
                        <?php echo e(translate('Customer')); ?>

                    </th>

                    <th>
                        <?php echo e(translate('Invoice No')); ?>

                    </th>
                    <th data-breakpoints="xs sm md">
                        <?php echo e(translate('Date')); ?>

                    </th>
                    <th data-breakpoints="xs sm md">
                        <?php echo e(translate('QTY')); ?>

                    </th>

                    <th data-breakpoints="xs sm">
                        <?php echo e(translate('Value')); ?>

                    </th>

                    <th data-breakpoints="xs sm">
                        <?php echo e(translate('Advance')); ?>

                    </th>

                    <th data-breakpoints="xs sm">
                        <?php echo e(translate('Due')); ?>

                    </th>

                    <th data-breakpoints="xs sm"><?php echo e(translate('Delivery Status')); ?></th>
                    <th data-breakpoints="xs sm"><?php echo e(translate('Payment')); ?></th>
                    <th data-breakpoints="xs sm" class="w-[130px] text-right">
                        <?php echo e(translate('Options')); ?>

                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="">
                            <div class="inline-flex items-center gap-4">
                                <div class="max-xs:hidden">
                                    <img src="<?php echo e(uploadedAsset($order->user?->avatar)); ?>" alt=""
                                        class="w-12 h-12 lg:w-[70px] lg:h-[80px] rounded-md"
                                        onerror="this.onerror=null;this.src='<?php echo e(asset('images/image-error.png')); ?>';" />
                                </div>
                                <div class=" line-clamp-2">
                                    <?php echo e($order->user?->name); ?>

                                    <div class=" line-clamp-2">
                                        <?php echo e($order->user?->phone); ?>

                                    </div>
                                </div>
                            </div>
                        </td>

                        <td class="text-ceter">
                            <a target="_blank" href="<?php echo e(route('admin.orders.downloadInvoice', $order->id)); ?>">
                                <i data-feather="download" width="18"></i>
                                <?php echo e(getSetting('orderCodePrefix')); ?><?php echo e($order->order_code); ?>

                                <span class="text-lg text-theme-orange">
                                    <i class="fa-solid fa-file-arrow-down"></i>
                                </span>
                            </a>
                        </td>

                        <td>
                            <?php echo e(date('d M, Y', strtotime($order->created_at))); ?>

                        </td>

                        <td>
                            <?php echo e($order->orderItems()->count() < 10 ? '0' . $order->orderItems()->count() : $order->orderItems()->count()); ?>

                        </td>

                        <td>
                            <span class="font-bold text-sky-500"><?php echo e(formatPrice($order->total_amount)); ?></span>
                        </td>


                        <td>
                            <span class="font-bold text-green-500"><?php echo e(formatPrice($order->advance_payment)); ?></span>
                        </td>

                        <td>
                            <span
                                class="font-bold text-red-500"><?php echo e(formatPrice($order->total_amount - $order->advance_payment)); ?></span>
                        </td>
                        <td>
                            <span
                                class="px-2 py-1 text-xs <?php echo e(getOrderBgClass($order->delivery_status)); ?> text-white rounded-md leading-none">
                                <?php echo e(ucfirst(str_replace('_', ' ', $order->delivery_status))); ?>

                            </span>
                        </td>


                        <td>
                            <div class="inline-flex items-center capitalize gap-1.5">
                                <span
                                    class="<?php echo e($order->payment_status == 'paid' ? 'text-teal-600' : 'text-neutral-300 dark:text-neutral-800'); ?> text-2xl">
                                    <i class="fa-solid fa-circle-check"></i>
                                </span>
                                <span><?php echo e(ucfirst($order->payment_status)); ?></span>
                            </div>
                        </td>


                        <td>
                            <div class="flex justify-end gap-3">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_orders')): ?>
                                    <?php
                                        $orderGroup = $order->orderGroup;
                                    ?>
                                    <?php if($orderGroup->is_pos_order): ?>
                                        <a class="text-stone-300 hover:text-stone-500 text-lg"
                                            href="<?php echo e(route('admin.pos')); ?>?orderGroupId=<?php echo e($order->orderGroup?->id); ?>">
                                            <i class="fa-regular fa-pen-to-square"></i>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('admin.orders.show', $order->order_code)); ?>"
                                        class="text-theme-secondary text-lg">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="card__footer">
            <?php echo e($orders->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/orders/index.blade.php ENDPATH**/ ?>