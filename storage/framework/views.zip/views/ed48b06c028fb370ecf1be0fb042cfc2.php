
<a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => 'button button--' . $variant])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/link.blade.php ENDPATH**/ ?>