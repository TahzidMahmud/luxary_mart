<?php if($label): ?>
    <label class="theme-input-label !pt-0 input-required">
        <?php echo translate($label); ?>

    </label>
<?php endif; ?>
<div class="search-form relative flex-grow w-full <?php echo e($class); ?>">
    <input <?php echo e($attributes->merge()); ?> type="text" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
        value="<?php echo $value; ?>" class="theme-input" placeholder="<?php echo e(translate($placeholder)); ?>"
        autocomplete="off" />
    <span
        class="text-theme-primary dark:text-muted absolute top-0 right-0 h-full flex items-center justify-center px-3 pointer-events-none">
        <i class="fa-solid fa-magnifying-glass"></i>
    </span>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/search-input.blade.php ENDPATH**/ ?>