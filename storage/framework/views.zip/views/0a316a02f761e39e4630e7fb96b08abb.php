<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Variation List')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Variation List')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="font-bold "><?php echo e(translate('Dashboard')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Variation List')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="grid md:grid-cols-6 gap-3">
        <div class="md:col-span-4 card">
            <div class="card__title border-none font-normal grid sm:grid-cols-2 3xl:grid-cols-3 gap-4">
                <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="py-3 md:py-7 px-4 md:px-8 bg-background-primary-light rounded-md flex flex-col">
                        <div class="flex justify-between">
                            <p class="uppercase"><?php echo e($variation->collectTranslation('name')); ?></p>

                            <div class="flex gap-3">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_variations')): ?>
                                    <a class="text-stone-300 hover:text-stone-500"
                                        href="<?php echo e(route('admin.variations.edit', ['variation' => $variation->id, 'lang_key' => config('app.default_language')])); ?>&translate">
                                        <i class="fa-regular fa-pen-to-square"></i>
                                    </a>
                                <?php endif; ?>
                                <?php
                                    $defaultVariationIds = [1, 2];
                                ?>
                                <?php if(!in_array($variation->id, $defaultVariationIds)): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_variations')): ?>
                                        <a class="text-red-400 hover:text-rose-600 confirm-modal" href="javascript:void(0);"
                                            data-href="<?php echo e(route('admin.variations.destroy', $variation->id)); ?>"
                                            data-title="<?php echo e(translate('Are you sure you want to delete this item?')); ?>"
                                            data-text="<?php echo e(translate('All data related to this may get deleted.')); ?>"
                                            data-method="DELETE" data-micromodal-trigger="confirm-modal">
                                            <i class="fa-regular fa-trash-can"></i>
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>

                            </div>
                        </div>

                        <div class="mt-1.5 mb-3 flex gap-1.5 flex-wrap max-w-[190px]">
                            <?php $__currentLoopData = $variation->getLimitedVariationValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variationValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span
                                    class="font-medium uppercase text-white bg-theme-secondary-light px-2.5 py-1 rounded"><?php echo e($variationValue->collectTranslation('name')); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="mt-auto flex justify-between">
                            <p>
                                <?php echo e(translate('Total Variations')); ?>

                                <span class="text-muted"><?php echo e($variation->variation_values_count); ?></span>
                            </p>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_variation_values')): ?>
                                <a href="<?php echo e(route('admin.variation-values.index', ['variation_id' => $variation->id])); ?>"
                                    class="text-theme-secondary-light"><?php echo e(translate('Edit Values')); ?></a>
                            <?php endif; ?>
                        </div>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_variations')): ?>
                            <div class="flex items-center justify-end gap-4 mt-3 border-t border-theme-primary-14 pt-4">
                                <label for="isActiveCheckbox"><?php echo e(translate('Activate Variation')); ?></label>
                                <?php if (isset($component)) { $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Checkbox::resolve(['toggler' => 'true','name' => 'isActiveCheckbox','value' => ''.e($variation->id).'','isChecked' => ''.e((int) $variation->is_active == 1).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-route' => ''.e(route('admin.variations.status')).'','data-status' => ''.e($variation->is_active).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $attributes = $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $component = $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="card__footer">
                <?php echo e($variations->links()); ?>

            </div>
        </div>
        <div class="md:col-span-2">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_variations')): ?>
                <div class="card">
                    <h4 class="card__title"><?php echo e(translate('Add New Variation')); ?></h4>
                    <div class="card__content">
                        <?php if (isset($component)) { $__componentOriginal24f3496218f28c17542573646e14ff2d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal24f3496218f28c17542573646e14ff2d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\VariationForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.variation-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\VariationForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal24f3496218f28c17542573646e14ff2d)): ?>
<?php $attributes = $__attributesOriginal24f3496218f28c17542573646e14ff2d; ?>
<?php unset($__attributesOriginal24f3496218f28c17542573646e14ff2d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal24f3496218f28c17542573646e14ff2d)): ?>
<?php $component = $__componentOriginal24f3496218f28c17542573646e14ff2d; ?>
<?php unset($__componentOriginal24f3496218f28c17542573646e14ff2d); ?>
<?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/variations/index.blade.php ENDPATH**/ ?>