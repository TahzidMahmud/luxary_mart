<?php if(!Route::is(routePrefix() . '.stockTransfers.show')): ?>
    <form action="<?php echo e(route(routePrefix() . '.stockTransfers.store')); ?>" method="POST" class="stocks-form">
        <?php echo csrf_field(); ?>
<?php endif; ?>

<div class="space-y-4">
    <div class="grid grid-cols-12 gap-4">
        <div class="col-span-12 md:col-span-6">
            <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['label' => 'From Warehouse','labelInline' => false,'name' => 'from_warehouse_id','isDisabled' => ''.e(Route::is(routePrefix() . '.stockTransfers.show') ? true : false).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>
                <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => 'Select from warehouse','value' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e($warehouse->name).'','value' => ''.e($warehouse->id).'','selected' => ''.e($stockTransfer?->from_warehouse_id).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
        </div>

        <div class="col-span-12 md:col-span-6">
            <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['label' => 'To Warehouse','labelInline' => false,'name' => 'to_warehouse_id','isDisabled' => ''.e(Route::is(routePrefix() . '.stockTransfers.show') ? true : false).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>
                <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => 'Select to warehouse','value' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e($warehouse->name).'','value' => ''.e($warehouse->id).'','selected' => ''.e($stockTransfer?->to_warehouse_id).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
        </div>
    </div>

    <?php if(!Route::is(routePrefix() . '.stockTransfers.show')): ?>
        <div class="group relative !mt-4" tabindex="0">
            <?php if (isset($component)) { $__componentOriginal0a9614842ee9e3735e691e614c4eb027 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a9614842ee9e3735e691e614c4eb027 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SearchInput::resolve(['label' => 'Product','class' => 'stocks-product-search-input','name' => '','placeholder' => 'Search product by name','value' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SearchInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $attributes = $__attributesOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__attributesOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a9614842ee9e3735e691e614c4eb027)): ?>
<?php $component = $__componentOriginal0a9614842ee9e3735e691e614c4eb027; ?>
<?php unset($__componentOriginal0a9614842ee9e3735e691e614c4eb027); ?>
<?php endif; ?>

            <div
                class="stock-product-search absolute z-[1] bg-background rounded-md right-0 top-[calc(100%)] w-full min-w-[300px] min-h-[150px] shadow max-h-[350px] overflow-y-auto p-[2px] divide-y divide-[#78787829] hidden group-focus-within:block transition-all duration-300">

                <div class="block py-4 px-6 bg-theme-primary/[.03] text-muted font-bold">
                    <span class="uppercase"><?php echo e(translate('Search Results')); ?></span>
                </div>

                
                <div class="divide-y divide-[#78787829] stock-search-results">
                    <?php echo $__env->make(
                        'backend.' . routePrefix() . '.inventory.stock-transfers.product-search-results',
                        [
                            'productVariations' => [],
                        ]
                    , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="!mt-4">
        <label class="theme-input-label !pt-0 input-required">
            <?php echo e(translate('Transferred Items')); ?>

        </label>
        <?php
            $stockProductVariations = collect();
            if ($stockTransfer) {
                $stockProductVariations = $stockTransfer->productVariations;
            }
        ?>

        <?php echo $__env->make('backend.' . routePrefix() . '.inventory.stock-transfers.stock-products-table', [
            'stockProductVariations' => $stockProductVariations,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    

    <?php if (isset($component)) { $__componentOriginale582db01b056b256cb800ff6b8d80bac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale582db01b056b256cb800ff6b8d80bac = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Textarea::resolve(['label' => 'Note','labelInline' => false,'name' => 'note','placeholder' => 'Type few words...','value' => ''.e($stockTransfer?->note).'','isRequired' => false,'isDisabled' => ''.e(Route::is(routePrefix() . '.stockTransfers.show') ? true : false).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $attributes = $__attributesOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__attributesOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $component = $__componentOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__componentOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>

    <?php if(!Route::is(routePrefix() . '.stockTransfers.show')): ?>
        <div class="flex justify-end">
            <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['buttonText' => 'Save Changes','type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php if(!Route::is(routePrefix() . '.stockTransfers.show')): ?>
    </form>
<?php endif; ?>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/forms/stock-transfer-form.blade.php ENDPATH**/ ?>