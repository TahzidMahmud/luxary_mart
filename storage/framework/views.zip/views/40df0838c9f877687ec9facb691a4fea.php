<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Stock Transfer')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Stock Transfer List')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="font-bold "><?php echo e(translate('Dashboard')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Stock Transfer List')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="card theme-table">
        <div
            class="card__title border-none theme-table__filter flex flex-col md:flex-row xl:items-center justify-between gap-3">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_stock_transfer')): ?>
                <?php if (isset($component)) { $__componentOriginaldbabb662c3b9843f55fe55cc2492a70a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Link::resolve(['href' => ''.e(route('admin.stockTransfers.create')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Link::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <span class="text-xl">
                        <i class="fal fa-plus"></i>
                    </span> <?php echo e(translate('Add New')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a)): ?>
<?php $attributes = $__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a; ?>
<?php unset($__attributesOriginaldbabb662c3b9843f55fe55cc2492a70a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbabb662c3b9843f55fe55cc2492a70a)): ?>
<?php $component = $__componentOriginaldbabb662c3b9843f55fe55cc2492a70a; ?>
<?php unset($__componentOriginaldbabb662c3b9843f55fe55cc2492a70a); ?>
<?php endif; ?>
            <?php else: ?>
                <div></div>
            <?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\SearchForm::resolve(['searchKey' => ''.e($searchKey).'','class' => 'max-w-[380px]','placeholder' => 'Type warehouse name & hit enter'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\SearchForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $attributes = $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $component = $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
        </div>

        <table class="product-list-table footable w-full">
            <thead class="uppercase text-left bg-theme-primary/10">
                <tr>
                    <th data-breakpoints="xs sm">
                        #
                    </th>
                    <th data-breakpoints="xs sm">
                        <?php echo e(translate('Date')); ?>

                    </th>
                    <th>
                        <?php echo e(translate('From Warehouse')); ?>

                    </th>
                    <th>
                        <?php echo e(translate('To Warehouse')); ?>

                    </th>

                    <th data-breakpoints="xs sm">
                        <?php echo e(translate('Total Products')); ?>

                    </th>

                    <th data-breakpoints="xs sm" class="w-[180px]">
                        <?php echo e(translate('Options')); ?>

                    </th>
                </tr>
            </thead>
            <tbody class="po-order-tbody">
                <?php $__currentLoopData = $stockTransfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $stockTransfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key + 1 + ($stockTransfers->currentPage() - 1) * $stockTransfers->perPage()); ?>

                        </td>
                        <td>
                            <div class=" line-clamp-2">
                                <?php echo e(date('d M, Y', strtotime($stockTransfer->created_at))); ?>

                            </div>
                        </td>
                        <td>
                            <span class="px-2 py-1 text-xs text-white rounded-md leading-none capitalize bg-red-500">
                                <?php echo e($stockTransfer->fromWarehouse?->name ?? translate('N/A')); ?>

                            </span>
                        </td>

                        <td>
                            <span class="px-2 py-1 text-xs text-white rounded-md leading-none capitalize bg-green-500">
                                <?php echo e($stockTransfer->toWarehouse?->name ?? translate('N/A')); ?>

                            </span>
                        </td>


                        <td>
                            <div class=" line-clamp-2">
                                <?php echo e($stockTransfer->productVariations()->count()); ?>

                            </div>
                        </td>


                        <td>
                            <div class="option-dropdown w-full" tabindex="0">
                                <div class="option-dropdown__toggler bg-theme-secondary/10 text-theme-secondary">
                                    <span><?php echo e(translate('Actions')); ?></span>
                                </div>

                                <div class="option-dropdown__options">
                                    <ul>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_stock_transfer_details')): ?>
                                            <li>
                                                <a href="<?php echo e(route('admin.stockTransfers.show', ['transfer' => $stockTransfer->id])); ?>"
                                                    class="option-dropdown__option">
                                                    <?php echo e(translate('Details')); ?>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="card__footer">
            <?php echo e($stockTransfers->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/inventory/stock-transfers/index.blade.php ENDPATH**/ ?>