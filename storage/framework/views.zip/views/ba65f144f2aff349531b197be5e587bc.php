<form
    action="<?php echo e($product ? route(routePrefix() . '.products.update', $product->id) : route(routePrefix() . '.products.store')); ?>"
    method="POST" id="product-form">
    <?php echo csrf_field(); ?>
    <?php if($product): ?>
        <input type="hidden" name="lang_key" value="<?php echo e($langKey); ?>">
    <?php else: ?>
        <?php
            $langKey = config('app.default_language');
        ?>
    <?php endif; ?>

    <div class="grid md:grid-cols-12 gap-3">
        <div class="md:col-span-8 md:row-span-2">
            
            <div class="card">
                <div class="card__title flex justify-between items-center">
                    <?php echo e(translate('General Informations')); ?>

                    <?php if($product): ?>
                        <?php if (isset($component)) { $__componentOriginald150fad69db3299536e688309c11a8e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald150fad69db3299536e688309c11a8e2 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\ChangeLanguages::resolve(['langKey' => ''.e($langKey).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.change-languages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\ChangeLanguages::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '!text-sm !font-normal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald150fad69db3299536e688309c11a8e2)): ?>
<?php $attributes = $__attributesOriginald150fad69db3299536e688309c11a8e2; ?>
<?php unset($__attributesOriginald150fad69db3299536e688309c11a8e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald150fad69db3299536e688309c11a8e2)): ?>
<?php $component = $__componentOriginald150fad69db3299536e688309c11a8e2; ?>
<?php unset($__componentOriginald150fad69db3299536e688309c11a8e2); ?>
<?php endif; ?>
                    <?php endif; ?>
                </div>

                <div class="card__content">
                    <div class="space-y-3">
                        <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Product Name','name' => 'name','placeholder' => 'Type product name','value' => ''.e($product?->collectTranslation('name', $langKey)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>

                        <div class="unit-tree-data">
                            <?php echo $__env->make('components.backend.inc.products.unit-list', [
                                'product' => $product,
                                'units' => $units,
                                'selectedUnit' => null,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>


                        <?php if(user()->user_type != 'seller'): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_units')): ?>
                                <div class="text-end !my-3">
                                    <a href="javascript:void(0);" class="text-theme-secondary-light unit-create-modal"
                                        data-micromodal-trigger="unit-create-modal">
                                        <?php echo e(translate('Add New Unit')); ?>

                                        <span class="ml-2">
                                            <i class="fa-solid fa-plus"></i>
                                        </span>
                                    </a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if(!$product || ($product && $langKey == config('app.default_language'))): ?>
                            <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['label' => 'Min Purchase Quantity','name' => 'min_purchase_qty','placeholder' => 'Type minimum purchase quantity','value' => ''.e($product?->min_purchase_qty ?? 1).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['label' => 'Max Purchase Quantity','name' => 'max_purchase_qty','placeholder' => 'Type maximum purchase quantity','value' => ''.e($product?->max_purchase_qty ?? 1).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if(!$product || ($product && $langKey == config('app.default_language'))): ?>
                
                <div class="card mt-3">
                    <div class="card__title">
                        <?php echo e(translate('Product Images')); ?>

                    </div>
                    <div class="card__content">
                        <div class="space-y-3">
                            <?php if (isset($component)) { $__componentOriginalbcbda3596773ae205278bc8929e0d504 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbcbda3596773ae205278bc8929e0d504 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\File::resolve(['label' => 'Product Image','name' => 'thumbnail_image','value' => ''.e($product?->thumbnail_image).'','filesHint' => 'This image will be used as thumbnail image of product. Recommended size: 512*512'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\File::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $attributes = $__attributesOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__attributesOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $component = $__componentOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__componentOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginalbcbda3596773ae205278bc8929e0d504 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbcbda3596773ae205278bc8929e0d504 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\File::resolve(['multiple' => true,'label' => 'Gallery Images','name' => 'gallery_images','value' => ''.e($product?->gallery_images).'','filesHint' => 'These images will be used as slider images of product in details page. Recommended size: 512*512'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\File::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $attributes = $__attributesOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__attributesOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $component = $__componentOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__componentOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginalbcbda3596773ae205278bc8929e0d504 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbcbda3596773ae205278bc8929e0d504 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\File::resolve(['multiple' => true,'label' => 'Real Images','name' => 'real_pictures','value' => ''.e($product?->real_pictures).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\File::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $attributes = $__attributesOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__attributesOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbcbda3596773ae205278bc8929e0d504)): ?>
<?php $component = $__componentOriginalbcbda3596773ae205278bc8929e0d504; ?>
<?php unset($__componentOriginalbcbda3596773ae205278bc8929e0d504); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>

                
                <div class="card mt-3">
                    <div class="card__title">
                        <div class="flex items-center justify-between">
                            <span><?php echo e(translate('Product Price & Stock')); ?></span>
                            <span>
                                <span class="flex items-center">
                                    <label for="is_variant" class="cursor-pointer">
                                        <?php echo e(translate('Has Variations?')); ?>

                                    </label>
                                    <span class="ms-3">
                                        <?php if (isset($component)) { $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Checkbox::resolve(['toggler' => 'true','name' => 'is_variant','isChecked' => $product?->has_variation] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'is_variant','onchange' => 'isVariantProduct(this)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $attributes = $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $component = $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
                                    </span>
                                </span>

                            </span>
                        </div>
                    </div>

                    <div class="card__content">
                        
                        <div class="noVariation space-y-3"
                            <?php if($product?->has_variation): ?> style="display:none;" <?php endif; ?>>

                            <?php
                                $price = 0;
                                $stock_qty = 0;
                                $sku = null;
                                $code = null;
                                $discount_value = 0;
                                $discount_type = 'amount';

                                if ($product) {
                                    $firstVariation = $product->variations()->first();
                                    if ($firstVariation) {
                                        $price = $firstVariation->price;
                                        $discount_value = $firstVariation->discount_value;
                                        $discount_type = $firstVariation->discount_type;

                                        $defaultWarehouse = shop()->warehouses()->where('is_default', 1)->first();
                                        if ($defaultWarehouse) {
                                            $stock = $firstVariation
                                                ->productVariationStocks()
                                                ->where('warehouse_id', $defaultWarehouse->id)
                                                ->first();
                                            if ($stock) {
                                                $stock_qty = $stock->stock_qty;
                                            }
                                        }

                                        $sku = $firstVariation->sku;
                                        $code = $firstVariation->code;
                                    }
                                }
                            ?>

                            <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['label' => 'Price','name' => 'price','placeholder' => 'Type price of product','value' => ''.e($price).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '0','step' => '0.001']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['label' => 'Sku','name' => 'sku','placeholder' => 'Type sku of product','value' => ''.e($sku).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>

                            <?php if(!useInventory()): ?>
                                <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['label' => 'Stock','name' => 'stock_qty','placeholder' => 'Type stock of product','value' => ''.e($stock_qty).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
                            <?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['label' => 'Discount Value','name' => 'discount_value','isRequired' => false,'value' => ''.e($discount_value).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '0','step' => '0.001']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['label' => 'Discount Type','name' => 'discount_type','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-search' => 'false']); ?>
                                <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Amount')).'','value' => 'amount','selected' => ''.e($discount_type).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Percentage')).'','value' => 'percentage','selected' => ''.e($discount_type).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
                        </div>

                        
                        <div class="hasVariation space-y-3"
                            <?php if($product && !$product->has_variation): ?> style="display:none;" <?php elseif(!$product): ?> style="display:none;" <?php endif; ?>>
                            
                            <div class="chosen_variation_options">
                                <?php if(!$product || !$product?->has_variation): ?>
                                    <div class="grid md:grid-cols-2 gap-3">
                                        <div class="md:col-span-1">
                                            <div class="flex items-center">
                                                <div class="w-full"><?php echo e(translate('Attribute')); ?> <span
                                                        class="attribute-counter">1</span></div>
                                                <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['groupClass' => 'w-full ms-4','name' => 'chosen_variations[]','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onchange' => 'getVariationValues(this)','class' => 'chosen_variations','data-search' => 'false']); ?>
                                                    <option value=""><?php echo e(translate('Select Variation')); ?>

                                                        <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e($variation->collectTranslation('name')).'','value' => ''.e($variation->id).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="md:col-span-1">
                                            <div class="flex items-center">
                                                <div class="variationvalues w-full">
                                                    <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => '','placeholder' => 'Select variation values'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                                                </div>
                                                <button class="button button-default" type="button"
                                                    onclick="addAnotherVariation()">
                                                    <span class="footable-toggle fooicon fooicon-plus"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <?php $__currentLoopData = generateVariationCombinations($product->variationCombinations()->get()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $combination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="grid md:grid-cols-2 gap-3 mb-3">
                                            <div class="md:col-span-1">
                                                <div class="flex items-center">
                                                    <div class="w-full"><?php echo e(translate('Attribute')); ?> <span
                                                            class="attribute-counter"><?php echo e($key + 1); ?></span></div>

                                                    <input type="hidden" name="chosen_variations[]"
                                                        value="<?php echo e($combination['id']); ?>">
                                                    <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => '','value' => ''.e($combination['name']).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ms-4','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="md:col-span-1">
                                                <div class="flex items-center">
                                                    <div class="variationvalues w-full">
                                                        <?php
                                                            $variation_values = \App\Models\VariationValue::where(
                                                                'variation_id',
                                                                $combination['id'],
                                                            )->get();
                                                            $old_val = array_map(function ($val) {
                                                                return $val['id'];
                                                            }, $combination['values']);

                                                        ?>

                                                        <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['name' => 'option_'.e($combination['id']).'_choices[]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onchange' => 'generateVariationCombinations()','data-placeholder' => ''.e(translate('Select values here')).'','multiple' => true,'data-selection-css-class' => 'multi-select2']); ?>
                                                            <?php $__currentLoopData = $variation_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e($variation_value->collectTranslation('name')).'','value' => ''.e($variation_value->id).'','selected' => ''.e(in_array($variation_value->id, $old_val) ? $variation_value->id : '').''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>

                                                    </div>
                                                    <?php if($key == 0): ?>
                                                        <button class="button button-default" type="button"
                                                            onclick="addAnotherVariation()">
                                                            <span class="footable-toggle fooicon fooicon-plus"></span>
                                                        </button>
                                                    <?php else: ?>
                                                        <button class="button button-default" type="button"
                                                            onclick="removeVariation(this)">
                                                            <span class="footable-toggle fooicon fooicon-minus"></span>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            

                            <div class="variation_combination" id="variation_combination">
                                
                                <?php if($product && $product->has_variation): ?>
                                    <?php echo $__env->make('backend.admin.products.update-variation-combinations', [
                                        'combinations' => $product->variations,
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mt-3 space-y-3">
                            <?php
                                $start_date = date('m/d/Y');
                                $end_date = date('m/d/Y');

                                if ($product) {
                                    $start_date = $product->discount_start_date
                                        ? date('m/d/Y', $product->discount_start_date)
                                        : date('m/d/Y');
                                    $end_date = $product->discount_end_date
                                        ? date('m/d/Y', $product->discount_end_date)
                                        : date('m/d/Y');
                                }
                            ?>

                            <?php if (isset($component)) { $__componentOriginal73a08ec365b68163e5a99ef991f25cd2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73a08ec365b68163e5a99ef991f25cd2 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Datepicker::resolve(['placeholder' => 'Start date - End date','label' => 'Discount Schedule','name' => 'date_range','isRequired' => false,'type' => 'range','value' => ''.e($start_date . ' - ' . $end_date).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.datepicker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Datepicker::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73a08ec365b68163e5a99ef991f25cd2)): ?>
<?php $attributes = $__attributesOriginal73a08ec365b68163e5a99ef991f25cd2; ?>
<?php unset($__attributesOriginal73a08ec365b68163e5a99ef991f25cd2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73a08ec365b68163e5a99ef991f25cd2)): ?>
<?php $component = $__componentOriginal73a08ec365b68163e5a99ef991f25cd2; ?>
<?php unset($__componentOriginal73a08ec365b68163e5a99ef991f25cd2); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>

            <?php endif; ?>
            
            <div class="card mt-3">
                <div class="card__title">
                    <?php echo e(translate('Product Description')); ?>

                </div>

                <div class="card__content">
                    <div class="space-y-3">
                        <?php if (isset($component)) { $__componentOriginale582db01b056b256cb800ff6b8d80bac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale582db01b056b256cb800ff6b8d80bac = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Textarea::resolve(['rich' => 'true','name' => 'description','placeholder' => 'Type description of product','value' => ''.e($product?->collectTranslation('description', $langKey)).'','isRequired' => false,'aiGenerate' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $attributes = $__attributesOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__attributesOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale582db01b056b256cb800ff6b8d80bac)): ?>
<?php $component = $__componentOriginale582db01b056b256cb800ff6b8d80bac; ?>
<?php unset($__componentOriginale582db01b056b256cb800ff6b8d80bac); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if(!$product || ($product && $langKey == config('app.default_language'))): ?>
                
                <div class="card mt-3">
                    <div class="card__title">
                        <?php echo e(translate('Product SEO Informations')); ?>

                    </div>

                    <div class="card__content">
                        <div class="space-y-3">
                            <?php if (isset($component)) { $__componentOriginal040ec92a5abd81238e24d0158e728f63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal040ec92a5abd81238e24d0158e728f63 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Seo::resolve(['metaTitle' => ''.e($product?->meta_title).'','metaDescription' => ''.e($product?->meta_description).'','metaKeywords' => ''.e($product?->meta_keywords).'','metaImage' => ''.e($product?->meta_image).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.seo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Seo::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal040ec92a5abd81238e24d0158e728f63)): ?>
<?php $attributes = $__attributesOriginal040ec92a5abd81238e24d0158e728f63; ?>
<?php unset($__attributesOriginal040ec92a5abd81238e24d0158e728f63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal040ec92a5abd81238e24d0158e728f63)): ?>
<?php $component = $__componentOriginal040ec92a5abd81238e24d0158e728f63; ?>
<?php unset($__componentOriginal040ec92a5abd81238e24d0158e728f63); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="justify-end mt-6 hidden md:flex">
                <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['buttonText' => 'Save Product','type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
            </div>
        </div>

        
        <?php if(!$product || ($product && $langKey == config('app.default_language'))): ?>
            <div class="md:col-span-4 space-y-3">
                
                <div class="card">
                    <div class="card__title">
                        <?php echo e(translate('Product Status')); ?>

                    </div>
                    <div class="card__content">
                        <div class="space-y-5">
                            <?php if($product && $langKey == config('app.default_language')): ?>
                                <div>
                                    <label class="mb-2">
                                        <?php echo e(translate('Slug')); ?>

                                        <span class="text-muted ml-2"><?php echo e(url('/products')); ?>/</span>
                                    </label>
                                    <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => 'slug','placeholder' => 'Type custom slug','value' => ''.e($product?->slug).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                                </div>


                                <a href="<?php echo e(url('/products')); ?>/<?php echo e($product?->slug); ?>" target="_blank">
                                    <?php echo e(translate('Visit Product')); ?>

                                    <span class="ml-2 text-theme-secondary-light">
                                        <i class="fa-solid fa-eye"></i>
                                    </span>
                                </a>
                            <?php endif; ?>
                            <div class="flex items-center justify-between">
                                <p><?php echo e(translate('Published')); ?></p>
                                <?php if (isset($component)) { $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Checkbox::resolve(['toggler' => 'true','name' => 'is_published','value' => '1','isChecked' => $product?->is_published] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $attributes = $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $component = $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
                            </div>

                            <?php if($product): ?>
                                <div class="flex justify-between gap-4">
                                    <span><?php echo e(translate('Date Created')); ?></span>
                                    <span
                                        class="text-muted"><?php echo e(date('d M, Y', strtotime($product->created_at))); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                
                <div class="card">
                    <div class="card__title">
                        <?php echo e(translate('Product Categories')); ?>

                    </div>
                    <div class="card__content">
                        <?php
                            $productCategories = $product ? $product->categories()->pluck('category_id') : collect();
                        ?>

                        <ul class="max-h-[315px] overflow-y-auto cateogry-tree">
                            <div class="category-tree-data space-y-5">
                                <?php echo $__env->make('components.backend.inc.products.category-list', [
                                    'categories' => $categories,
                                    'productCategories' => $productCategories,
                                    'selectedCategories' => [],
                                    'langKey' => $langKey,
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </ul>
                        <?php if(user()->user_type != 'seller'): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_categories')): ?>
                                <a href="javascript:void(0);"
                                    class="text-theme-secondary-light !mt-7 category-create-modal"
                                    data-micromodal-trigger="category-create-modal">
                                    <?php echo e(translate('Add New Category')); ?>

                                    <span class="ml-2">
                                        <i class="fa-solid fa-plus"></i>
                                    </span>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="card">
                    <div class="card__title">
                        <?php echo e(translate('Product Brand')); ?>

                    </div>
                    <div class="card__content">
                        <ul class="space-y-5 max-h-[315px] overflow-y-auto brand-tree-data">

                            <?php echo $__env->make('components.backend.inc.products.brand-list', [
                                'product' => $product,
                                'langKey' => $langKey,
                                'selectedBrand' => null,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>

                        <?php if(user()->user_type != 'seller'): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_brands')): ?>
                                <a href="javascript:void(0);" class="text-theme-secondary-light !mt-4 brand-create-modal"
                                    data-micromodal-trigger="brand-create-modal">
                                    <?php echo e(translate('Add New Brand')); ?>

                                    <span class="ml-2">
                                        <i class="fa-solid fa-plus"></i>
                                    </span>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="card">
                    <div class="card__title">
                        <?php echo e(translate('Tags and Badges')); ?>

                    </div>

                    <div class="card__content">
                        <div class="space-y-8">
                            <div>
                                <?php
                                    $productTags = collect();
                                    if ($product) {
                                        $productTags = $product->tags()->pluck('tag_id');
                                    }
                                ?>
                                <div class="mb-2 flex justify-between">
                                    <span><?php echo e(translate('Tags')); ?></span>

                                    <?php if(user()->user_type != 'seller'): ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_tags')): ?>
                                            <a href="javascript:void(0);"
                                                class="text-theme-secondary-light tag-create-modal"
                                                data-micromodal-trigger="tag-create-modal">

                                                <span class="mr-1">
                                                    <i class="fa-solid fa-plus"></i>
                                                </span>
                                                <?php echo e(translate('Add New Tag')); ?>

                                            </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>

                                <div class="tag-tree-data">
                                    <?php echo $__env->make('components.backend.inc.products.tag-list', [
                                        'tags' => $tags,
                                        'productTags' => $productTags,
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>

                            <div>
                                <div class="mb-2 flex justify-between">
                                    <span><?php echo e(translate('Badges')); ?></span>

                                    <?php if(user()->user_type != 'seller'): ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_badges')): ?>
                                            <a href="javascript:void(0);"
                                                class="text-theme-secondary-light badge-create-modal"
                                                data-micromodal-trigger="badge-create-modal">

                                                <span class="mr-1">
                                                    <i class="fa-solid fa-plus"></i>
                                                </span>
                                                <?php echo e(translate('Add New Badge')); ?>

                                            </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                <?php
                                    $productBadges = collect();
                                    if ($product) {
                                        $productBadges = $product->badges()->pluck('badge_id');
                                    }
                                ?>

                                <div class="badge-tree-data">
                                    <?php echo $__env->make('components.backend.inc.products.badge-list', [
                                        'badges' => $badges,
                                        'productBadges' => $productBadges,
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card">
                    <div class="card__title flex items-center justify-between">
                        <span>
                            <?php echo e(translate('Product Taxes')); ?>

                        </span>

                        <small class="muted">
                            (<?php echo e(translate('Default 0%')); ?>)
                        </small>
                    </div>
                    <div class="card__content">
                        <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $taxValue = 0;
                                $taxType = 'amount';
                                if ($product && $product->taxes()->count() > 0) {
                                    $productTax = $product->taxes()->firstWhere('tax_id', $tax->id);
                                    $taxValue = $productTax->tax_value;
                                    $taxType = $productTax->tax_type;
                                }
                            ?>
                            <input type="hidden" value="<?php echo e($tax->id); ?>" name="tax_ids[]">
                            <div class="mb-4">
                                <label for="" class="theme-input-label !pt-0">
                                    <?php echo e($tax->name); ?>

                                </label>
                                <div class="grid md:grid-cols-2 gap-3">
                                    <div class="md:col-span-1">
                                        <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['name' => 'tax_values[]','value' => ''.e($taxValue).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '0','step' => '0.001']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
                                    </div>
                                    <div class="md:col-span-1">
                                        <?php if (isset($component)) { $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Select::resolve(['name' => 'tax_types[]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>
                                            <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Amount')).'','value' => 'amount','selected' => ''.e($taxType).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal8b4dd75f801619a90ab5f7500d95647d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\SelectOption::resolve(['name' => ''.e(translate('Percentage')).'','value' => 'percentage','selected' => ''.e($taxType).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\SelectOption::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $attributes = $__attributesOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__attributesOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d)): ?>
<?php $component = $__componentOriginal8b4dd75f801619a90ab5f7500d95647d; ?>
<?php unset($__componentOriginal8b4dd75f801619a90ab5f7500d95647d); ?>
<?php endif; ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $attributes = $__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__attributesOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9)): ?>
<?php $component = $__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9; ?>
<?php unset($__componentOriginal4b6a5b9a10116f09f415a8f6085f81e9); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card__title flex items-center justify-between">
                        <span>
                            <?php echo e(translate('Other Informations')); ?>

                        </span>
                    </div>
                    <div class="card__content">
                        <div class="space-y-8">

                            
                            <div>
                                <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['labelInline' => false,'label' => 'Commission Rate','name' => 'commission_rate','placeholder' => 'Type commission %','value' => ''.e($product?->commission_rate).'','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['step' => '0.001']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
                            </div>

                            
                            <div>
                                <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['labelInline' => false,'label' => 'Estimated Delivery Time','name' => 'est_delivery_time','placeholder' => 'Type etimated delivery hours','value' => ''.e($product?->est_delivery_time).'','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                            </div>

                            
                            <div class="flex items-center justify-between">
                                <p><?php echo e(translate('EMI Available')); ?></p>
                                <?php if (isset($component)) { $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Checkbox::resolve(['toggler' => 'true','name' => 'has_emi','value' => '1','isChecked' => $product?->has_emi] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $attributes = $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $component = $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
                            </div>

                            <div>
                                <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['labelInline' => false,'label' => 'Emi Info','name' => 'emi_info','placeholder' => 'Type EMI info if available','value' => ''.e($product?->emi_info).'','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                            </div>

                            
                            <div class="flex items-center justify-between">
                                <p><?php echo e(translate('Warrenty Available')); ?></p>
                                <?php if (isset($component)) { $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Checkbox::resolve(['toggler' => 'true','name' => 'has_warranty','value' => '1','isChecked' => $product?->has_warranty] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $attributes = $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $component = $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
                            </div>

                            <div>
                                <label class="mb-2" for="warranty_info"><?php echo e(translate('Warranty Info')); ?></label>
                                <?php if (isset($component)) { $__componentOriginal81f02f0df24cc00639f974cb177f9230 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81f02f0df24cc00639f974cb177f9230 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Text::resolve(['name' => 'warranty_info','placeholder' => 'Type Warranty info','value' => ''.e($product?->warranty_info).'','isRequired' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Text::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $attributes = $__attributesOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__attributesOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81f02f0df24cc00639f974cb177f9230)): ?>
<?php $component = $__componentOriginal81f02f0df24cc00639f974cb177f9230; ?>
<?php unset($__componentOriginal81f02f0df24cc00639f974cb177f9230); ?>
<?php endif; ?>
                            </div>

                            
                            <div>
                                <?php if (isset($component)) { $__componentOriginale6804915af63961e1b21820879fb521e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6804915af63961e1b21820879fb521e = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Number::resolve(['labelInline' => false,'label' => 'Alert Quantity','name' => 'alert_qty','placeholder' => 'Type alert quantity','value' => ''.e($product?->alert_qty ?? 0).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Number::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['min' => '0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $attributes = $__attributesOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__attributesOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6804915af63961e1b21820879fb521e)): ?>
<?php $component = $__componentOriginale6804915af63961e1b21820879fb521e; ?>
<?php unset($__componentOriginale6804915af63961e1b21820879fb521e); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="flex justify-end mt-6 md:hidden">
        <?php if (isset($component)) { $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Button::resolve(['buttonText' => 'Save Product','type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $attributes = $__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__attributesOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95)): ?>
<?php $component = $__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95; ?>
<?php unset($__componentOriginald16eeb4bf49f503cf4cdc4bd20a90f95); ?>
<?php endif; ?>
    </div>
</form>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/forms/product-form.blade.php ENDPATH**/ ?>