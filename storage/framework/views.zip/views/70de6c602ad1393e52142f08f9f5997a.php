<a href="javascript:void(0);" data-href="<?php echo e($href); ?>" data-title="<?php echo e(translate($title)); ?>"
    data-text="<?php echo e(translate($text)); ?>" data-method="DELETE" data-micromodal-trigger="confirm-modal"
    <?php echo e($attributes->merge(['class' => 'option-dropdown__option confirm-modal'])); ?>>
    <?php echo translate($btnText); ?>

</a>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/delete-link.blade.php ENDPATH**/ ?>