<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Tag List')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Tag List')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="font-bold "><?php echo e(translate('Dashboard')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Tag List')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="grid md:grid-cols-5 gap-3">
        <div class="md:col-span-3">
            <div class="card theme-table">
                <div
                    class="card__title border-none theme-table__filter flex flex-col md:flex-row xl:items-center justify-end gap-3">
                    <?php if (isset($component)) { $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\SearchForm::resolve(['searchKey' => ''.e($searchKey).'','class' => 'max-w-[380px]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\SearchForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $attributes = $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $component = $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
                </div>

                <table class="product-list-table footable w-full">
                    <thead class="uppercase text-left bg-theme-primary/10">
                        <tr>
                            <th>
                                #
                            </th>
                            <th class="">
                                <?php echo e(translate('Tag Details')); ?>

                            </th>
                            <th class="w-[130px]">
                                <?php echo e(translate('Options')); ?>

                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1 + ($tags->currentPage() - 1) * $tags->perPage()); ?></td>
                                <td class="">
                                    <div class="inline-flex items-center gap-4">
                                        <div class=" line-clamp-2">
                                            <?php echo e($tag->name); ?>

                                        </div>
                                    </div>
                                </td>



                                <td>
                                    <div class="option-dropdown" tabindex="0">
                                        <div class="option-dropdown__toggler bg-theme-secondary/10 text-theme-secondary">
                                            <span><?php echo e(translate('Actions')); ?></span>
                                        </div>

                                        <div class="option-dropdown__options">
                                            <ul>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_tags')): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('admin.tags.edit', ['tag' => $tag->id, 'lang_key' => config('app.default_language')])); ?>&translate"
                                                            class="option-dropdown__option">
                                                            <?php echo e(translate('Edit')); ?>

                                                        </a>
                                                    </li>
                                                <?php endif; ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_tags')): ?>
                                                    <li>
                                                        <?php if (isset($component)) { $__componentOriginalf2f51adcf06edeb87dc06426610dc8e6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2f51adcf06edeb87dc06426610dc8e6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\DeleteLink::resolve(['href' => ''.e(route('admin.tags.destroy', $tag->id)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.delete-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\DeleteLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2f51adcf06edeb87dc06426610dc8e6)): ?>
<?php $attributes = $__attributesOriginalf2f51adcf06edeb87dc06426610dc8e6; ?>
<?php unset($__attributesOriginalf2f51adcf06edeb87dc06426610dc8e6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2f51adcf06edeb87dc06426610dc8e6)): ?>
<?php $component = $__componentOriginalf2f51adcf06edeb87dc06426610dc8e6; ?>
<?php unset($__componentOriginalf2f51adcf06edeb87dc06426610dc8e6); ?>
<?php endif; ?>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="card__footer">
                    <?php echo e($tags->links()); ?>

                </div>
            </div>
        </div>
        <div class="md:col-span-2">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_tags')): ?>
                <div class="card">
                    <h4 class="card__title"><?php echo e(translate('Add New Tag')); ?></h4>
                    <div class="card__content">
                        <?php if (isset($component)) { $__componentOriginal46d89ef8f122e71d75fbac2b994e3564 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal46d89ef8f122e71d75fbac2b994e3564 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\TagForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.tag-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\TagForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal46d89ef8f122e71d75fbac2b994e3564)): ?>
<?php $attributes = $__attributesOriginal46d89ef8f122e71d75fbac2b994e3564; ?>
<?php unset($__attributesOriginal46d89ef8f122e71d75fbac2b994e3564); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46d89ef8f122e71d75fbac2b994e3564)): ?>
<?php $component = $__componentOriginal46d89ef8f122e71d75fbac2b994e3564; ?>
<?php unset($__componentOriginal46d89ef8f122e71d75fbac2b994e3564); ?>
<?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/resources/tags/index.blade.php ENDPATH**/ ?>