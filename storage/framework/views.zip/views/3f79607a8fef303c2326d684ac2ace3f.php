<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Add New Product')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Add New Product')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.products.index')); ?>" class="font-bold "><?php echo e(translate('Products')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Add New Product')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->
    <!-- start::product-form -->
    <?php if (isset($component)) { $__componentOriginal14748bda978376331f05dd5169160ea7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14748bda978376331f05dd5169160ea7 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\ProductForm::resolve(['categories' => $categories,'brands' => $brands,'units' => $units,'variations' => $variations,'taxes' => $taxes,'tags' => $tags,'badges' => $badges] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.product-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\ProductForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14748bda978376331f05dd5169160ea7)): ?>
<?php $attributes = $__attributesOriginal14748bda978376331f05dd5169160ea7; ?>
<?php unset($__attributesOriginal14748bda978376331f05dd5169160ea7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14748bda978376331f05dd5169160ea7)): ?>
<?php $component = $__componentOriginal14748bda978376331f05dd5169160ea7; ?>
<?php unset($__componentOriginal14748bda978376331f05dd5169160ea7); ?>
<?php endif; ?>
    <!-- end::product-form -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <?php if (isset($component)) { $__componentOriginal6f19e8eb106d8e95e928603277000822 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6f19e8eb106d8e95e928603277000822 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.backend.inc.product-scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inc.product-scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6f19e8eb106d8e95e928603277000822)): ?>
<?php $attributes = $__attributesOriginal6f19e8eb106d8e95e928603277000822; ?>
<?php unset($__attributesOriginal6f19e8eb106d8e95e928603277000822); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6f19e8eb106d8e95e928603277000822)): ?>
<?php $component = $__componentOriginal6f19e8eb106d8e95e928603277000822; ?>
<?php unset($__componentOriginal6f19e8eb106d8e95e928603277000822); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/products/create.blade.php ENDPATH**/ ?>