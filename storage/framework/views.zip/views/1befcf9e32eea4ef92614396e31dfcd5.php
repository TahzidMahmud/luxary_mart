<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Orders')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>


    <?php $__env->startSection('content'); ?>
        <div id="app" class="bg-background-primary-light"></div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
        <script>
            window.config = <?php echo json_encode($settings, 15, 512) ?>;
        </script>

        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/backend/order/Index.tsx']); ?>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/backend/admin/orders/index.blade.php ENDPATH**/ ?>