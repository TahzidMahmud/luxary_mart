<option <?php echo e($attributes->merge()); ?> value="<?php echo e($value); ?>" <?php if($selected != null && $selected == $value): echo 'selected'; endif; ?>>
    <?php echo $name; ?>

</option>
<?php /**PATH /Users/m2pro/Downloads/well-known/resources/views/components/backend/inputs/select-option.blade.php ENDPATH**/ ?>