<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Update Category')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm sm:text-base font-bold">
                <?php echo e(translate('Update Category')); ?>

            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="font-bold "><?php echo e(translate('Dashboard')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <a href="<?php echo e(route('admin.categories.index')); ?>" class="font-bold "><?php echo e(translate('Category List')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Update')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="grid xl:grid-cols-12">
        <div class="xl:col-span-7">
            <div class="card">
                <div class="card__content">
                    <div class="flex justify-end mb-3">
                        <?php if (isset($component)) { $__componentOriginald150fad69db3299536e688309c11a8e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald150fad69db3299536e688309c11a8e2 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\ChangeLanguages::resolve(['langKey' => ''.e($lang_key).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.change-languages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\ChangeLanguages::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald150fad69db3299536e688309c11a8e2)): ?>
<?php $attributes = $__attributesOriginald150fad69db3299536e688309c11a8e2; ?>
<?php unset($__attributesOriginald150fad69db3299536e688309c11a8e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald150fad69db3299536e688309c11a8e2)): ?>
<?php $component = $__componentOriginald150fad69db3299536e688309c11a8e2; ?>
<?php unset($__componentOriginald150fad69db3299536e688309c11a8e2); ?>
<?php endif; ?>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal674c240f153aa133aa09252538384e90 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal674c240f153aa133aa09252538384e90 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\CategoryForm::resolve(['category' => $category,'langKey' => ''.e($lang_key).'','categories' => $categories,'variations' => $variations] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.category-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\CategoryForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal674c240f153aa133aa09252538384e90)): ?>
<?php $attributes = $__attributesOriginal674c240f153aa133aa09252538384e90; ?>
<?php unset($__attributesOriginal674c240f153aa133aa09252538384e90); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal674c240f153aa133aa09252538384e90)): ?>
<?php $component = $__componentOriginal674c240f153aa133aa09252538384e90; ?>
<?php unset($__componentOriginal674c240f153aa133aa09252538384e90); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/categories/edit.blade.php ENDPATH**/ ?>