<?php $__env->startSection('title'); ?>
    <?php echo e(translate('Variation Value List')); ?> | <?php echo e(getSetting('systemName')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- start::dashboard breadcrumb -->
    <div class="dashboard-nav pt-6 flex items-center justify-between mb-9">
        <div class="flex items-center">
            <span class="text-xl mr-3 text-theme-secondary">
                <i class="fa-regular fa-folder"></i>
            </span>
            <span class="text-sm smtext-base font-bold">
                <?php echo e(translate('Variation Value List')); ?> (<?php echo e($variation->collectTranslation('name')); ?>)
            </span>
        </div>

        <div class="max-sm:hidden flex items-center gap-2">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="font-bold "><?php echo e(translate('Dashboard')); ?></a>
            <span class="text-theme-primary dark:text-muted">
                <i class="fa-solid fa-chevron-right"></i>
            </span>
            <p class="text-muted"><?php echo e(translate('Variation Value List')); ?></p>
        </div>
    </div>
    <!-- end::dashboard breadcrumb -->

    <div class="grid md:grid-cols-5 gap-3">
        <div class="md:col-span-3 card theme-table">
            <div
                class="card__title border-none theme-table__filter flex flex-col md:flex-row xl:items-center justify-between gap-3">

                <div></div>

                <?php if (isset($component)) { $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\SearchForm::resolve(['searchKey' => ''.e($searchKey).'','class' => 'max-w-[380px]'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\SearchForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $attributes = $__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__attributesOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4)): ?>
<?php $component = $__componentOriginal345715b96e48f5cd63276a2fb38ef4d4; ?>
<?php unset($__componentOriginal345715b96e48f5cd63276a2fb38ef4d4); ?>
<?php endif; ?>
            </div>

            <table class="product-list-table footable w-full">
                <thead class="uppercase text-left bg-theme-primary/10">
                    <tr>
                        <th>
                            #
                        </th>
                        <th>
                            <?php echo e(translate('Value Name')); ?>

                        </th>
                        <?php if($variation->id == colorVariationId()): ?>
                            <th data-breakpoints="xs sm">
                                <?php echo e(translate('Image')); ?>

                            </th>
                        <?php endif; ?>
                        <th><?php echo e(translate('Show/Hide')); ?></th>
                        <th data-breakpoints="xs sm" class="w-[130px]">
                            <?php echo e(translate('Options')); ?>

                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $variationValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $variationValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1 + ($variationValues->currentPage() - 1) * $variationValues->perPage()); ?>

                            </td>

                            <td>
                                <div class=" line-clamp-2">
                                    <?php echo e($variationValue->collectTranslation('name')); ?>

                                </div>
                            </td>

                            <?php if($variation->id == colorVariationId()): ?>
                                <td>
                                    <img src="<?php echo e(uploadedAsset($variationValue->thumbnail_image)); ?>" alt=""
                                        class="w-12 h-12 lg:w-[70px] lg:h-[80px] rounded-md"
                                        onerror="this.onerror=null;this.src='<?php echo e(asset('images/image-error.png')); ?>';" />
                                </td>
                            <?php endif; ?>

                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_variation_values')): ?>
                                    <?php if (isset($component)) { $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\Checkbox::resolve(['toggler' => 'true','name' => 'isActiveCheckbox','value' => ''.e($variationValue->id).'','isChecked' => ''.e((int) $variationValue->is_active == 1).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\Checkbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-route' => ''.e(route('admin.variation-values.status')).'','data-status' => ''.e($variationValue->is_active).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $attributes = $__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__attributesOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6)): ?>
<?php $component = $__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6; ?>
<?php unset($__componentOriginal8a8ed9c46ff987fb3d139c1e0e4932f6); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </td>

                            <td>
                                <div class="option-dropdown w-[130px]" tabindex="0">
                                    <div class="option-dropdown__toggler bg-theme-secondary/10 text-theme-secondary">
                                        <span><?php echo e(translate('Actions')); ?></span>
                                    </div>

                                    <div class="option-dropdown__options">
                                        <ul>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_variation_values')): ?>
                                                <li>
                                                    <a href="<?php echo e(route('admin.variation-values.edit', ['id' => $variationValue->id, 'lang_key' => config('app.default_language')])); ?>&translate"
                                                        class="option-dropdown__option">
                                                        <?php echo e(translate('Edit')); ?>

                                                    </a>
                                                </li>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_variation_values')): ?>
                                                <li>
                                                    <?php if (isset($component)) { $__componentOriginalf2f51adcf06edeb87dc06426610dc8e6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2f51adcf06edeb87dc06426610dc8e6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Inputs\DeleteLink::resolve(['href' => ''.e(route('admin.variation-values.destroy', ['id' => $variationValue->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.inputs.delete-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Inputs\DeleteLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2f51adcf06edeb87dc06426610dc8e6)): ?>
<?php $attributes = $__attributesOriginalf2f51adcf06edeb87dc06426610dc8e6; ?>
<?php unset($__attributesOriginalf2f51adcf06edeb87dc06426610dc8e6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2f51adcf06edeb87dc06426610dc8e6)): ?>
<?php $component = $__componentOriginalf2f51adcf06edeb87dc06426610dc8e6; ?>
<?php unset($__componentOriginalf2f51adcf06edeb87dc06426610dc8e6); ?>
<?php endif; ?>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="card__footer">
                <?php echo e($variationValues->links()); ?>

            </div>
        </div>
        <div class="md:col-span-2">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_variation_values')): ?>
                <div class="card">
                    <h4 class="card__title"><?php echo e(translate('Add New Variation Value')); ?></h4>
                    <div class="card__content">
                        <?php if (isset($component)) { $__componentOriginal61ca637af5597a75b8e5923c09b2a144 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal61ca637af5597a75b8e5923c09b2a144 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Forms\VariationValueForm::resolve(['variation' => $variation] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('backend.forms.variation-value-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Backend\Forms\VariationValueForm::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal61ca637af5597a75b8e5923c09b2a144)): ?>
<?php $attributes = $__attributesOriginal61ca637af5597a75b8e5923c09b2a144; ?>
<?php unset($__attributesOriginal61ca637af5597a75b8e5923c09b2a144); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal61ca637af5597a75b8e5923c09b2a144)): ?>
<?php $component = $__componentOriginal61ca637af5597a75b8e5923c09b2a144; ?>
<?php unset($__componentOriginal61ca637af5597a75b8e5923c09b2a144); ?>
<?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luxuryon/public_html/resources/views/backend/admin/variation-values/index.blade.php ENDPATH**/ ?>