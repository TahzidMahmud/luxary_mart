<div class="<?php echo e($labelInline ? 'theme-input-group' : ''); ?>">
    <?php if($label): ?>
        <label for="<?php echo e($name); ?>"
            class="theme-input-label <?php echo e($labelInline ? '' : 'pt-0'); ?> <?php echo e($isRequired ? 'input-required' : ''); ?>">
            <?php echo translate($label); ?>

        </label>
    <?php endif; ?>

    <div class="theme-input-wrapper <?php echo e($label ? '' : 'col-span-4'); ?>">
        <input type="number" min="0" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
            <?php echo e($attributes->merge(['class' => 'theme-input'])); ?> placeholder="<?php echo e(translate($placeholder)); ?>"
            value="<?php echo $value; ?>" <?php if($isRequired): echo 'required'; endif; ?> <?php if($isDisabled): echo 'disabled'; endif; ?> />
    </div>
</div>
<?php /**PATH /home/luxuryon/public_html/resources/views/components/backend/inputs/number.blade.php ENDPATH**/ ?>