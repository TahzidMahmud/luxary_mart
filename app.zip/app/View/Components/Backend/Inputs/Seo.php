<?php

namespace App\View\Components\Backend\Inputs;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class Seo extends Component
{
    /**
     * Create a new component instance.
     */
    public function __construct(
        public $metaTitle       = '',
        public $metaDescription = '',
        public $metaKeywords    = '',
        public $metaImage       = '',
    ) {
        //
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.backend.inputs.seo');
    }
}
