<?php

namespace App\View\Components\Backend\Inputs;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class Checkbox extends Component
{
    /**
     * Create a new component instance.
     */
    public function __construct(
        public $name,
        public $value       = null,
        public $label       = '',
        public $labelInline = true,
        public $toggler = false,
        public $labelOnly = false,
        public $variant     = "success", // 'primary', 'secondary', 'success', 'danger', 'warning', 'light', 'dark'
        public $isChecked   = false,
        public $isDisabled  = false,
    ) {
        //
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.backend.inputs.checkbox');
    }
}
