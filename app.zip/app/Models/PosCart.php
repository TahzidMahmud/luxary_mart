<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PosCart extends Model
{
    use HasFactory;

    public function productVariation()
    {
        return $this->belongsTo(ProductVariation::class);
    }
}
